import { test } from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import { submitCreativeBatch } from '../src/studio/creative';
import { renderFilm, runFfmpeg, mediaRoot } from '../server/media';

test('Creative batch requests three distinct directions and submits three independently planned scripts', async () => {
  const directions: string[] = [], scripts: string[] = [];
  const count = await submitCreativeBatch(async direction => {
    directions.push(direction.id);
    return { title: direction.name, scenes: [{ assetId: 'photo', text: `测试脚本：${direction.name}`, duration: 3, start: 0 }] };
  }, async plan => { scripts.push(plan.scenes[0].text); });
  assert.equal(count, 3); assert.equal(new Set(directions).size, 3); assert.equal(new Set(scripts).size, 3);
});
test('Creative batch rejects duplicate scripts and reports exactly how many jobs were submitted', async () => {
  let submissions = 0;
  await assert.rejects(() => submitCreativeBatch(async () => ({ title: '重复', scenes: [{ assetId: 'photo', text: '完全相同的口播', duration: 3, start: 0 }] }), async () => { submissions++; }), /已提交 1 \/ 3.*重复文案/);
  assert.equal(submissions, 1);
});
function capture(args: string[]) {
  return new Promise<Buffer>((resolve, reject) => {
    const child = spawn(process.env.FFMPEG_PATH || ffmpegInstaller.path, ['-hide_banner', '-loglevel', 'error', ...args], { windowsHide: true });
    const chunks: Buffer[] = []; let error = '';
    child.stdout.on('data', data => chunks.push(data)); child.stderr.on('data', data => { error += data; });
    child.on('error', reject); child.on('close', code => code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error(error)));
  });
}
test('Film export contains a blended transition frame and the overlap reduces actual duration', { timeout: 120000 }, async () => {
  const directory = path.join(mediaRoot, 'transition-' + randomUUID()); await fs.mkdir(directory, { recursive: true });
  const red = path.join(directory, 'red.png'), blue = path.join(directory, 'blue.png');
  await runFfmpeg(['-f', 'lavfi', '-i', 'color=c=red:s=720x1280', '-frames:v', '1', red]);
  await runFfmpeg(['-f', 'lavfi', '-i', 'color=c=blue:s=720x1280', '-frames:v', '1', blue]);
  const output = await renderFilm({ style: 'film', scenes: [{ assetId: 'red', text: '第一镜', duration: 2, start: 0 }, { assetId: 'blue', text: '第二镜', duration: 2, start: 0 }] }, 'transition-test', id => ({ id, owner: 'transition-test', name: id, kind: 'image', file: id === 'red' ? red : blue }));
  const pixel = await capture(['-ss', '1.85', '-i', output, '-vf', 'crop=2:2:0:0', '-frames:v', '1', '-pix_fmt', 'rgb24', '-f', 'rawvideo', 'pipe:1']);
  assert.ok(pixel[0] > 40 && pixel[2] > 40, `Expected red+blue blend, got ${[...pixel.slice(0, 3)]}`);
  const progress = (await capture(['-i', output, '-f', 'null', '-', '-progress', 'pipe:1'])).toString();
  const times = [...progress.matchAll(/out_time_us=(\d+)/g)]; const seconds = Number(times.at(-1)?.[1]) / 1e6;
  assert.ok(seconds > 3.5 && seconds < 3.85, `Expected ~3.7 seconds, got ${seconds}`);
  await fs.mkdir('evidence', { recursive: true }); await fs.copyFile(output, 'evidence/film-transition-sample.mp4');
});
