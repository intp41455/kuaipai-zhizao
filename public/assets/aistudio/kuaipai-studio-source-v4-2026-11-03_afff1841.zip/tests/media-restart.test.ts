import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fork, type ChildProcess } from 'node:child_process';
import { once } from 'node:events';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { MediaState } from '../server/media-state';
import { runFfmpeg } from '../server/media';

test('Running jobs recover as queued and cancelled jobs remain cancelled', async () => {
  const directory = path.resolve('.media', 'catalog-test-' + randomUUID());
  const first = new MediaState(directory);
  const request = { scenes: [{ assetId: 'photo', text: '测试', duration: 2, start: 0 }] };
  first.jobs.set('running', { id: 'running', owner: 'user', request, status: 'running', progress: 44, createdAt: 1 });
  first.jobs.set('cancelled', { id: 'cancelled', owner: 'user', request, status: 'cancelled', cancelled: true, progress: 0, createdAt: 2 });
  first.save();
  const restored = new MediaState(directory);
  assert.equal(restored.jobs.get('running')?.status, 'queued');
  assert.equal(restored.jobs.get('running')?.progress, 0);
  assert.equal(restored.jobs.get('cancelled')?.status, 'cancelled');
});

async function startWorker(directory: string) {
  const child = fork('tests/media-worker.ts', [], { execArgv: ['--import', 'tsx'], env: { ...process.env, MEDIA_DIR: directory }, stdio: ['ignore', 'pipe', 'pipe', 'ipc'] });
  let stderr = ''; child.stderr?.on('data', d => { stderr += d.toString(); });
  const port = await new Promise<number>((resolve, reject) => {
    child.once('message', (message: any) => resolve(message.port));
    child.once('error', reject); child.once('exit', code => reject(new Error(`Test worker exited ${code}: ${stderr}`)));
  });
  return { child, base: `http://127.0.0.1:${port}/media` };
}
async function stop(child: ChildProcess) { const exited = once(child, 'exit'); child.kill(); await exited; }
async function complete(base: string, id: string) {
  for (let i = 0; i < 300; i++) {
    const jobs = await (await fetch(base + '/jobs')).json() as any[];
    const job = jobs.find(j => j.id === id);
    if (job?.status === 'failed') throw new Error(job.error);
    if (job?.status === 'completed') return job;
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error('真实成片任务超时');
}
test('Restarted server retains downloads and can render again from the previous upload ID', { timeout: 90000 }, async () => {
  const directory = path.resolve('.media', 'restart-' + randomUUID());
  await fs.mkdir(directory, { recursive: true });
  const photo = path.join(directory, 'photo.png');
  await runFfmpeg(['-f', 'lavfi', '-i', 'color=c=0x3e6985:s=720x1280', '-frames:v', '1', photo]);
  let worker = await startWorker(directory);
  try {
    const asset = await (await fetch(worker.base + '/assets', { method: 'POST', headers: { 'Content-Type': 'image/png' }, body: await fs.readFile(photo) })).json() as any;
    const body = JSON.stringify({ narration: false, scenes: [{ assetId: asset.id, text: '服务重启后，素材与成片仍可使用', duration: 2, start: 0 }] });
    const submit = async () => (await (await fetch(worker.base + '/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })).json()) as any;
    const original = await submit(); await complete(worker.base, original.id);
    const before = Buffer.from(await (await fetch(worker.base + `/jobs/${original.id}/download`)).arrayBuffer());
    await stop(worker.child); worker = await startWorker(directory);
    const restored = await complete(worker.base, original.id); assert.equal(restored.downloadable, true);
    const after = Buffer.from(await (await fetch(worker.base + `/jobs/${original.id}/download`)).arrayBuffer());
    assert.deepEqual(after, before);
    const second = await submit(); assert.ok(second.id); await complete(worker.base, second.id);
  } finally { await stop(worker.child); }
});
