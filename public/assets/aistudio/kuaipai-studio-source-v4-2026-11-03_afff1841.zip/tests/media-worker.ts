import express from 'express';
import mediaRouter from '../server/media';
const app = express();
app.use(express.json());
// Isolated test process only; this fixture is never imported by server.ts.
app.use((req, _res, next) => { req.identity = { uid: 'restart-user', role: 'creator', verified: true }; next(); });
app.use('/media', mediaRouter);
const server = app.listen(0, '127.0.0.1', () => process.send?.({ port: (server.address() as any).port }));
