import { test } from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import express from 'express';
import { retrieveKnowledge } from '../server/knowledge';
import { requireIdentity } from '../server/auth';
import mediaRouter, { renderFilm, runFfmpeg, synthesizeSpeech, mediaRoot, type StoredAsset } from '../server/media';

test('RAG retrieves facts with source and does not invent a hit', () => {
  const docs = [{ id: 'menu', name: '店铺资料.md', text: '店铺名称：巷口面馆。招牌菜为油泼面，营业时间上午十点至晚上九点。' }, { id: 'other', name: '家具.md', text: '实木桌椅采用榫卯结构。' }];
  const hits = retrieveKnowledge('招牌菜是什么？', docs);
  assert.equal(hits[0].sourceId, 'menu');
  assert.ok(hits[0].text.includes('油泼面'));
  assert.equal(hits[0].chunk, 1);
  assert.equal(retrieveKnowledge('量子纠缠', docs).length, 0);
});
test('Forged admin headers do not authenticate an API request', async () => {
  const app = express();
  app.get('/protected', requireIdentity, (_req, res) => res.json({ ok: true }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise<void>(resolve => server.once('listening', resolve));
  const port = (server.address() as any).port;
  try {
    const response = await fetch(`http://127.0.0.1:${port}/protected`, { headers: { 'X-User-Uid': 'victim', 'X-User-Role': 'super_admin' } });
    assert.equal(response.status, 401);
    assert.match((await response.json() as any).error, /登录/);
  } finally { server.close(); }
});
test('Missing AI key returns explicit error instead of synthetic audio', async () => {
  if (!process.env.GEMINI_API_KEY) await assert.rejects(() => synthesizeSpeech('真实音频测试', 'Kore'), /GEMINI_API_KEY/);
});
test('Actual photo + video + subtitles + BGM render to playable 1080P MP4', { timeout: 120000 }, async () => {
  const dir = path.join(mediaRoot, 'smoke-fixtures'); await fs.mkdir(dir, { recursive: true });
  const photo = path.join(dir, 'photo.png'); const video = path.join(dir, 'clip.mp4'); const music = path.join(dir, 'music.wav');
  await runFfmpeg(['-f', 'lavfi', '-i', 'color=c=0x385b79:s=800x1200', '-frames:v', '1', photo]);
  await runFfmpeg(['-f', 'lavfi', '-i', 'testsrc2=size=640x360:rate=30', '-t', '2', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', video]);
  await runFfmpeg(['-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000', '-t', '5', music]);
  const fixtures: Record<string, StoredAsset> = {
    photo: { id: 'photo', owner: 'smoke', file: photo, kind: 'image', name: 'photo' },
    video: { id: 'video', owner: 'smoke', file: video, kind: 'video', name: 'video' },
    music: { id: 'music', owner: 'smoke', file: music, kind: 'audio', name: 'music' },
  };
  const progress: number[] = [];
  const output = await renderFilm({ aspect: '9:16', style: 'food', narration: false, bgmId: 'music', scenes: [{ assetId: 'photo', text: '照片推近与中文字幕', duration: 2, start: 0 }, { assetId: 'video', text: '实拍片段与音轨一起导出', duration: 2, start: 0 }] }, 'smoke', id => fixtures[id], n => progress.push(n));
  const stat = await fs.stat(output); assert.ok(stat.size > 10000);
  await runFfmpeg(['-i', output, '-f', 'null', '-']);
  assert.equal(progress.at(-1), 100);
  await fs.mkdir('evidence', { recursive: true });
  await fs.copyFile(output, 'evidence/render-smoke-1080p.mp4');
  await runFfmpeg(['-ss', '0.5', '-i', output, '-frames:v', '1', 'evidence/render-smoke-frame.png']);
});
test('HTTP upload, queued render, owner isolation, download and cancel use real files', { timeout: 120000 }, async () => {
  const app = express(); app.use(express.json());
  // Test-only identity fixture. The production app always uses requireIdentity.
  app.use((req, _res, next) => { req.identity = { uid: req.headers['x-test-owner'] === 'other' ? 'other' : 'http-test', role: 'creator', verified: true }; next(); });
  app.use('/studio', mediaRouter);
  const server = app.listen(0, '127.0.0.1'); await new Promise<void>(r => server.once('listening', r));
  const base = `http://127.0.0.1:${(server.address() as any).port}/studio`;
  try {
    const source = path.join(mediaRoot, 'http-fixture.png'); await fs.mkdir(mediaRoot, { recursive: true });
    await runFfmpeg(['-f', 'lavfi', '-i', 'color=c=0x826f53:s=720x1080', '-frames:v', '1', source]);
    const uploaded = await fetch(base + '/assets', { method: 'POST', headers: { 'Content-Type': 'image/png', 'X-File-Name': 'fixture.png' }, body: await fs.readFile(source) });
    assert.equal(uploaded.status, 201); const asset = await uploaded.json() as any;
    const body = JSON.stringify({ scenes: [{ assetId: asset.id, text: '真实 HTTP 成片链路', duration: 2, start: 0 }], narration: false });
    const denied = await fetch(base + '/render', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Test-Owner': 'other' }, body });
    assert.equal(denied.status, 400);
    const response = await fetch(base + '/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    assert.equal(response.status, 202); const job = await response.json() as any;
    let completed = false;
    for (let i = 0; i < 200; i++) {
      const list = await (await fetch(base + '/jobs')).json() as any[];
      const state = list.find(item => item.id === job.id);
      if (state?.status === 'failed') assert.fail(state.error);
      if (state?.status === 'completed') { completed = true; break; }
      await new Promise(r => setTimeout(r, 100));
    }
    assert.ok(completed);
    const download = await fetch(base + `/jobs/${job.id}/download`); assert.equal(download.status, 200);
    assert.match(download.headers.get('content-type') || '', /video\/mp4/);
    const data = new Uint8Array(await download.arrayBuffer()); assert.ok(data.byteLength > 10000);
    const other = await fetch(base + `/jobs/${job.id}/download`, { headers: { 'X-Test-Owner': 'other' } }); assert.equal(other.status, 404);
    const pending = await (await fetch(base + '/render', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body })).json() as any;
    const cancel = await fetch(base + `/jobs/${pending.id}/cancel`, { method: 'POST' }); assert.equal(cancel.status, 200);
  } finally { server.close(); }
});
