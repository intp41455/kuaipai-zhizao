import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { SemanticKnowledge, cosineSimilarity } from '../server/semantic-knowledge';
import { retrieveKnowledge } from '../server/knowledge';

test('Semantic retrieval finds a passage without shared keywords, retains sources, and rejects unrelated queries', async () => {
  // Controlled vectors verify retrieval mechanics, not Gemini's real embedding quality.
  const vectors: Record<string, number[]> = {
    '停车方便吗': [1, 0, 0], '院子内提供三个车位。': [0.98, 0.1, 0],
    '招牌是油泼面。': [0, 1, 0], '如何给手机刷机': [0, 0, 1],
  };
  const sources = [{ id: 'parking', name: '服务信息.md', text: '院子内提供三个车位。' }, { id: 'menu', name: '菜单.md', text: '招牌是油泼面。' }];
  assert.equal(retrieveKnowledge('停车方便吗', sources).length, 0);
  const service = new SemanticKnowledge({ directory: path.resolve('.media', 'semantic-test-' + randomUUID()), embed: async texts => texts.map(text => vectors[text]) });
  const result = await service.search('owner', '停车方便吗', sources);
  assert.equal(result.sources[0].sourceId, 'parking');
  assert.equal(result.sources[0].name, '服务信息.md');
  assert.equal(result.sources[0].chunk, 1);
  assert.equal(result.retrieval, 'semantic-hybrid');
  assert.equal((await service.search('owner', '如何给手机刷机', sources)).sources.length, 0);
});
test('Index persists across service instances, separates users, and updates after edits and deletion', async () => {
  const directory = path.resolve('.media', 'semantic-cache-' + randomUUID());
  let documentCalls = 0;
  const embed = async (texts: string[], task: string) => { if (task === 'RETRIEVAL_DOCUMENT') documentCalls++; return texts.map(() => [1, 0]); };
  const first = new SemanticKnowledge({ directory, model: 'fixture-model', embed });
  const source = [{ id: 'one', name: '店铺.md', text: '旧菜单' }];
  await first.index('user-a', source); assert.equal(documentCalls, 1);
  await new SemanticKnowledge({ directory, model: 'fixture-model', embed }).index('user-a', source); assert.equal(documentCalls, 1);
  await first.index('user-b', source); assert.equal(documentCalls, 2);
  const edited = await first.index('user-a', [{ ...source[0], text: '新菜单' }]);
  assert.equal(documentCalls, 3); assert.equal(edited.passages[0].text, '新菜单');
  const removed = await first.search('user-a', '菜单', []);
  assert.equal(removed.sources.length, 0);
  const afterRestart = await new SemanticKnowledge({ directory, model: 'fixture-model', embed }).index('user-a', []);
  assert.equal(afterRestart.passages.length, 0);
});
test('Vector service failure surfaces as a failure and never becomes a lexical-only success', async () => {
  const service = new SemanticKnowledge({ directory: path.resolve('.media', 'semantic-failure-' + randomUUID()), embed: async () => { throw new Error('provider unavailable'); } });
  await assert.rejects(() => service.search('user', '招牌菜', [{ id: 'one', name: 'menu', text: '招牌菜是油泼面。' }]), /provider unavailable/);
  assert.throws(() => cosineSimilarity([1, 0], [1]), /维度不一致/);
});
