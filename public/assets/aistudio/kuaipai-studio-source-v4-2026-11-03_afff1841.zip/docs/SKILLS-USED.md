# 专业技能使用记录

本次在产品代码修改前安装并读取了以下技能入口；各类工程工作可共用一个技能，不按名称堆砌重复包。

| 类别 | 技能 | 来源与状态 |
|---|---|---|
| 前端视觉与交互 | frontend-design | anthropics/skills，已新安装并读取 |
| 应用流程验证 | webapp-testing | anthropics/skills，已新安装并读取 |
| 数据库结构、查询、权限 | supabase-postgres-best-practices | supabase/agent-skills，已新安装并读取；仅作数据库方法参考，实际项目是Firestore，没有迁移成Postgres |
| 架构与编程接口 | codebase-design | mattpocock/skills，已新安装并读取 |
| 视频应用开发 | remotion-best-practices | remotion-dev/skills，已新安装并读取；实际使用FFmpeg，没有为了用技能强加Remotion |
| 后端架构 | create-a-backend | 现有Vercel插件技能，修改前已读取；没有迁移到Vercel |
| React编程与组件检查 | react-best-practices / vercel-react-best-practices | 现有Vercel技能，收口时读取，用于本轮TSX检查 |
| 软件工程验收 | verification-before-completion | 现有技能，修改过程中已读取，按改动范围验证 |

核实的仓库星标快照：anthropics/skills 186870、supabase/agent-skills 2992、remotion-dev/skills 6172、mattpocock/skills 310517。快照可能变化，属于整个仓库热度，不是各技能好评率。skills.sh展示安装量，不能把它称作收藏量。没有取得可信的独立好评/收藏统计，因此没有编造这两项指标。

安装入口：`C:\Users\intpj\.codex\skills\<技能名>\SKILL.md`。技能本身是工作指引，不是产品运行依赖；源包无需复制本机全部技能文件即可部署。
