export interface KnowledgeSource { id: string; name: string; text: string }
export function retrieveKnowledge(question: string, sources: KnowledgeSource[]) {
  const terms = [...new Set((question.toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).flatMap(w => w.length > 2 ? [w, ...Array.from({ length: w.length - 1 }, (_, i) => w.slice(i, i + 2))] : [w]))];
  return sources.slice(0, 30).flatMap(source => {
    const text = String(source.text || '').slice(0, 50000);
    const chunks: { sourceId: string; name: string; chunk: number; text: string; score: number }[] = [];
    for (let i = 0; i < text.length; i += 420) {
      const part = text.slice(i, i + 500);
      const score = terms.reduce((sum, word) => sum + (part.toLowerCase().includes(word) ? word.length : 0), 0);
      if (score > 0) chunks.push({ sourceId: source.id, name: source.name, chunk: Math.floor(i / 420) + 1, text: part, score });
    }
    return chunks;
  }).sort((a, b) => b.score - a.score).slice(0, 6);
}
