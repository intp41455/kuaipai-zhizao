import type { Request, Response, NextFunction } from 'express';
import { readFileSync } from 'node:fs';

const config = JSON.parse(readFileSync('firebase-applet-config.json', 'utf8'));
export interface Identity { uid: string; role: 'super_admin' | 'creator'; verified: boolean }
declare global { namespace Express { interface Request { identity?: Identity } } }
const cache = new Map<string, { identity: Identity; expires: number }>();

export async function requireIdentity(req: Request, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: '请先登录后使用云端功能。' });
  try {
    let entry = cache.get(token);
    if (!entry || entry.expires < Date.now()) {
      const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${config.apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken: token }), signal: AbortSignal.timeout(12000),
      });
      const data = await response.json() as { users?: { localId: string; emailVerified?: boolean }[] };
      if (!response.ok || !data.users?.[0]) return res.status(401).json({ error: '登录已过期，请重新登录。' });
      const user = data.users[0];
      const admins = (process.env.ADMIN_UIDS || '').split(',').map(s => s.trim()).filter(Boolean);
      entry = { identity: { uid: user.localId, role: admins.includes(user.localId) ? 'super_admin' : 'creator', verified: !!user.emailVerified }, expires: Date.now() + 60000 };
      if (cache.size > 1000) cache.clear();
      cache.set(token, entry);
    }
    req.identity = entry.identity;
    return next();
  } catch { return res.status(503).json({ error: '暂时无法验证登录，请检查认证服务连接。' }); }
}
