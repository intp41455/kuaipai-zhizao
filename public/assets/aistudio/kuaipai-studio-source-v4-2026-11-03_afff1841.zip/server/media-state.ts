import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import path from 'node:path';
import type { Scene } from '../src/studio/types';

export interface StoredAsset { id: string; owner: string; file: string; name: string; kind: 'image' | 'video' | 'audio' }
export interface RenderOptions { title?: string; scenes: Scene[]; aspect?: string; style?: string; voice?: string; narration?: boolean; bgmId?: string }
export interface RenderJob {
  id: string; owner: string; status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number; error?: string; output?: string; createdAt: number; cancelled?: boolean;
  request: RenderOptions;
}

// One writer per MEDIA_DIR. A persistent mount is required across container replacement.
export class MediaState {
  readonly assets = new Map<string, StoredAsset>();
  readonly jobs = new Map<string, RenderJob>();
  private readonly file: string;
  constructor(directory: string) {
    mkdirSync(directory, { recursive: true });
    this.file = path.join(directory, 'catalog.json');
    if (!existsSync(this.file)) return;
    const data = JSON.parse(readFileSync(this.file, 'utf8')) as { version: number; assets: StoredAsset[]; jobs: RenderJob[] };
    if (data.version !== 1) throw new Error('不支持的媒体索引版本。');
    for (const asset of data.assets) this.assets.set(asset.id, asset);
    for (const job of data.jobs) {
      if (job.status === 'running') { job.status = 'queued'; job.progress = 0; }
      this.jobs.set(job.id, job);
    }
  }
  save() {
    const temporary = this.file + '.tmp';
    writeFileSync(temporary, JSON.stringify({ version: 1, assets: [...this.assets.values()], jobs: [...this.jobs.values()] }), { mode: 0o600 });
    renameSync(temporary, this.file);
  }
}
