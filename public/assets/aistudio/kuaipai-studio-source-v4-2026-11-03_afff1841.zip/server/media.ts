import express from 'express';
import { randomUUID } from 'node:crypto';
import { promises as fs, existsSync } from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { GoogleGenAI, Modality } from '@google/genai';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import { MediaState, type RenderJob, type RenderOptions, type StoredAsset } from './media-state';
export type { StoredAsset } from './media-state';

export const mediaRoot = path.resolve(process.env.MEDIA_DIR || '.media');
const ffmpeg = process.env.FFMPEG_PATH || ffmpegInstaller.path;
const state = new MediaState(mediaRoot);
const { jobs, assets } = state;
let queue = Promise.resolve();
const router = express.Router();
export default router;

export function runFfmpeg(args: string[], signal?: AbortSignal) {
  return new Promise<string>((resolve, reject) => {
    const child = spawn(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', ...args], { windowsHide: true, signal });
    let stderr = '';
    child.stderr.on('data', d => { stderr = (stderr + String(d)).slice(-5000); });
    child.once('error', reject);
    child.once('close', code => code === 0 ? resolve(stderr) : reject(new Error(`视频合成失败 (${code})：${stderr.slice(-800)}`)));
  });
}

function ownAsset(id: string, owner: string) {
  const asset = assets.get(id);
  if (!asset || asset.owner !== owner) throw new Error('素材已过期或无权访问，请重新上传。');
  return asset;
}
function voiceClient() {
  if (!process.env.GEMINI_API_KEY) throw new Error('请在 AI Studio Secrets 配置 GEMINI_API_KEY 后使用 AI 配音。');
  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}
export async function synthesizeSpeech(text: string, voice: string) {
  const response = await voiceClient().models.generateContent({
    model: process.env.TTS_MODEL || 'gemini-2.5-flash-preview-tts',
    contents: `请用自然、真诚的普通话朗读以下内容，不添加任何额外文字：\n${text.slice(0, 3000)}`,
    config: { responseModalities: [Modality.AUDIO], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: ['Kore', 'Puck', 'Charon', 'Aoede'].includes(voice) ? voice : 'Kore' } } } },
  });
  const audio = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData?.data)?.inlineData;
  if (!audio?.data) throw new Error('配音模型没有返回音频，请检查模型权限和配额。');
  const pcm = Buffer.from(audio.data, 'base64');
  const rate = Number(audio.mimeType?.match(/rate=(\d+)/)?.[1] || 24000);
  const wav = Buffer.alloc(44);
  wav.write('RIFF'); wav.writeUInt32LE(pcm.length + 36, 4); wav.write('WAVEfmt ', 8);
  wav.writeUInt32LE(16, 16); wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22);
  wav.writeUInt32LE(rate, 24); wav.writeUInt32LE(rate * 2, 28); wav.writeUInt16LE(2, 32); wav.writeUInt16LE(16, 34);
  wav.write('data', 36); wav.writeUInt32LE(pcm.length, 40);
  return { buffer: Buffer.concat([wav, pcm]), duration: pcm.length / rate / 2 };
}

router.get('/status', async (_req, res) => {
  let renderer = true;
  try { await runFfmpeg(['-version']); } catch { renderer = false; }
  res.json({ renderer, speech: !!process.env.GEMINI_API_KEY, persistentMedia: process.env.MEDIA_PERSISTENT === 'true', storage: 'filesystem', restartRecovery: true, maxUploadMB: 25 });
});
router.post('/assets', express.raw({ type: ['image/*', 'video/*', 'audio/*'], limit: '25mb' }), async (req, res) => {
  try {
    if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ error: '请选择图片、视频或音频文件。' });
    const mime = String(req.headers['content-type'] || '');
    const kind = mime.startsWith('image/') ? 'image' : mime.startsWith('video/') ? 'video' : mime.startsWith('audio/') ? 'audio' : null;
    if (!kind) return res.status(415).json({ error: '不支持的素材类型。' });
    const id = randomUUID();
    const name = decodeURIComponent(String(req.headers['x-file-name'] || '素材')).slice(0, 150);
    const dir = path.join(mediaRoot, req.identity!.uid);
    await fs.mkdir(dir, { recursive: true });
    const file = path.join(dir, id + (kind === 'image' ? '.image' : kind === 'audio' ? '.audio' : '.video'));
    await fs.writeFile(file, req.body);
    assets.set(id, { id, owner: req.identity!.uid, file, name, kind });
    state.save();
    res.status(201).json({ id, name, kind });
  } catch { res.status(500).json({ error: '素材上传失败。' }); }
});
router.post('/speech', async (req, res) => {
  try {
    if (!String(req.body.text || '').trim()) return res.status(400).json({ error: '请先输入口播文案。' });
    const result = await synthesizeSpeech(String(req.body.text), String(req.body.voice || 'Kore'));
    res.type('audio/wav').send(result.buffer);
  } catch (error) { res.status(503).json({ error: (error as Error).message }); }
});

export async function renderFilm(options: RenderOptions, owner: string, resolveAsset = ownAsset, onProgress = (_n: number) => {}, signal?: AbortSignal) {
  const id = randomUUID();
  const dir = path.join(mediaRoot, owner, id);
  await fs.mkdir(dir, { recursive: true });
  const width = options.aspect === '16:9' ? 1920 : 1080;
  const height = options.aspect === '16:9' ? 1080 : 1920;
  const font = process.env.VIDEO_FONT_PATH || path.resolve('assets/fonts/NotoSansCJKsc-Regular.otf');
  if (!existsSync(font)) throw new Error('缺少中文字体，请配置 VIDEO_FONT_PATH。');
  const escapedFont = font.replace(/\\/g, '/').replace(/:/g, '\\:');
  const clips: string[] = [];
  const durations: number[] = [];
  for (let i = 0; i < options.scenes.length; i++) {
    if (signal?.aborted) throw new Error('已取消');
    const scene = options.scenes[i];
    const asset = resolveAsset(scene.assetId, owner);
    const caption = String(scene.text || '').slice(0, 180);
    let duration = Math.min(15, Math.max(2, Number(scene.duration) || 4));
    let speech: string | undefined;
    if (options.narration && caption) {
      const audio = await synthesizeSpeech(caption, options.voice || 'Kore');
      duration = Math.max(duration, audio.duration + 0.35);
      speech = path.join(dir, `voice-${i}.wav`);
      await fs.writeFile(speech, audio.buffer);
    }
    const textFile = path.join(dir, `caption-${i}.txt`);
    const lines = caption.match(/.{1,16}/gu) || [];
    await fs.writeFile(textFile, lines.join('\n'), 'utf8');
    const safeTextFile = textFile.replace(/\\/g, '/').replace(/:/g, '\\:');
    const base = asset.kind === 'image'
      ? `scale=${width * 2}:${height * 2}:force_original_aspect_ratio=increase,crop=${width * 2}:${height * 2},zoompan=z='min(zoom+0.0004,1.08)':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=${Math.ceil(duration * 30)}:s=${width}x${height}:fps=30`
      : `scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},fps=30`;
    const tint = options.style === 'film' ? ',eq=saturation=0.85:contrast=1.05:brightness=-0.015' : options.style === 'food' ? ',eq=saturation=1.12:contrast=1.03' : '';
    const filter = `${base}${tint},setsar=1,drawtext=fontfile='${escapedFont}':textfile='${safeTextFile}':expansion=none:fontsize=${width === 1080 ? 48 : 42}:fontcolor=white:borderw=3:bordercolor=black@0.75:line_spacing=12:x=(w-tw)/2:y=min(h*0.76\\,h-th-h*0.12)`;
    const clip = path.join(dir, `${i}.mp4`);
    const input = asset.kind === 'image' ? ['-loop', '1', '-i', asset.file] : ['-ss', String(Math.max(0, Number(scene.start) || 0)), '-stream_loop', '-1', '-i', asset.file];
    input.splice(input.indexOf('-i'), 0, '-protocol_whitelist', 'file,pipe,crypto');
    await runFfmpeg([...input, ...(speech ? ['-i', speech] : ['-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo']), '-map', '0:v:0', '-map', '1:a:0', '-vf', filter, '-af', 'apad,aresample=48000', '-t', String(duration), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-movflags', '+faststart', clip], signal);
    clips.push(clip);
    durations.push(duration);
    onProgress(Math.round(((i + 1) / options.scenes.length) * 88));
  }
  const list = path.join(dir, 'clips.txt');
  await fs.writeFile(list, clips.map(file => `file '${file.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'));
  const joined = path.join(dir, 'joined.mp4');
  if (options.style === 'film' && clips.length > 1) {
    const filters: string[] = [];
    const sequence: string[] = [];
    clips.forEach((_, i) => {
      const names = [...(i ? [`headSource${i}`] : []), `bodySource${i}`, ...(i < clips.length - 1 ? [`tailSource${i}`] : [])];
      filters.push(`[${i}:v]split=${names.length}${names.map(name => `[${name}]`).join('')}`);
      filters.push(`[bodySource${i}]trim=start=${i ? 0.3 : 0}:end=${(durations[i] - (i < clips.length - 1 ? 0.3 : 0)).toFixed(3)},setpts=PTS-STARTPTS[body${i}]`, `[${i}:a]asetpts=PTS-STARTPTS[a${i}]`);
      if (i) filters.push(`[headSource${i}]trim=start=0:end=0.3,setpts=PTS-STARTPTS[head${i}]`);
      if (i < clips.length - 1) filters.push(`[tailSource${i}]trim=start=${(durations[i] - 0.3).toFixed(3)}:end=${durations[i].toFixed(3)},setpts=PTS-STARTPTS[tail${i}]`);
    });
    let sound = 'a0';
    sequence.push('[body0]');
    for (let i = 1; i < clips.length; i++) {
      filters.push(`[tail${i - 1}][head${i}]blend=all_expr='A*(1-T/0.3)+B*(T/0.3)'[mix${i}]`, `[${sound}][a${i}]acrossfade=d=0.3[sound${i}]`);
      sound = `sound${i}`;
      sequence.push(`[mix${i}]`, `[body${i}]`);
    }
    filters.push(`${sequence.join('')}concat=n=${sequence.length}:v=1:a=0[picture]`);
    const picture = 'picture';
    await runFfmpeg([...clips.flatMap(file => ['-i', file]), '-filter_complex_threads', '1', '-filter_complex', filters.join(';'), '-map', `[${picture}]`, '-map', `[${sound}]`, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', joined], signal);
  } else await runFfmpeg(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', joined], signal);
  const output = path.join(dir, 'film.mp4');
  if (options.bgmId) {
    const bgm = resolveAsset(options.bgmId, owner);
    await runFfmpeg(['-i', joined, '-stream_loop', '-1', '-i', bgm.file, '-filter_complex', '[1:a]volume=0.12[music];[0:a][music]amix=inputs=2:duration=first[a]', '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', output], signal);
  } else await fs.rename(joined, output);
  onProgress(100);
  return output;
}

router.post('/render', async (req, res) => {
  const options = req.body as RenderOptions;
  if (!Array.isArray(options.scenes) || options.scenes.length < 1 || options.scenes.length > 24) return res.status(400).json({ error: '请添加 1–24 个镜头。' });
  const owner = req.identity!.uid;
  try { for (const scene of options.scenes) ownAsset(scene.assetId, owner); if (options.bgmId) ownAsset(options.bgmId, owner); }
  catch (error) { return res.status(400).json({ error: (error as Error).message }); }
  const pending = [...jobs.values()].filter(job => job.owner === owner && ['queued', 'running'].includes(job.status));
  if (pending.length >= 5) return res.status(429).json({ error: '最多同时排队 5 个成片任务，请等待当前任务完成。' });
  const job: RenderJob = { id: randomUUID(), owner, status: 'queued', progress: 0, createdAt: Date.now(), request: options };
  jobs.set(job.id, job);
  state.save();
  enqueueJob(job);
  res.status(202).json({ id: job.id, status: job.status });
});

function enqueueJob(job: RenderJob) {
  queue = queue.catch(() => {}).then(async () => {
    if (job.cancelled) return;
    job.status = 'running';
    state.save();
    const controller = new AbortController();
    const timer = setInterval(() => { if (job.cancelled) controller.abort(); }, 300);
    try {
      job.output = await renderFilm(job.request, job.owner, ownAsset, n => { job.progress = n; state.save(); }, controller.signal);
      job.status = job.cancelled ? 'cancelled' : 'completed';
    } catch (error) { job.status = job.cancelled ? 'cancelled' : 'failed'; job.error = (error as Error).message; }
    finally { clearInterval(timer); state.save(); }
  });
}
for (const job of jobs.values()) if (job.status === 'queued' && !job.cancelled) enqueueJob(job);

router.get('/jobs', (req, res) => res.json([...jobs.values()].filter(j => j.owner === req.identity!.uid).map(({ output, owner, request, ...job }) => ({ ...job, title: request.title || '未命名作品', downloadable: job.status === 'completed' && !!output && existsSync(output) }))));
router.post('/jobs/:id/cancel', (req, res) => {
  const job = jobs.get(String(req.params.id));
  if (!job || job.owner !== req.identity!.uid) return res.sendStatus(404);
  if (['queued', 'running'].includes(job.status)) { job.cancelled = true; job.status = 'cancelled'; }
  state.save();
  res.json({ ok: true });
});
router.get('/jobs/:id/download', (req, res) => {
  const job = jobs.get(String(req.params.id));
  if (!job || job.owner !== req.identity!.uid || !job.output || job.status !== 'completed') return res.sendStatus(404);
  res.download(job.output, '快拍智造.mp4');
});
