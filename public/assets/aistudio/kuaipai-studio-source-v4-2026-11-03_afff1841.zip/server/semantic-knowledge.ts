import { GoogleGenAI } from '@google/genai';
import { createHash, randomUUID } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { retrieveKnowledge, type KnowledgeSource } from './knowledge';

type Passage = { sourceId: string; name: string; chunk: number; text: string };
type Index = { fingerprint: string; model: string; passages: Passage[]; vectors: number[][] };
type Embedder = (texts: string[], task: 'RETRIEVAL_DOCUMENT' | 'RETRIEVAL_QUERY') => Promise<number[][]>;
const hash = (text: string) => createHash('sha256').update(text).digest('hex');

export function cosineSimilarity(left: number[], right: number[]) {
  if (!left.length || left.length !== right.length) throw new Error('知识向量维度不一致，请重建索引。');
  let dot = 0, a = 0, b = 0;
  for (let i = 0; i < left.length; i++) { dot += left[i] * right[i]; a += left[i] ** 2; b += right[i] ** 2; }
  return a && b ? dot / Math.sqrt(a * b) : 0;
}
function chunkSources(sources: KnowledgeSource[]): Passage[] {
  return sources.flatMap(source => {
    const result: Passage[] = [];
    for (let offset = 0; offset < source.text.length; offset += 420) result.push({ sourceId: source.id, name: source.name, chunk: Math.floor(offset / 420) + 1, text: source.text.slice(offset, offset + 500) });
    return result;
  });
}

export class SemanticKnowledge {
  private readonly directory: string;
  private readonly model: string;
  private readonly embed: Embedder;
  private readonly pending = new Map<string, Promise<Index>>();
  constructor(options: { directory?: string; model?: string; embed?: Embedder } = {}) {
    this.directory = options.directory || path.resolve(process.env.MEDIA_DIR || '.media', 'knowledge');
    this.model = options.model || process.env.EMBEDDING_MODEL || 'gemini-embedding-001';
    this.embed = options.embed || (async (texts, taskType) => {
      if (!process.env.GEMINI_API_KEY) throw new Error('语义知识库需要部署端配置 GEMINI_API_KEY。');
      const client = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await client.models.embedContent({ model: this.model, contents: texts, config: { taskType, outputDimensionality: 768 } });
      const vectors = response.embeddings?.map(item => item.values || []) || [];
      if (vectors.length !== texts.length || vectors.some(v => !v.length || v.some(n => !Number.isFinite(n)))) throw new Error('向量模型没有返回完整结果，请检查模型权限或配额。');
      return vectors;
    });
  }
  async index(owner: string, sources: KnowledgeSource[]) {
    if (sources.length > 30 || sources.some(s => typeof s.text !== 'string' || typeof s.id !== 'string' || typeof s.name !== 'string') || sources.reduce((n, s) => n + s.text.length, 0) > 200000) throw new Error('知识资料最多30份、合计20万字。');
    const normalized = sources.filter(s => s.text.trim()).map(s => ({ id: s.id, name: s.name, text: s.text }));
    const fingerprint = hash(JSON.stringify({ model: this.model, sources: normalized }));
    const key = hash(owner);
    const file = path.join(this.directory, key + '.json');
    let cached: Index | undefined;
    try { cached = JSON.parse(await fs.readFile(file, 'utf8')); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error; }
    if (cached?.fingerprint === fingerprint) return cached;
    const pendingKey = key + fingerprint;
    if (this.pending.has(pendingKey)) return this.pending.get(pendingKey)!;
    const work = (async () => {
      const passages = chunkSources(normalized);
      const vectors: number[][] = [];
      for (let offset = 0; offset < passages.length; offset += 64) vectors.push(...await this.embed(passages.slice(offset, offset + 64).map(p => p.text), 'RETRIEVAL_DOCUMENT'));
      const index: Index = { fingerprint, model: this.model, passages, vectors };
      await fs.mkdir(this.directory, { recursive: true });
      const temporary = file + '.' + randomUUID() + '.tmp';
      await fs.writeFile(temporary, JSON.stringify(index), { mode: 0o600 });
      await fs.rename(temporary, file);
      return index;
    })();
    this.pending.set(pendingKey, work);
    try { return await work; } finally { this.pending.delete(pendingKey); }
  }
  async search(owner: string, question: string, sources: KnowledgeSource[]) {
    if (!question.trim()) return { sources: [], retrieval: 'semantic-hybrid', model: this.model };
    const index = await this.index(owner, sources);
    if (!index.passages.length) return { sources: [], retrieval: 'semantic-hybrid', model: this.model };
    const [query] = await this.embed([question], 'RETRIEVAL_QUERY');
    const lexical = retrieveKnowledge(question, sources);
    const ranked = index.passages.map((passage, i) => ({ ...passage, similarity: cosineSimilarity(query, index.vectors[i]) })).sort((a, b) => b.similarity - a.similarity);
    const scores = new Map<string, number>();
    const identify = (p: Passage) => `${p.sourceId}:${p.chunk}`;
    ranked.filter(p => p.similarity >= Number(process.env.RAG_MIN_SIMILARITY || 0.5)).slice(0, 12).forEach((p, rank) => scores.set(identify(p), 1 / (20 + rank)));
    lexical.forEach((p, rank) => scores.set(identify(p), (scores.get(identify(p)) || 0) + 1 / (20 + rank)));
    return { sources: ranked.filter(p => scores.has(identify(p))).sort((a, b) => scores.get(identify(b))! - scores.get(identify(a))!).slice(0, 6), retrieval: 'semantic-hybrid', model: this.model };
  }
}
export const semanticKnowledge = new SemanticKnowledge();
