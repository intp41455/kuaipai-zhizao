功能链路样片，不是竞品质量达标证明。food-workflow-sample.mp4 为图库照片推近与字幕演示，无AI配音。图片来源：https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg
render-smoke-1080p.mp4 为自动化测试，含合成色块、测试片段与正弦测试音轨。
未包含真实用户文件、API密钥、node_modules、临时渲染目录或.git。