import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Sparkles,
  Film,
  Sliders,
  Wand2,
  Plus,
  Copy,
  ArrowUpToLine,
  ArrowDownToLine,
  Trash2,
  CheckCircle2,
  Layers,
  Music,
  Type,
  Palette,
  Upload,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  SkipBack,
  SkipForward,
  Bot,
  Eye,
  Zap,
  RefreshCw,
  Camera,
  MapPin,
  Mic,
  Award,
  Flame,
  Check,
  Share2,
  Maximize2,
  Minimize2,
  Grid,
  FileVideo,
  ListOrdered,
  Radio,
  Clock,
  Sparkle,
  Store,
  Shuffle,
  FileText,
  Lightbulb,
  SlidersHorizontal,
  Settings2,
  Activity,
  Compass,
  BrainCircuit,
} from 'lucide-react';
import { StoreMemoryProfile } from '../data/curatedTemplates';

export type RemixStudioMode = 'foolproof' | 'pro_nle';

export interface ShotProConfig {
  duration: number;
  movement: '慢速推近' | '全景拉镜' | '平滑右摇' | '环绕聚焦' | '固定促单';
  transition: '硬切卡点' | '柔光叠化' | '闪白冲击' | '动感推进';
  lut: 'street_fire' | 'vivid_food' | 'retro_film' | 'clean_cool' | 'luxury_dark';
  subtitleStyle: 'yellow_stroke' | 'white_minimal' | 'variety_pop' | 'xhs_pill' | 'red_sign';
  subtitleSize: number;
  subtitlePosY: number; // 0.65 to 0.88
  customMediaUrl?: string;
  rankBadge?: string;
  locationTag?: string;
}

export interface AIVideoRemixDualStudioProps {
  initialMode?: RemixStudioMode;
  projectTitle: string;
  setProjectTitle: (v: string) => void;
  productName: string;
  setProductName: (v: string) => void;
  sellingPoints: string;
  setSellingPoints: (v: string) => void;
  category: string;
  aspectRatio: '9:16' | '16:9' | '4:3';
  setAspectRatio: (v: '9:16' | '16:9' | '4:3') => void;
  bgmStyle: string;
  setBgmStyle: (v: string) => void;
  voiceTone: string;
  setVoiceTone: (v: string) => void;
  cameraAngles: string[];
  setCameraAngles: (v: string[]) => void;
  visualCues: string[];
  setVisualCues: (v: string[]) => void;
  sceneLines: string[];
  setSceneLines: (v: string[]) => void;
  shotDurations: number[];
  setShotDurations: (v: number[]) => void;
  shotMovements: string[];
  setShotMovements: (v: string[]) => void;
  activeStore: StoreMemoryProfile;
  onShowNotice: (type: 'success' | 'error', text: string) => void;
  onNavigateToEditor: () => void;
  onOpenCustomAgentModal?: () => void;
}

// 6 大真人级 AI 口播音色库（对标筷子科技 & 火兔真人口播）
export interface AIVoicePersona {
  id: string;
  name: string;
  tag: string;
  desc: string;
  pitch: number;
  rate: number;
  sampleText: string;
}

const AI_VOICE_PERSONAS: AIVoicePersona[] = [
  {
    id: 'voice_xian_foodie',
    name: '老陕·同城探店豪爽男声',
    tag: '本地爆款',
    desc: '地道北方汉子腔调，接地气，老饕信赖感拉满',
    pitch: 0.95,
    rate: 1.1,
    sampleText: '先别划走！如果你只知道去网红街，那真亏大了！本地人私藏的小破店，人均几十吃到撑！',
  },
  {
    id: 'voice_xhs_sister',
    name: '元气种草闺蜜女声',
    tag: '小红书高收藏',
    desc: '热情亲切、节奏明快，极易激发女生收藏和种草欲',
    pitch: 1.18,
    rate: 1.05,
    sampleText: '答应我！一定要去试试这家私藏宝藏小馆，碳水脑袋直接沦陷，真的无法超越！',
  },
  {
    id: 'voice_deep_gourmet',
    name: '舌尖纪录片磁性老饕',
    tag: '电影烟火感',
    desc: '低沉浑厚叙事音，充满市井温情与岁月沉淀',
    pitch: 0.85,
    rate: 0.95,
    sampleText: '深巷里的一碗热气腾腾，三十年手艺传承，藏着老街最滚烫的烟火记忆。',
  },
  {
    id: 'voice_streamer_fast',
    name: '千川带货亢奋主播',
    tag: '投流高转化',
    desc: '情绪饱满高亢，直击痛点，促单逼单转化率 TOP1',
    pitch: 1.1,
    rate: 1.25,
    sampleText: '有同样痛点的姐妹闭眼冲！今天这个专属福利机制真的绝了，错过等一年！',
  },
  {
    id: 'voice_humor_fun',
    name: '幽默风趣反转达人',
    tag: '高完播段子',
    desc: '富有网感和幽默起伏，黄金前三秒留存率极高',
    pitch: 1.05,
    rate: 1.15,
    sampleText: '家人们谁懂啊！藏在居民楼底下的这家小破店，排队两小时，第一口直接把我看呆了！',
  },
  {
    id: 'voice_cantonese',
    name: '港风街坊探店男声',
    tag: '老字号情怀',
    desc: '地道老广风味，极具特色的人文美食探店声',
    pitch: 0.92,
    rate: 1.05,
    sampleText: '今日带大家去试下街坊由细食到大嘅宝藏老铺，真正平靓正，食过先知味道绝！',
  },
];

// 6 大通用爆款短视频底层模型
export interface UniversalViralArchetype {
  id: string;
  title: string;
  badge: string;
  category: string;
  formulaShort: string;
  defaultVoiceId: string;
  defaultLut: ShotProConfig['lut'];
  defaultSubtitleStyle: ShotProConfig['subtitleStyle'];
  defaultBgm: string;
  previewThumbnail: string;
}

const UNIVERSAL_VIRAL_ARCHETYPES: UniversalViralArchetype[] = [
  {
    id: 'archetype_cangying_explore',
    title: '同城探店·排队神仙小破店',
    badge: '高赞同城',
    category: '餐饮美食 · 地方小吃',
    formulaShort: '0-3s反常识钩子 + 门头烟火气 + 爆品4K流口水特写 + 超高性价比 + 同城促单',
    defaultVoiceId: 'voice_xian_foodie',
    defaultLut: 'street_fire',
    defaultSubtitleStyle: 'yellow_stroke',
    defaultBgm: '轻快市井烟火卡点调',
    previewThumbnail: 'https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&auto=format&fit=crop',
  },
  {
    id: 'archetype_top_ranking',
    title: '老饕权威合集·无法超越TOP榜',
    badge: '完播率 TOP1',
    category: '多菜品合集 · 权威榜单',
    formulaShort: '权威背书 + 01~04招牌必点排比特写 + 避坑踩雷对比 + 保姆级打卡指南',
    defaultVoiceId: 'voice_xhs_sister',
    defaultLut: 'vivid_food',
    defaultSubtitleStyle: 'yellow_stroke',
    defaultBgm: '国潮动感鼓点卡点律动',
    previewThumbnail: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=800&auto=format&fit=crop',
  },
  {
    id: 'archetype_fanzhuan_bikeng',
    title: '反转避坑·只知道XX就亏大了',
    badge: '高反差留存',
    category: '避坑避雷 · 深度打卡',
    formulaShort: '扎心反问打破认知 + 真实细节揭秘反差 + 独门神仙吃法 + 粉丝专属避雷福利',
    defaultVoiceId: 'voice_humor_fun',
    defaultLut: 'luxury_dark',
    defaultSubtitleStyle: 'variety_pop',
    defaultBgm: '轻快反转节奏BGM',
    previewThumbnail: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop',
  },
  {
    id: 'archetype_ecommerce_conversion',
    title: '沉浸式实测·闭眼冲带货',
    badge: '商业投流',
    category: '美妆日化 · 好物带货',
    formulaShort: '痛点扎心暴击 + 4K微距质感实测 + 使用前后对比 + 限时团购闭眼促单',
    defaultVoiceId: 'voice_streamer_fast',
    defaultLut: 'clean_cool',
    defaultSubtitleStyle: 'yellow_stroke',
    defaultBgm: '清爽活力电音卡点BGM',
    previewThumbnail: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop',
  },
  {
    id: 'archetype_poor_mans_set',
    title: '打工人平价一人食·穷鬼套餐',
    badge: '高互动评论',
    category: '平价简餐 · 团购秒杀',
    formulaShort: '预算敏感痛点 + 满桌盛宴视觉冲击 + 现做现卖烟火气 + 团购优惠一键核销',
    defaultVoiceId: 'voice_xian_foodie',
    defaultLut: 'street_fire',
    defaultSubtitleStyle: 'red_sign',
    defaultBgm: '轻快市井烟火卡点调',
    previewThumbnail: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop',
  },
  {
    id: 'archetype_artisan_story',
    title: '主理人自白·三十年老手艺烟火',
    badge: '情感共鸣',
    category: '老字号 · 匠心传承',
    formulaShort: '凌晨备料市井温情 + 纯手工坚持与匠心微距 + 老街坊口碑 + 情绪共鸣转化',
    defaultVoiceId: 'voice_deep_gourmet',
    defaultLut: 'retro_film',
    defaultSubtitleStyle: 'yellow_stroke',
    defaultBgm: '秦腔与现代电音国潮律动',
    previewThumbnail: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop',
  },
];

// 动态脚本生成器
function generateUniversalViralScript(
  subjectName: string,
  location: string,
  sellingPoint: string,
  archetypeId: string,
  voiceTone: string
) {
  const cleanSubject = subjectName.trim() || '特色神仙小店';
  const cleanLoc = location.trim() || '同城老街深巷';
  const cleanPoint = sellingPoint.trim() || '现做现吃、用料扎实、性价比拉满';

  switch (archetypeId) {
    case 'archetype_top_ranking':
      return {
        name: `【权威TOP榜】${cleanLoc} · ${cleanSubject}无法超越榜首`,
        category: '权威榜单 · 美食攻略',
        bgm: '国潮动感鼓点卡点律动',
        lut: 'vivid_food' as const,
        subtitleStyle: 'yellow_stroke' as const,
        shots: [
          {
            title: '01 榜单开场权威痛点',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: 'TOP 01',
            visualCue: `老饕排队长龙全景，醒目红底大字弹出「${cleanLoc} 权威必吃榜单」徽章。`,
            scriptLine: `这是一份专门给吃货的真诚攻略！本地人从小吃到大的${cleanSubject}，目前真的很难被超越！`,
          },
          {
            title: '02 核心镇店之宝展示',
            duration: 4.0,
            movement: '环绕聚焦' as const,
            transition: '柔光叠化' as const,
            rankBadge: '镇店爆品',
            visualCue: `环绕镜头聚焦${cleanSubject}核心产品，质感饱满，突出「${cleanPoint}」。`,
            scriptLine: `排队也要抢的招牌第一道！${cleanPoint}，一口咬下去层层爆汁超满足！`,
          },
          {
            title: '03 隐藏吃法神仙搭配',
            duration: 4.0,
            movement: '平滑右摇' as const,
            transition: '动感推进' as const,
            rankBadge: '独门神仙吃法',
            visualCue: `展示老食客独家吃法与经典搭配，色泽诱人。`,
            scriptLine: `老饕才知道的隐藏神仙吃法，搭配独家秘制配方，吃一次就彻底沦陷！`,
          },
          {
            title: '04 保姆级收藏闭眼冲',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '硬切卡点' as const,
            rankBadge: '闭眼冲指南',
            visualCue: `全套产品套餐组合入画，屏幕高亮提示点击收藏夹。`,
            scriptLine: `担心划走找不到的赶紧点赞收藏！周末约上搭子直接闭眼冲！`,
          },
        ],
      };

    case 'archetype_fanzhuan_bikeng':
      return {
        name: `【反转避坑】来${cleanLoc}只知道去网红店？这才是真正老字号！`,
        category: '反常识避坑 · 深度打卡',
        bgm: '轻快反转节奏BGM',
        lut: 'luxury_dark' as const,
        subtitleStyle: 'variety_pop' as const,
        shots: [
          {
            title: '01 扎心反问打破认知',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: '避坑防踩雷',
            visualCue: `网红排队商业街打大红叉，镜头瞬间切换至深巷居民楼下的烟火老店。`,
            scriptLine: `如果你在${cleanLoc}还在盲目跟风排网红店，那真是交了学费！本地老餮都在这家${cleanSubject}！`,
          },
          {
            title: '02 真实细节揭秘反差',
            duration: 4.0,
            movement: '平滑右摇' as const,
            transition: '动感推进' as const,
            rankBadge: '现点现做真功夫',
            visualCue: `大特写厨师师傅行云流水的操作与真材实料，突出「${cleanPoint}」。`,
            scriptLine: `没有任何花里胡哨的科技，主打的就是${cleanPoint}，三十年如一日的良心品质！`,
          },
          {
            title: '03 惊艳口感真实特写',
            duration: 4.0,
            movement: '慢速推近' as const,
            transition: '柔光叠化' as const,
            rankBadge: '惊艳全场',
            visualCue: `近景特写食物热气升腾，食客竖起大拇指点赞，眼神满是惊喜。`,
            scriptLine: `第一口下肚就彻底被征服！汤浓料足，这才是让人念念不忘的市井味道！`,
          },
          {
            title: '04 评论区避坑神评互动',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '硬切卡点' as const,
            rankBadge: '粉丝专属福利',
            visualCue: `定格在丰盛菜品，屏幕弹出互动问答「评论区聊聊你踩过的雷」。`,
            scriptLine: `想知道具体坐标的看评论区置顶！你在平时还踩过哪些坑？在评论区告诉我！`,
          },
        ],
      };

    case 'archetype_ecommerce_conversion':
      return {
        name: `【爆款实测】${cleanSubject} · 72h高光实测闭眼冲`,
        category: '电商带货 · 商业投流',
        bgm: '清爽活力电音卡点BGM',
        lut: 'clean_cool' as const,
        subtitleStyle: 'yellow_stroke' as const,
        shots: [
          {
            title: '01 痛点扎心暴击',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: '痛点扎心',
            visualCue: `受众痛点大特写镜头拉近，苦恼表情与日常困扰直击心灵。`,
            scriptLine: `有同样困扰的姐妹快停下！你不是方法不对，是根本没有选对${cleanSubject}！`,
          },
          {
            title: '02 4K微距质感实测',
            duration: 4.0,
            movement: '环绕聚焦' as const,
            transition: '柔光叠化' as const,
            rankBadge: '微距质感',
            visualCue: `4K微距特写展示${cleanSubject}的核心成分与细腻质地，${cleanPoint}。`,
            scriptLine: `这款${cleanSubject}，核心成分拉满，${cleanPoint}，用一次就被彻底惊艳！`,
          },
          {
            title: '03 使用前后高光对比',
            duration: 4.0,
            movement: '平滑右摇' as const,
            transition: '动感推进' as const,
            rankBadge: '实测前后对比',
            visualCue: `分屏对比展示前后颠覆性效果，神采奕奕自信满满。`,
            scriptLine: `实测效果直接封神！状态彻底拉满，连用几天回头率直线上升！`,
          },
          {
            title: '04 专属破价机制促单',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '柔光叠化' as const,
            rankBadge: '闭眼冲限时抢',
            visualCue: `精美礼盒包装与官方大促福利卡弹出，主理人微笑引导点击左下角。`,
            scriptLine: `今天官方破价大促，点击左下角商品卡，支持七天无理由，手慢无直接闭眼冲！`,
          },
        ],
      };

    case 'archetype_poor_mans_set':
      return {
        name: `【平价一人食】在${cleanLoc}人均几十块能吃到什么？穷鬼套餐封神`,
        category: '平价一人食 · 性价比之王',
        bgm: '轻快市井烟火卡点调',
        lut: 'street_fire' as const,
        subtitleStyle: 'red_sign' as const,
        shots: [
          {
            title: '01 穷鬼套餐悬念开场',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: '性价比之王',
            visualCue: `食客拍下整整一桌满当当的美食，大字幕弹出「人均只要两位数？！」`,
            scriptLine: `家人们谁懂啊！在${cleanLoc}人均几十块居然能吃到这么豪横的${cleanSubject}！`,
          },
          {
            title: '02 满桌视觉冲击特写',
            duration: 4.0,
            movement: '全景拉镜' as const,
            transition: '柔光叠化' as const,
            rankBadge: '份量惊人',
            visualCue: `镜头大俯拍整桌菜品，主食、肉类、小吃、饮品样样俱全，突出「${cleanPoint}」。`,
            scriptLine: `主食小吃肉菜满满一整桌，${cleanPoint}，热气腾腾直接给看饿了！`,
          },
          {
            title: '03 真实大口品尝高潮',
            duration: 4.0,
            movement: '慢速推近' as const,
            transition: '动感推进' as const,
            rankBadge: '打工人解药',
            visualCue: `大口咀嚼享受的特写，肉香汁浓，字幕高亮「打工人的深夜灵魂解药」。`,
            scriptLine: `不仅价格良心，味道更是直接封神！下班后来这么一顿，一天的疲惫瞬间全消！`,
          },
          {
            title: '04 团购福利一键核销',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '柔光叠化' as const,
            rankBadge: '限时团购神券',
            visualCue: `手机弹出团购优惠券与门店地址，提示限时立减。`,
            scriptLine: `左下角团购专属神券已经帮你们要到了，随时可退过期自动退，赶紧囤一张！`,
          },
        ],
      };

    case 'archetype_artisan_story':
      return {
        name: `【三十年老手艺】${cleanLoc} · 藏在深巷里的${cleanSubject}`,
        category: '人文老字号 · 匠心口碑',
        bgm: '秦腔与现代电音国潮律动',
        lut: 'retro_film' as const,
        subtitleStyle: 'yellow_stroke' as const,
        shots: [
          {
            title: '01 凌晨清晨市井开门',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: '老字号匠心',
            visualCue: `晨光初照老街深巷，老师傅推开木门，滚烫沸水大锅冒出白茫茫热气。`,
            scriptLine: `在${cleanLoc}的这条老街深巷里，这家${cleanSubject}，三十年如一日只做这一件事！`,
          },
          {
            title: '02 纯手工匠心操作微距',
            duration: 4.0,
            movement: '环绕聚焦' as const,
            transition: '柔光叠化' as const,
            rankBadge: '手艺传承',
            visualCue: `师傅布满老茧的双手机巧制作，每一个动作都充满时光的从容，突出「${cleanPoint}」。`,
            scriptLine: `坚持纯手工制作，${cleanPoint}，每一个细节都透着老手艺人的执着与真诚！`,
          },
          {
            title: '03 老街坊口口相传',
            duration: 4.0,
            movement: '平滑右摇' as const,
            transition: '动感推进' as const,
            rankBadge: '街坊回头客',
            visualCue: `几代食客或老顾客围坐品尝，笑容真挚自然，市井温情满满。`,
            scriptLine: `很多街坊老客是从小吃到大，现在又带着孩子来，吃的就是这口地道的情怀！`,
          },
          {
            title: '04 走心互动招徕到店',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '柔光叠化' as const,
            rankBadge: '老街温度',
            visualCue: `暖色夕阳下的店门招牌全景，屏幕弹出地址导航，文字致敬时光。`,
            scriptLine: `路过${cleanLoc}的朋友，不妨停下脚步来坐坐，给喧闹的生活添一抹滚烫的烟火气！`,
          },
        ],
      };

    case 'archetype_cangying_explore':
    default:
      return {
        name: `【同城探店】${cleanLoc} · 私藏${cleanSubject}合集`,
        category: '同城探店 · 地方特色',
        bgm: '轻快市井烟火卡点调',
        lut: 'street_fire' as const,
        subtitleStyle: 'yellow_stroke' as const,
        shots: [
          {
            title: '01 颠覆认知黄金钩子 (0-3s)',
            duration: 3.5,
            movement: '慢速推近' as const,
            transition: '闪白冲击' as const,
            rankBadge: '同城私藏',
            visualCue: `镜头由远及近推向位于「${cleanLoc}」的${cleanSubject}门头，烟火气升腾，食客络绎不绝。`,
            scriptLine: `先别划走！如果你在${cleanLoc}只知道去网红大店，那真亏大了！本地人私藏的这家${cleanSubject}直接香迷糊！`,
          },
          {
            title: '02 招牌爆品微距特写 (3-7s)',
            duration: 4.0,
            movement: '慢速推近' as const,
            transition: '柔光叠化' as const,
            rankBadge: '必吃招牌',
            visualCue: `4K微距特写${cleanSubject}的招牌核心，${cleanPoint}，热气腾腾油润透亮。`,
            scriptLine: `看这现做现出的招牌，${cleanPoint}，香气直冲脑门，光闻着就流口水！`,
          },
          {
            title: '03 滋滋冒油实测对比 (7-11s)',
            duration: 4.0,
            movement: '平滑右摇' as const,
            transition: '动感推进' as const,
            rankBadge: '高性价比吃撑',
            visualCue: `食客大快朵颐大特写，满满一桌份量扎实，镜头扫过价格牌突出超高性价比。`,
            scriptLine: `份量给得特别足，老板放料根本不手软！人均几十块钱直接吃到扶墙出！`,
          },
          {
            title: '04 评论区同城互动促单 (11-15s)',
            duration: 3.5,
            movement: '固定促单' as const,
            transition: '柔光叠化' as const,
            rankBadge: '保姆级打卡',
            visualCue: `全桌佳肴全景展示，屏幕弹出导航定位与专属福利字卡，主理人热情招手。`,
            scriptLine: `赶紧点赞收藏备用！想去打卡的小伙伴看左下角定位，评论区告诉我你想和谁一起去！`,
          },
        ],
      };
  }
}

export const AIVideoRemixDualStudio: React.FC<AIVideoRemixDualStudioProps> = ({
  initialMode = 'foolproof',
  projectTitle,
  setProjectTitle,
  productName,
  setProductName,
  sellingPoints,
  setSellingPoints,
  category,
  aspectRatio,
  setAspectRatio,
  bgmStyle,
  setBgmStyle,
  voiceTone,
  setVoiceTone,
  cameraAngles,
  setCameraAngles,
  visualCues,
  setVisualCues,
  sceneLines,
  setSceneLines,
  shotDurations,
  setShotDurations,
  shotMovements,
  setShotMovements,
  activeStore,
  onShowNotice,
  onNavigateToEditor,
  onOpenCustomAgentModal,
}) => {
  // Mode: ⚡ 极速套模板成片 vs 🎛️ 工业级微操剪辑台
  const [studioMode, setStudioMode] = useState<RemixStudioMode>(initialMode);
  useEffect(() => {
    if (initialMode) setStudioMode(initialMode);
  }, [initialMode]);

  // Collapsible Advanced Settings Drawer (长条展开/收起效果，杜绝组件文本堆砌)
  const [isConfigDrawerExpanded, setIsConfigDrawerExpanded] = useState<boolean>(false);

  // Inspector Right Panel Tab: 'voice' | 'subtitle' | 'lut' | 'movement'
  const [activeInspectorTab, setActiveInspectorTab] = useState<'voice' | 'subtitle' | 'lut' | 'movement'>('voice');

  // Bottom Timeline Collapsible
  const [isTimelineExpanded, setIsTimelineExpanded] = useState<boolean>(true);

  // Dynamic Subject & Location Inputs
  const [userSubjectName, setUserSubjectName] = useState<string>(productName || '地道老字号小馆');
  const [userLocationTag, setUserLocationTag] = useState<string>(
    activeStore.cityLocation ? `${activeStore.cityLocation} · ${activeStore.storeName}` : '西安 · 碑林区老街深巷'
  );
  const [userSellingPoint, setUserSellingPoint] = useState<string>(
    sellingPoints || '现做现吃、用料扎实、鲜香浓郁人均几十吃撑'
  );

  // Active Universal Archetype
  const [selectedArchetypeId, setSelectedArchetypeId] = useState<string>('archetype_cangying_explore');
  const activeArchetype =
    UNIVERSAL_VIRAL_ARCHETYPES.find((a) => a.id === selectedArchetypeId) || UNIVERSAL_VIRAL_ARCHETYPES[0];

  // Active Voice Persona
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>(activeArchetype.defaultVoiceId);
  const activeVoice =
    AI_VOICE_PERSONAS.find((v) => v.id === selectedVoiceId) || AI_VOICE_PERSONAS[0];

  // Player State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.1);
  const [bgmVolume, setBgmVolume] = useState<number>(0.4);
  const [selectedShotIdx, setSelectedShotIdx] = useState<number>(0);
  const [currentPlayingShotIdx, setCurrentPlayingShotIdx] = useState<number>(0);

  // Batch Remix Modal State (火兔 / 筷子招牌：一键批量裂变10条)
  const [isBatchRemixModalOpen, setIsBatchRemixModalOpen] = useState<boolean>(false);
  const [batchGeneratedVideos, setBatchGeneratedVideos] = useState<
    {
      id: string;
      title: string;
      hookType: string;
      voiceName: string;
      bgm: string;
      coverUrl: string;
      duration: number;
      uniqueScore: number;
    }[]
  >([]);

  // Per-shot configurations
  const [shotProConfigs, setShotProConfigs] = useState<ShotProConfig[]>(() => {
    const initialGenerated = generateUniversalViralScript(
      userSubjectName,
      userLocationTag,
      userSellingPoint,
      selectedArchetypeId,
      voiceTone
    );

    return initialGenerated.shots.map((s, i) => ({
      duration: s.duration,
      movement: s.movement,
      transition: s.transition,
      lut: initialGenerated.lut,
      subtitleStyle: initialGenerated.subtitleStyle,
      subtitleSize: 24,
      subtitlePosY: 0.78,
      customMediaUrl:
        i === 0
          ? 'https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&auto=format&fit=crop'
          : i === 1
          ? 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop'
          : i === 2
          ? 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=800&auto=format&fit=crop'
          : 'https://images.unsplash.com/photo-1552611052-33e04de081de?w=800&auto=format&fit=crop',
      rankBadge: s.rankBadge,
      locationTag: userLocationTag,
    }));
  });

  // Calculate Total Duration
  const totalDuration = shotProConfigs.reduce((acc, c) => acc + (c?.duration || 4.0), 0);

  // Canvas Refs & Caches
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const lastTimestampRef = useRef<number>(0);
  const imageCacheRef = useRef<Record<string, HTMLImageElement>>({});

  // File Upload Ref
  const batchFileInputRef = useRef<HTMLInputElement | null>(null);
  const singleShotFileInputRef = useRef<HTMLInputElement | null>(null);

  // Preload Images into Cache
  const preloadImage = useCallback((url: string) => {
    if (!url || imageCacheRef.current[url]) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = url;
    img.onload = () => {
      imageCacheRef.current[url] = img;
    };
  }, []);

  useEffect(() => {
    shotProConfigs.forEach((c) => {
      if (c.customMediaUrl) preloadImage(c.customMediaUrl);
    });
    UNIVERSAL_VIRAL_ARCHETYPES.forEach((a) => preloadImage(a.previewThumbnail));
  }, [shotProConfigs, preloadImage]);

  // Speech Synthesis Controller
  const isSpeakingRef = useRef<boolean>(false);
  const speakCurrentLine = useCallback(
    (text: string) => {
      if (typeof window === 'undefined' || !window.speechSynthesis || isMuted) return;
      window.speechSynthesis.cancel();
      if (!text.trim()) return;

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = speechRate * (activeVoice.rate || 1.0);
      utterance.pitch = activeVoice.pitch || 1.0;
      utterance.lang = selectedVoiceId === 'voice_cantonese' ? 'zh-HK' : 'zh-CN';

      utterance.onstart = () => {
        isSpeakingRef.current = true;
      };
      utterance.onend = () => {
        isSpeakingRef.current = false;
      };
      utterance.onerror = () => {
        isSpeakingRef.current = false;
      };

      window.speechSynthesis.speak(utterance);
    },
    [isMuted, speechRate, activeVoice, selectedVoiceId]
  );

  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      isSpeakingRef.current = false;
    }
  }, []);

  // Web Audio Context for Authentic BGM
  const audioCtxRef = useRef<AudioContext | null>(null);
  const bgmGainRef = useRef<GainNode | null>(null);

  const initAudioIfNeeded = () => {
    if (!audioCtxRef.current && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        audioCtxRef.current = new AudioCtx();
        bgmGainRef.current = audioCtxRef.current.createGain();
        bgmGainRef.current.gain.value = bgmVolume;
        bgmGainRef.current.connect(audioCtxRef.current.destination);
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  // Dynamic Generator Trigger
  const handleGenerateScriptForUserSubject = (archetypeId = selectedArchetypeId) => {
    const generated = generateUniversalViralScript(
      userSubjectName,
      userLocationTag,
      userSellingPoint,
      archetypeId,
      voiceTone
    );

    setProjectTitle(generated.name);
    setProductName(userSubjectName);
    setSellingPoints(userSellingPoint);
    setBgmStyle(generated.bgm);

    const newAngles = generated.shots.map((s) => s.title);
    const newCues = generated.shots.map((s) => s.visualCue);
    const newLines = generated.shots.map((s) => s.scriptLine);
    const newDurations = generated.shots.map((s) => s.duration);
    const newMovements = generated.shots.map((s) => s.movement);

    setCameraAngles(newAngles);
    setVisualCues(newCues);
    setSceneLines(newLines);
    setShotDurations(newDurations);
    setShotMovements(newMovements);

    setShotProConfigs((prev) => {
      return generated.shots.map((s, idx) => {
        const existingMedia = prev[idx]?.customMediaUrl;
        return {
          duration: s.duration,
          movement: s.movement,
          transition: s.transition,
          lut: generated.lut,
          subtitleStyle: generated.subtitleStyle,
          subtitleSize: 24,
          subtitlePosY: 0.78,
          customMediaUrl:
            existingMedia ||
            (idx === 0
              ? 'https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&auto=format&fit=crop'
              : idx === 1
              ? 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop'
              : idx === 2
              ? 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=800&auto=format&fit=crop'
              : 'https://images.unsplash.com/photo-1552611052-33e04de081de?w=800&auto=format&fit=crop'),
          rankBadge: s.rankBadge,
          locationTag: userLocationTag,
        };
      });
    });

    setCurrentTime(0);
    setSelectedShotIdx(0);
    onShowNotice('success', `已成功为「${userSubjectName}」动态定制生成 4 镜头高转化爆款脚本！`);
  };

  const handleSelectArchetype = (archetype: UniversalViralArchetype) => {
    setSelectedArchetypeId(archetype.id);
    setSelectedVoiceId(archetype.defaultVoiceId);
    handleGenerateScriptForUserSubject(archetype.id);
  };

  // Batch Photo Upload
  const handleBatchFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileList = Array.from(files);
    const readUrls: string[] = [];
    let loadedCount = 0;

    fileList.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (loadEvent) => {
        const result = loadEvent.target?.result as string;
        if (result) {
          readUrls.push(result);
          preloadImage(result);
        }
        loadedCount++;
        if (loadedCount === fileList.length) {
          setShotProConfigs((prev) => {
            const next = [...prev];
            readUrls.forEach((url, i) => {
              if (i < next.length) {
                next[i] = {
                  ...next[i],
                  customMediaUrl: url,
                };
              } else {
                next.push({
                  duration: 3.5,
                  movement: '慢速推近',
                  transition: '柔光叠化',
                  lut: activeArchetype.defaultLut,
                  subtitleStyle: activeArchetype.defaultSubtitleStyle,
                  subtitleSize: 24,
                  subtitlePosY: 0.78,
                  customMediaUrl: url,
                  rankBadge: `实拍 0${next.length + 1}`,
                  locationTag: userLocationTag,
                });
              }
            });
            return next;
          });

          if (readUrls.length > cameraAngles.length) {
            const extraCount = readUrls.length - cameraAngles.length;
            const extraAngles = Array.from(
              { length: extraCount },
              (_, k) => `实拍镜头 0${cameraAngles.length + k + 1}`
            );
            const extraLines = Array.from(
              { length: extraCount },
              () => `看这【${userSubjectName}】的真实细节，色泽诱人，让人食指大动！`
            );
            const extraCues = Array.from(
              { length: extraCount },
              () => `实拍素材特写镜头，微动视差放大细节，突出「${userSellingPoint}」。`
            );

            setCameraAngles([...cameraAngles, ...extraAngles]);
            setSceneLines([...sceneLines, ...extraLines]);
            setVisualCues([...visualCues, ...extraCues]);
          }

          onShowNotice(
            'success',
            `已成功导入 ${readUrls.length} 张实拍杂片素材，AI 已自动裁切 9:16 并赋予 2.5D 视差微动！`
          );
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Single Shot Replace
  const handleSingleShotPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const res = evt.target?.result as string;
      if (res) {
        preloadImage(res);
        setShotProConfigs((prev) => {
          const next = [...prev];
          if (next[selectedShotIdx]) {
            next[selectedShotIdx] = {
              ...next[selectedShotIdx],
              customMediaUrl: res,
            };
          }
          return next;
        });
        onShowNotice('success', `已成功替换第 0${selectedShotIdx + 1} 镜的实拍素材！`);
      }
    };
    reader.readAsDataURL(file);
  };

  const getActiveShotAtTime = (t: number) => {
    let accumulated = 0;
    for (let i = 0; i < shotProConfigs.length; i++) {
      const dur = shotProConfigs[i]?.duration || 4.0;
      if (t >= accumulated && t < accumulated + dur) {
        return { index: i, localTime: t - accumulated, duration: dur };
      }
      accumulated += dur;
    }
    const lastIdx = Math.max(0, shotProConfigs.length - 1);
    return {
      index: lastIdx,
      localTime: shotProConfigs[lastIdx]?.duration || 4.0,
      duration: shotProConfigs[lastIdx]?.duration || 4.0,
    };
  };

  // Draw Canvas
  const drawCanvas = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const W = canvas.width;
      const H = canvas.height;

      const { index: sceneIndex, localTime, duration } = getActiveShotAtTime(t);
      const cfg = shotProConfigs[sceneIndex] || shotProConfigs[0];
      const progress = Math.min(1, Math.max(0, localTime / duration));

      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#0b0f19';
      ctx.fillRect(0, 0, W, H);

      // Ken Burns Transform
      const customUrl = cfg?.customMediaUrl;
      const cachedImg = customUrl ? imageCacheRef.current[customUrl] : undefined;

      ctx.save();
      let scale = 1.0;
      let offsetX = 0;
      let offsetY = 0;

      if (cfg.movement === '慢速推近') {
        scale = 1.0 + 0.16 * progress;
      } else if (cfg.movement === '全景拉镜') {
        scale = 1.16 - 0.16 * progress;
      } else if (cfg.movement === '平滑右摇') {
        scale = 1.08;
        offsetX = (progress - 0.5) * 48;
      } else if (cfg.movement === '环绕聚焦') {
        scale = 1.06 + 0.04 * Math.sin(progress * Math.PI);
        offsetY = Math.cos(progress * Math.PI) * 16;
      } else {
        scale = 1.04;
      }

      ctx.translate(W / 2 + offsetX, H / 2 + offsetY);
      ctx.scale(scale, scale);
      ctx.translate(-W / 2, -H / 2);

      if (cachedImg && cachedImg.complete && cachedImg.naturalWidth > 0) {
        const imgRatio = cachedImg.naturalWidth / cachedImg.naturalHeight;
        const canvasRatio = W / H;
        let drawW = W;
        let drawH = H;
        if (imgRatio > canvasRatio) {
          drawH = H;
          drawW = H * imgRatio;
        } else {
          drawW = W;
          drawH = W / imgRatio;
        }
        ctx.drawImage(cachedImg, (W - drawW) / 2, (H - drawH) / 2, drawW, drawH);
      } else {
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, '#1e293b');
        grad.addColorStop(0.5, '#334155');
        grad.addColorStop(1, '#0f172a');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);
      }

      // Color LUT Grading Layer
      if (cfg.lut === 'street_fire') {
        ctx.fillStyle = 'rgba(249, 115, 22, 0.16)';
        ctx.fillRect(0, 0, W, H);
      } else if (cfg.lut === 'vivid_food') {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.14)';
        ctx.fillRect(0, 0, W, H);
      } else if (cfg.lut === 'retro_film') {
        ctx.fillStyle = 'rgba(234, 179, 8, 0.15)';
        ctx.fillRect(0, 0, W, H);
      } else if (cfg.lut === 'clean_cool') {
        ctx.fillStyle = 'rgba(56, 189, 248, 0.12)';
        ctx.fillRect(0, 0, W, H);
      } else if (cfg.lut === 'luxury_dark') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.3)';
        ctx.fillRect(0, 0, W, H);
      }
      ctx.restore();

      // Scrims
      const topScrim = ctx.createLinearGradient(0, 0, 0, 160);
      topScrim.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
      topScrim.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = topScrim;
      ctx.fillRect(0, 0, W, 160);

      const bottomScrim = ctx.createLinearGradient(0, H - 240, 0, H);
      bottomScrim.addColorStop(0, 'rgba(0, 0, 0, 0)');
      bottomScrim.addColorStop(1, 'rgba(0, 0, 0, 0.85)');
      ctx.fillStyle = bottomScrim;
      ctx.fillRect(0, H - 240, W, 240);

      // Top Location Pin
      const locationText = cfg.locationTag || userLocationTag;
      ctx.save();
      ctx.fillStyle = 'rgba(15, 23, 42, 0.84)';
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(24, 26, W - 48, 36, 18);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#fde047';
      ctx.font = '700 13px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('📍 ' + locationText, 38, 49);

      ctx.fillStyle = '#ffffff';
      ctx.font = '600 12px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`0${sceneIndex + 1} / 0${shotProConfigs.length}`, W - 38, 49);
      ctx.restore();

      // Rank Badge
      if (cfg.rankBadge) {
        ctx.save();
        ctx.fillStyle = '#ef4444';
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(26, 74, 105, 30, 8);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '800 13px "PingFang SC", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(cfg.rankBadge, 78, 94);
        ctx.restore();
      }

      // Transition FX
      if (localTime < 0.35) {
        const transAlpha = 1 - localTime / 0.35;
        if (cfg.transition === '闪白冲击') {
          ctx.fillStyle = `rgba(255, 255, 255, ${transAlpha * 0.75})`;
          ctx.fillRect(0, 0, W, H);
        } else if (cfg.transition === '柔光叠化') {
          ctx.fillStyle = `rgba(15, 23, 42, ${transAlpha * 0.55})`;
          ctx.fillRect(0, 0, W, H);
        }
      }

      // Karaoke Subtitle
      const spokenLine = sceneLines[sceneIndex] || '';
      const subCenterY = Math.round(H * (cfg.subtitlePosY || 0.78));
      const fontSize = cfg.subtitleSize || 23;

      ctx.save();
      ctx.font = `800 ${fontSize}px "PingFang SC", "Heiti SC", sans-serif`;
      ctx.textAlign = 'center';

      const maxLineWidth = W - 52;
      const words = spokenLine;
      const lines: string[] = [];
      let currentLine = '';
      for (let i = 0; i < words.length; i++) {
        const testLine = currentLine + words[i];
        if (ctx.measureText(testLine).width > maxLineWidth) {
          lines.push(currentLine);
          currentLine = words[i];
        } else {
          currentLine = testLine;
        }
      }
      if (currentLine) lines.push(currentLine);

      const boxHeight = Math.max(72, lines.length * (fontSize + 12) + 24);
      const boxTop = subCenterY - boxHeight / 2;

      if (cfg.subtitleStyle === 'yellow_stroke') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.roundRect(20, boxTop, W - 40, boxHeight, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#fef08a';
        lines.forEach((l, idx) => {
          ctx.fillText(l, W / 2, boxTop + 32 + idx * (fontSize + 10));
        });
      } else if (cfg.subtitleStyle === 'red_sign') {
        ctx.fillStyle = 'rgba(220, 38, 38, 0.94)';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.roundRect(20, boxTop, W - 40, boxHeight, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        lines.forEach((l, idx) => {
          ctx.fillText(l, W / 2, boxTop + 32 + idx * (fontSize + 10));
        });
      } else {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.78)';
        ctx.beginPath();
        ctx.roundRect(24, boxTop, W - 48, boxHeight, 14);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        lines.forEach((l, idx) => {
          ctx.fillText(l, W / 2, boxTop + 32 + idx * (fontSize + 10));
        });
      }
      ctx.restore();

      // Audio Waveform Simulator Indicator
      ctx.save();
      const waveBarCount = 20;
      const waveStartX = W / 2 - (waveBarCount * 6) / 2;
      for (let b = 0; b < waveBarCount; b++) {
        const barHeight = 4 + 14 * Math.abs(Math.sin((t * 6 + b * 0.4)));
        ctx.fillStyle = isPlaying ? '#38bdf8' : 'rgba(255, 255, 255, 0.3)';
        ctx.fillRect(waveStartX + b * 6, H - 40 - barHeight / 2, 3, barHeight);
      }
      ctx.restore();
    },
    [shotProConfigs, sceneLines, userLocationTag, isPlaying]
  );

  // Play loop
  const playLoop = useCallback(
    (timestamp: number) => {
      if (!lastTimestampRef.current) lastTimestampRef.current = timestamp;
      const delta = (timestamp - lastTimestampRef.current) / 1000;
      lastTimestampRef.current = timestamp;

      setCurrentTime((prevTime) => {
        const nextTime = prevTime + delta;
        if (nextTime >= totalDuration) {
          return 0;
        }
        return nextTime;
      });

      animFrameIdRef.current = requestAnimationFrame(playLoop);
    },
    [totalDuration]
  );

  useEffect(() => {
    const { index } = getActiveShotAtTime(currentTime);
    if (index !== currentPlayingShotIdx) {
      setCurrentPlayingShotIdx(index);
      if (isPlaying) {
        const nextLine = sceneLines[index] || '';
        speakCurrentLine(nextLine);
      }
    }
  }, [currentTime, currentPlayingShotIdx, isPlaying, sceneLines, speakCurrentLine]);

  const togglePlay = () => {
    initAudioIfNeeded();
    if (isPlaying) {
      setIsPlaying(false);
      stopSpeaking();
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    } else {
      setIsPlaying(true);
      lastTimestampRef.current = 0;
      animFrameIdRef.current = requestAnimationFrame(playLoop);
      const { index } = getActiveShotAtTime(currentTime);
      const curLine = sceneLines[index] || '';
      speakCurrentLine(curLine);
    }
  };

  useEffect(() => {
    drawCanvas(currentTime);
  }, [currentTime, drawCanvas]);

  useEffect(() => {
    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      stopSpeaking();
    };
  }, [stopSpeaking]);

  const handleTestVoice = (voice: AIVoicePersona) => {
    setSelectedVoiceId(voice.id);
    speakCurrentLine(voice.sampleText);
    onShowNotice('success', `正在试听「${voice.name}」真人语音...`);
  };

  const handleTriggerBatchRemix = () => {
    window.location.assign('/');
  };

  const handleExportVideo = () => {
    window.location.assign('/');
  };

  return (
    <div className="w-full space-y-4">
      {/* 1. Sleek Cybernetic Header Capsule (合并精简为一维极简高科技条，彻底消除元素堆砌) */}
      <header className="rounded-2xl border border-slate-800/80 bg-slate-950/90 p-3 sm:p-4 text-slate-100 shadow-[0_8px_30px_rgb(0,0,0,0.12)] backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          {/* Left Brand & Quick Title Pill */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white shadow-md shadow-cyan-500/20">
              <Film className="h-5 w-5" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <input
                  type="text"
                  value={projectTitle}
                  onChange={(e) => setProjectTitle(e.target.value)}
                  className="font-bold text-white text-sm sm:text-base hover:text-cyan-300 focus:outline-none focus:text-cyan-300 bg-transparent truncate max-w-sm"
                />
                <span className="rounded-full bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 text-[10px] font-mono text-cyan-300">
                  4K 视差渲染
                </span>
                <span className="rounded-full bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-mono text-emerald-300">
                  🎙️ {activeVoice.name.split('·')[0]}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 truncate flex items-center gap-2 mt-0.5">
                <span>主体: <strong className="text-slate-200">{userSubjectName}</strong></span>
                <span className="text-slate-600">·</span>
                <span>模型: <strong className="text-indigo-300">{activeArchetype.title.slice(0, 14)}</strong></span>
              </div>
            </div>
          </div>

          {/* Right Action Capsule */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {/* Custom AI Agent & RAG Modal Opener */}
            {onOpenCustomAgentModal && (
              <button
                type="button"
                onClick={onOpenCustomAgentModal}
                className="inline-flex items-center gap-1.5 rounded-xl border border-cyan-500/30 bg-cyan-950/40 px-3 py-1.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-900/40 transition-colors cursor-pointer"
                title="打开个性化自定义 AI 智能体与 RAG 建立工作台"
              >
                <BrainCircuit className="h-3.5 w-3.5 text-cyan-400" />
                <span>自定义智能体/RAG</span>
              </button>
            )}

            {/* Hidden Input for Files */}
            <input
              ref={batchFileInputRef}
              type="file"
              multiple
              accept="image/*,video/*"
              onChange={handleBatchFileUpload}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => batchFileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
              title="批量导入随手拍照片/视频"
            >
              <Upload className="h-3.5 w-3.5 text-sky-400" />
              <span>导入杂片</span>
            </button>

            <button
              type="button"
              onClick={() => handleGenerateScriptForUserSubject()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:brightness-110 transition-all cursor-pointer"
              title="AI 针对当前主体与模型一键生成爆款脚本"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>智能成片</span>
            </button>

            <button
              type="button"
              onClick={handleTriggerBatchRemix}
              className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:brightness-110 transition-all cursor-pointer"
              title="批量生成 10 条原创差异化视频"
            >
              <Flame className="h-3.5 w-3.5" />
              <span>批量裂变10条</span>
            </button>

            <button
              type="button"
              onClick={handleExportVideo}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-indigo-500 transition-colors cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>导出4K</span>
            </button>

            {/* Collapsible Parameters Button (长条展开/收起效果) */}
            <button
              type="button"
              onClick={() => setIsConfigDrawerExpanded(!isConfigDrawerExpanded)}
              className="inline-flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-900/80 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
              title={isConfigDrawerExpanded ? '收起配置' : '展开参数配置'}
            >
              <Settings2 className="h-3.5 w-3.5 text-slate-400" />
              <span>{isConfigDrawerExpanded ? '收起配置' : '配置'}</span>
              {isConfigDrawerExpanded ? (
                <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
              )}
            </button>
          </div>
        </div>

        {/* 2. Collapsible Extended Parameters & Models (长条抽屉展开效果，默认可收起，保持极简大气) */}
        {isConfigDrawerExpanded && (
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-4 animate-in fade-in slide-in-from-top-2 duration-150">
            {/* Input Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  店名 / 商品 / 拍摄主体
                </label>
                <input
                  type="text"
                  value={userSubjectName}
                  onChange={(e) => setUserSubjectName(e.target.value)}
                  placeholder="如：阿强牛肉火锅 / 星澜洗发水"
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  同城定位 / 商圈坐标
                </label>
                <input
                  type="text"
                  value={userLocationTag}
                  onChange={(e) => setUserLocationTag(e.target.value)}
                  placeholder="如：西安 · 碑林区老店 / 成都 · 春熙路"
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  核心特色 / 招牌 / 爆款痛点
                </label>
                <input
                  type="text"
                  value={userSellingPoint}
                  onChange={(e) => setUserSellingPoint(e.target.value)}
                  placeholder="如：现切鲜牛肉、熬制6小时高汤、人均40吃撑"
                  className="w-full rounded-xl border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* Archetype Strip (横向长条极简选择器，杜绝卡片文本堆砌) */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-slate-400">选择 6 大万能爆款短视频底层模型：</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                {UNIVERSAL_VIRAL_ARCHETYPES.map((arch) => {
                  const active = selectedArchetypeId === arch.id;
                  return (
                    <button
                      key={arch.id}
                      type="button"
                      onClick={() => handleSelectArchetype(arch)}
                      className={`flex flex-col text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                        active
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200 shadow-xs'
                          : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] mb-1">
                        <span className="font-bold text-white truncate">{arch.badge}</span>
                        {active && <Check className="h-3 w-3 text-cyan-400" />}
                      </div>
                      <div className="text-xs font-semibold truncate text-slate-200">{arch.title}</div>
                      <div className="text-[9px] text-slate-500 line-clamp-1 mt-0.5">{arch.category}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* 3. Main Workspace: 3-Column Studio (Left Footage -> Center Sci-Fi Canvas -> Right Tabbed Inspector) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* LEFT COLUMN: Footage Pool & Shot Clips */}
        <div className="lg:col-span-3 space-y-3">
          <div className="rounded-2xl border border-slate-800/80 bg-slate-950/80 p-3.5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                <Layers className="h-3.5 w-3.5 text-cyan-400" />
                <span>分镜片段 ({shotProConfigs.length} 镜)</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  const newIdx = shotProConfigs.length + 1;
                  const newCfg: ShotProConfig = {
                    duration: 3.5,
                    movement: '慢速推近',
                    transition: '柔光叠化',
                    lut: activeArchetype.defaultLut,
                    subtitleStyle: activeArchetype.defaultSubtitleStyle,
                    subtitleSize: 24,
                    subtitlePosY: 0.78,
                    customMediaUrl:
                      shotProConfigs[0]?.customMediaUrl || activeArchetype.previewThumbnail,
                    rankBadge: `SHOT 0${newIdx}`,
                    locationTag: userLocationTag,
                  };
                  setShotProConfigs((prev) => [...prev, newCfg]);
                  setCameraAngles([...cameraAngles, `新增镜头 0${newIdx}`]);
                  setSceneLines([...sceneLines, `看这【${userSubjectName}】的真材实料，色泽诱人！`]);
                  setVisualCues([...visualCues, '实拍高画质微距特写画面']);
                  onShowNotice('success', `已添加第 0${newIdx} 个新分镜！`);
                }}
                className="inline-flex items-center gap-1 rounded-lg bg-slate-900 border border-slate-800 px-2 py-0.5 text-[11px] font-bold text-cyan-400 hover:bg-slate-800 cursor-pointer"
              >
                <Plus className="h-3 w-3" />
                <span>加镜头</span>
              </button>
            </div>

            {/* Quick Upload Strip */}
            <div
              onClick={() => batchFileInputRef.current?.click()}
              className="rounded-xl border border-dashed border-slate-800 bg-slate-900/50 p-2.5 text-center hover:border-cyan-500/50 hover:bg-slate-900 transition-all cursor-pointer"
            >
              <Upload className="mx-auto h-4 w-4 text-cyan-400 mb-0.5" />
              <div className="text-[11px] font-bold text-slate-200">批量上传随手拍杂片</div>
              <p className="text-[9px] text-slate-500">自动裁剪 9:16 + 2.5D 视差微动</p>
            </div>

            {/* Hidden Single Shot File Input */}
            <input
              ref={singleShotFileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleSingleShotPhotoUpload}
              className="hidden"
            />

            {/* Shot List */}
            <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
              {shotProConfigs.map((cfg, idx) => {
                const isSelected = selectedShotIdx === idx;
                const isCurrentPlaying = currentPlayingShotIdx === idx;
                const angleTitle = cameraAngles[idx] || `分镜 0${idx + 1}`;
                const spoken = sceneLines[idx] || '';

                return (
                  <div
                    key={idx}
                    onClick={() => {
                      setSelectedShotIdx(idx);
                      let startT = 0;
                      for (let k = 0; k < idx; k++) {
                        startT += shotProConfigs[k]?.duration || 4.0;
                      }
                      setCurrentTime(startT);
                    }}
                    className={`relative rounded-xl border p-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-cyan-500/80 bg-slate-900 shadow-xs ring-1 ring-cyan-500/50'
                        : 'border-slate-800/80 bg-slate-900/40 hover:bg-slate-900/80'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <div className="relative h-14 w-10 shrink-0 overflow-hidden rounded-lg bg-slate-950 border border-slate-800">
                        {cfg.customMediaUrl ? (
                          <img
                            src={cfg.customMediaUrl}
                            alt={angleTitle}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-[9px] font-bold text-slate-400">
                            0{idx + 1}
                          </div>
                        )}
                        {isCurrentPlaying && isPlaying && (
                          <div className="absolute inset-0 bg-cyan-500/30 flex items-center justify-center">
                            <span className="flex h-2 w-2 rounded-full bg-white animate-ping" />
                          </div>
                        )}
                        <span className="absolute bottom-0.5 right-0.5 rounded bg-black/80 px-1 text-[8px] font-mono text-white">
                          {cfg.duration}s
                        </span>
                      </div>

                      <div className="flex-1 min-w-0 text-left">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[11px] text-white truncate">
                            0{idx + 1} {angleTitle}
                          </span>
                          <span className="text-[9px] text-slate-400 font-mono">{cfg.movement}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{spoken}</p>
                        <div className="mt-1 flex items-center gap-2 text-[9px] text-slate-500">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedShotIdx(idx);
                              singleShotFileInputRef.current?.click();
                            }}
                            className="text-cyan-400 hover:underline cursor-pointer"
                          >
                            换素材
                          </button>
                          <span>·</span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (shotProConfigs.length <= 1) {
                                onShowNotice('error', '至少保留一个分镜镜头！');
                                return;
                              }
                              setShotProConfigs((prev) => prev.filter((_, i) => i !== idx));
                              setCameraAngles(cameraAngles.filter((_, i) => i !== idx));
                              setSceneLines(sceneLines.filter((_, i) => i !== idx));
                              setVisualCues(visualCues.filter((_, i) => i !== idx));
                              setSelectedShotIdx(Math.max(0, idx - 1));
                            }}
                            className="text-red-400 hover:underline cursor-pointer"
                          >
                            删除
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* CENTER COLUMN: Futuristic 9:16 Canvas Phone Player */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full max-w-[330px] flex flex-col items-center space-y-3">
            {/* Aspect Ratio Switch */}
            <div className="w-full flex items-center justify-between text-xs text-slate-400 px-1">
              <span className="flex items-center gap-1.5 font-bold text-slate-200">
                <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
                <span>实时真机渲染</span>
              </span>
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
                {(['9:16', '16:9', '4:3'] as const).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-md transition-colors cursor-pointer ${
                      aspectRatio === ratio
                        ? 'bg-cyan-500 text-slate-950 shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            {/* Glowing Futuristic Phone Frame */}
            <div className="relative w-full aspect-[9/16] rounded-[34px] bg-slate-950 p-2.5 shadow-[0_0_50px_-10px_rgba(99,102,241,0.25)] border-2 border-slate-800 overflow-hidden group">
              <div className="absolute top-3.5 left-1/2 -translate-x-1/2 h-3 w-20 rounded-full bg-black z-20" />
              <div className="relative h-full w-full rounded-[24px] overflow-hidden bg-black">
                <canvas
                  ref={canvasRef}
                  width={360}
                  height={640}
                  className="h-full w-full object-contain cursor-pointer"
                  onClick={togglePlay}
                />
                {!isPlaying && (
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="absolute inset-0 m-auto h-14 w-14 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-xs hover:scale-110 transition-transform cursor-pointer z-10 border border-white/20 shadow-lg shadow-black/40"
                  >
                    <Play className="h-7 w-7 ml-0.5 text-white fill-white" />
                  </button>
                )}
              </div>
            </div>

            {/* Sleek Floating Player Transport Bar */}
            <div className="w-full rounded-2xl border border-slate-800/80 bg-slate-950/90 p-3 shadow-md space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="font-bold text-cyan-400">{currentTime.toFixed(1)}s</span>
                <span className="text-slate-500">/ {totalDuration.toFixed(1)}s</span>
              </div>

              <input
                type="range"
                min={0}
                max={Math.max(0.1, totalDuration)}
                step={0.1}
                value={currentTime}
                onChange={(e) => setCurrentTime(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCurrentTime(0)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                    title="重置"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const prevIdx = Math.max(0, selectedShotIdx - 1);
                      setSelectedShotIdx(prevIdx);
                      let startT = 0;
                      for (let k = 0; k < prevIdx; k++) {
                        startT += shotProConfigs[k]?.duration || 4.0;
                      }
                      setCurrentTime(startT);
                    }}
                    className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                    title="上一镜"
                  >
                    <SkipBack className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 text-slate-950 hover:brightness-110 cursor-pointer shadow-xs"
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5 fill-slate-950" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const nextIdx = Math.min(shotProConfigs.length - 1, selectedShotIdx + 1);
                      setSelectedShotIdx(nextIdx);
                      let startT = 0;
                      for (let k = 0; k < nextIdx; k++) {
                        startT += shotProConfigs[k]?.duration || 4.0;
                      }
                      setCurrentTime(startT);
                    }}
                    className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                    title="下一镜"
                  >
                    <SkipForward className="h-3.5 w-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                  >
                    {isMuted ? <VolumeX className="h-3.5 w-3.5 text-red-400" /> : <Volume2 className="h-3.5 w-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const line = sceneLines[selectedShotIdx] || '';
                      speakCurrentLine(line);
                      onShowNotice('success', `正在试听第 0${selectedShotIdx + 1} 镜真人配音...`);
                    }}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 px-2 py-1 text-[11px] font-bold text-cyan-300 hover:bg-slate-800 cursor-pointer"
                  >
                    <Mic className="h-3 w-3" />
                    <span>试听口播</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Tabbed Inspector (抽屉式分类精调，彻底消除纵向文本堆砌) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="rounded-2xl border border-slate-800/80 bg-slate-950/80 p-4 shadow-sm space-y-4">
            {/* Inspector Header & Segmented Tabs */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <SlidersHorizontal className="h-3.5 w-3.5 text-cyan-400" />
                <span>第 0{selectedShotIdx + 1} 镜精调</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {cameraAngles[selectedShotIdx] || '分镜'}
              </span>
            </div>

            {/* 4 Segmented Tabs */}
            <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-[11px]">
              {[
                { id: 'voice', label: '配音', icon: Mic },
                { id: 'subtitle', label: '文案', icon: Type },
                { id: 'lut', label: '滤镜', icon: Palette },
                { id: 'movement', label: '运镜', icon: Compass },
              ].map((tab) => {
                const Icon = tab.icon;
                const active = activeInspectorTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveInspectorTab(tab.id as typeof activeInspectorTab)}
                    className={`flex items-center justify-center gap-1 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                      active
                        ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Icon className="h-3 w-3" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab 1: AI 真人配音 */}
            {activeInspectorTab === 'voice' && (
              <div className="space-y-3 animate-in fade-in duration-150">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-semibold">选择真人音色库</span>
                  <span className="text-cyan-400 text-[11px] font-bold">{activeVoice.name}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {AI_VOICE_PERSONAS.map((voice) => {
                    const active = selectedVoiceId === voice.id;
                    return (
                      <button
                        key={voice.id}
                        type="button"
                        onClick={() => handleTestVoice(voice)}
                        className={`text-left p-2 rounded-xl border transition-all cursor-pointer ${
                          active
                            ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                            : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px] mb-0.5">
                          <span className="font-bold truncate text-white">{voice.name.split('·')[0]}</span>
                          <span className="rounded bg-slate-800 px-1 text-[8px] text-slate-400 shrink-0">
                            {voice.tag}
                          </span>
                        </div>
                        <p className="text-[9px] text-slate-500 line-clamp-1">{voice.desc}</p>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
                  <span>语速调节 ({speechRate.toFixed(2)}x)</span>
                  <input
                    type="range"
                    min={0.8}
                    max={1.4}
                    step={0.05}
                    value={speechRate}
                    onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                    className="w-28 accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded"
                  />
                </div>
              </div>
            )}

            {/* Tab 2: 本镜文案与花字 */}
            {activeInspectorTab === 'subtitle' && (
              <div className="space-y-3 animate-in fade-in duration-150">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-slate-300">口播字幕台词</span>
                  <textarea
                    rows={3}
                    value={sceneLines[selectedShotIdx] || ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      const next = [...sceneLines];
                      next[selectedShotIdx] = val;
                      setSceneLines(next);
                    }}
                    className="w-full rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-xs text-white placeholder-slate-600 focus:border-cyan-400 focus:outline-none"
                    placeholder="输入本镜台词，播放时真人自动朗读..."
                  />
                </div>

                <div className="space-y-1.5 pt-1">
                  <span className="text-xs font-semibold text-slate-300">花字样式选择</span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: 'yellow_stroke', label: '网感黄字' },
                      { id: 'red_sign', label: '红底招牌' },
                      { id: 'variety_pop', label: '综艺爆梗' },
                      { id: 'white_minimal', label: '极简白底' },
                    ].map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => {
                          setShotProConfigs((prev) => {
                            const next = [...prev];
                            if (next[selectedShotIdx]) {
                              next[selectedShotIdx] = {
                                ...next[selectedShotIdx],
                                subtitleStyle: st.id as ShotProConfig['subtitleStyle'],
                              };
                            }
                            return next;
                          });
                        }}
                        className={`py-1.5 text-[10px] rounded-lg font-bold border transition-colors cursor-pointer text-center ${
                          shotProConfigs[selectedShotIdx]?.subtitleStyle === st.id
                            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: 电影 LUT 滤镜 */}
            {activeInspectorTab === 'lut' && (
              <div className="space-y-3 animate-in fade-in duration-150">
                <span className="text-xs font-semibold text-slate-300">电影级调色滤镜 (LUT)</span>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { id: 'street_fire', label: '市井烟火' },
                    { id: 'vivid_food', label: '高饱和' },
                    { id: 'retro_film', label: '复古胶片' },
                    { id: 'clean_cool', label: '清冷冷调' },
                    { id: 'luxury_dark', label: '黑金质感' },
                  ].map((l) => (
                    <button
                      key={l.id}
                      type="button"
                      onClick={() => {
                        setShotProConfigs((prev) => {
                          const next = [...prev];
                          if (next[selectedShotIdx]) {
                            next[selectedShotIdx] = {
                              ...next[selectedShotIdx],
                              lut: l.id as ShotProConfig['lut'],
                            };
                          }
                          return next;
                        });
                      }}
                      className={`py-1.5 text-[10px] rounded-lg font-medium border transition-colors cursor-pointer text-center ${
                        shotProConfigs[selectedShotIdx]?.lut === l.id
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 font-bold'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {l.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Tab 4: 运镜与转场 */}
            {activeInspectorTab === 'movement' && (
              <div className="space-y-3 animate-in fade-in duration-150">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-slate-300">
                    本镜时长 ({shotProConfigs[selectedShotIdx]?.duration || 4.0}s)
                  </span>
                  <input
                    type="range"
                    min={2.0}
                    max={8.0}
                    step={0.5}
                    value={shotProConfigs[selectedShotIdx]?.duration || 4.0}
                    onChange={(e) => {
                      const dur = parseFloat(e.target.value);
                      setShotProConfigs((prev) => {
                        const next = [...prev];
                        if (next[selectedShotIdx]) {
                          next[selectedShotIdx] = {
                            ...next[selectedShotIdx],
                            duration: dur,
                          };
                        }
                        return next;
                      });
                    }}
                    className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 block mb-1">运镜方式</span>
                    <select
                      value={shotProConfigs[selectedShotIdx]?.movement || '慢速推近'}
                      onChange={(e) => {
                        const mv = e.target.value as ShotProConfig['movement'];
                        setShotProConfigs((prev) => {
                          const next = [...prev];
                          if (next[selectedShotIdx]) {
                            next[selectedShotIdx] = {
                              ...next[selectedShotIdx],
                              movement: mv,
                            };
                          }
                          return next;
                        });
                      }}
                      className="w-full rounded-xl border border-slate-800 bg-slate-900 p-1.5 text-xs text-white focus:outline-none"
                    >
                      <option value="慢速推近">慢速推近</option>
                      <option value="全景拉镜">全景拉镜</option>
                      <option value="平滑右摇">平滑右摇</option>
                      <option value="环绕聚焦">环绕聚焦</option>
                      <option value="固定促单">固定促单</option>
                    </select>
                  </div>

                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 block mb-1">切镜转场</span>
                    <select
                      value={shotProConfigs[selectedShotIdx]?.transition || '柔光叠化'}
                      onChange={(e) => {
                        const tr = e.target.value as ShotProConfig['transition'];
                        setShotProConfigs((prev) => {
                          const next = [...prev];
                          if (next[selectedShotIdx]) {
                            next[selectedShotIdx] = {
                              ...next[selectedShotIdx],
                              transition: tr,
                            };
                          }
                          return next;
                        });
                      }}
                      className="w-full rounded-xl border border-slate-800 bg-slate-900 p-1.5 text-xs text-white focus:outline-none"
                    >
                      <option value="柔光叠化">柔光叠化</option>
                      <option value="闪白冲击">闪白冲击</option>
                      <option value="动感推进">动感推进</option>
                      <option value="硬切卡点">硬切卡点</option>
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 4. Collapsible Multi-Track Timeline (可收起/展开的极简多轨时间轴) */}
      <section className="rounded-2xl border border-slate-800/80 bg-slate-950/80 p-3.5 sm:p-4 text-slate-100 shadow-sm space-y-2">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
          <div className="flex items-center gap-2">
            <span className="flex h-5 w-5 items-center justify-center rounded-lg bg-indigo-600 text-white text-[10px] font-bold">
              Timeline
            </span>
            <span className="text-xs font-bold text-white">多轨精细时间轴</span>
            <span className="text-[10px] text-slate-500">点击时间块定位播放头</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs font-mono text-slate-400">
              播放头: <strong className="text-cyan-400">{currentTime.toFixed(2)}s</strong> / {totalDuration.toFixed(1)}s
            </div>
            <button
              type="button"
              onClick={() => setIsTimelineExpanded(!isTimelineExpanded)}
              className="text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              {isTimelineExpanded ? '收起时间轴 ▲' : '展开时间轴 ▼'}
            </button>
          </div>
        </div>

        {isTimelineExpanded && (
          <div className="space-y-1.5 pt-1 overflow-x-auto animate-in fade-in duration-150">
            {/* V1 Video Track */}
            <div className="flex items-center gap-2 min-w-[620px]">
              <div className="w-16 shrink-0 text-[11px] font-bold text-sky-400">V1 视频轨</div>
              <div className="flex flex-1 gap-1">
                {shotProConfigs.map((cfg, idx) => {
                  const dur = cfg?.duration || 4.0;
                  const widthPct = Math.max(14, (dur / totalDuration) * 100);
                  const isSelected = selectedShotIdx === idx;
                  return (
                    <div
                      key={idx}
                      style={{ width: `${widthPct}%` }}
                      onClick={() => {
                        setSelectedShotIdx(idx);
                        let startT = 0;
                        for (let k = 0; k < idx; k++) {
                          startT += shotProConfigs[k]?.duration || 4.0;
                        }
                        setCurrentTime(startT);
                      }}
                      className={`truncate rounded-lg border p-1.5 text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-cyan-400 bg-cyan-950/60 shadow-xs ring-1 ring-cyan-400/50'
                          : 'border-slate-800 bg-slate-900/60 hover:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] font-bold text-white truncate">
                        <span>0{idx + 1} {cameraAngles[idx] || '镜头'}</span>
                        <span className="font-mono text-slate-400">{dur}s</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* T1 Subtitle Track */}
            <div className="flex items-center gap-2 min-w-[620px]">
              <div className="w-16 shrink-0 text-[11px] font-bold text-amber-400">T1 字幕轨</div>
              <div className="flex flex-1 gap-1">
                {shotProConfigs.map((cfg, idx) => {
                  const dur = cfg?.duration || 4.0;
                  const widthPct = Math.max(14, (dur / totalDuration) * 100);
                  return (
                    <div
                      key={idx}
                      style={{ width: `${widthPct}%` }}
                      className="truncate rounded-lg border border-amber-500/20 bg-amber-500/10 px-2 py-1 text-[10px] text-amber-200"
                    >
                      “{sceneLines[idx] || '台词'}”
                    </div>
                  );
                })}
              </div>
            </div>

            {/* A1 Voice Track */}
            <div className="flex items-center gap-2 min-w-[620px]">
              <div className="w-16 shrink-0 text-[11px] font-bold text-emerald-400">A1 配音轨</div>
              <div className="flex-1 rounded-lg border border-emerald-500/20 bg-emerald-500/10 px-2.5 py-1 flex items-center justify-between text-[11px] text-emerald-200">
                <span className="flex items-center gap-1">
                  <Mic className="h-3 w-3 text-emerald-400" />
                  <span>AI 真人口播：{activeVoice.name} ({speechRate.toFixed(2)}x)</span>
                </span>
                <span className="font-mono text-[9px] text-emerald-300">自动卡点已就绪</span>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 5. Batch Remix Matrix Modal (一键批量裂变 10 条原创视频) */}
      {isBatchRemixModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-in fade-in duration-150">
          <div className="relative w-full max-w-5xl rounded-[28px] border border-slate-800 bg-slate-950 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white font-bold">
                  <Flame className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    火兔 × 筷子：批量视频混剪裂变中心（10 条去重原创）
                  </h3>
                  <p className="text-xs text-slate-400">
                    已针对「{userSubjectName}」自动重组镜头、差异化开头黄金钩子、换配音音色与 BGM，防搬运查重！
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsBatchRemixModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold p-1 cursor-pointer"
              >
                关闭
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {batchGeneratedVideos.map((item, idx) => (
                <div
                  key={item.id}
                  className="group rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 hover:border-cyan-400/60 transition-all flex flex-col justify-between"
                >
                  <div className="space-y-1.5">
                    <div className="relative aspect-[9/16] w-full rounded-lg overflow-hidden bg-slate-950">
                      <img
                        src={item.coverUrl}
                        alt={item.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute top-1 left-1 rounded bg-black/80 px-1 py-0.2 text-[8px] font-bold text-amber-300">
                        #{idx + 1}
                      </span>
                      <span className="absolute bottom-1 right-1 rounded bg-emerald-600/90 px-1 py-0.2 text-[8px] font-bold text-white">
                        原创度 {item.uniqueScore}%
                      </span>
                    </div>

                    <div className="font-bold text-white text-xs line-clamp-1">{item.title}</div>
                    <p className="text-[10px] text-slate-400 line-clamp-1">🎙️ {item.voiceName}</p>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                    <button
                      type="button"
                      onClick={() => {
                        setIsBatchRemixModalOpen(false);
                        onShowNotice('success', `已将裂变成片 #${idx + 1} 载入主剪辑台继续精修！`);
                      }}
                      className="text-cyan-400 font-bold hover:underline cursor-pointer"
                    >
                      载入微操
                    </button>
                    <button
                      type="button"
                      onClick={() => onShowNotice('success', `成片 #${idx + 1} 单独下载完成！`)}
                      className="text-slate-400 hover:text-white cursor-pointer"
                    >
                      下载
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-800">
              <span className="text-xs text-slate-400">
                支持一键打包下载全部 10 条高清 MP4 视频或一键推送到多账号矩阵发布宝
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onShowNotice('success', '正在打包全部 10 条视频为 ZIP 压缩包并自动下载！');
                    setIsBatchRemixModalOpen(false);
                  }}
                  className="rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-4 py-2 text-xs font-bold text-white shadow-xs hover:brightness-105 cursor-pointer"
                >
                  打包下载全部 10 条视频
                </button>
                <button
                  type="button"
                  onClick={() => setIsBatchRemixModalOpen(false)}
                  className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  完成
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
