import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  X,
  Check,
  Copy,
  Play,
  Volume2,
  UserCheck,
  Layers,
  FileText,
  Film,
  Scissors,
  Wand2,
  Store,
  ChevronRight,
  Zap,
  Terminal,
  Cpu,
  Plus,
  RefreshCw,
  Maximize2,
  Minimize2,
  BookmarkPlus,
  Share2,
  CheckCircle2,
  Code2,
  Boxes,
  Github,
} from 'lucide-react';
import { CuratedTemplate, StoreMemoryProfile } from '../data/curatedTemplates';
import { SkillHubMarketplaceModal } from './SkillHubMarketplaceModal';

export type KuaiziToolId =
  | 'daily_insight'
  | 'smart_dissect'
  | 'xhs_copy'
  | 'multi_scene_text'
  | 'write_script'
  | 'team_templates'
  | 'multi_lang_tts'
  | 'digital_human'
  | 'product_poster'
  | 'smart_mix'
  | 'ai_oneclick_video'
  | 'smart_graphic'
  | 'banner_personalize'
  | 'ecommerce_main'
  | 'matrix_publish'
  | 'ad_placement';

export interface KuaiziCapabilityGroup {
  groupTitle: string;
  items: {
    id: KuaiziToolId;
    label: string;
    shortDesc: string;
  }[];
}

export interface AgentMountedSkill {
  id: string;
  name: string;
  toolName: string;
  directive: string;
  isCustom?: boolean;
}

const DEFAULT_AGENT_SKILLS: AgentMountedSkill[] = [
  {
    id: 'skill_short_video_script',
    name: '短视频口播脚本爆款生成器 (4段式高留存)',
    toolName: 'generate_viral_speaking_script',
    directive:
      '长期记忆核心模块：按「0-3s颠覆认知钩子 + 3-15s痛点情绪共振 + 15-45s干货3步解法 + 45-60s评论互动CTA」生成短视频口播脚本',
  },
  {
    id: 'ag_skill_hook3s',
    name: '黄金前3秒强钩子 Skill',
    toolName: 'analyze_golden_3s_hook',
    directive: '提取反常识视觉冲突与痛点提问，确保前3秒留存率 > 82%',
  },
  {
    id: 'ag_skill_rag_store',
    name: 'RAG 门店知识库检索 Skill',
    toolName: 'query_rag_store_memory',
    directive: '检索当前绑定门店的镇店爆品、地域锚点、主理人人设与团购利益点',
  },
  {
    id: 'ag_skill_matrix_storyboard',
    name: '4镜高转化分镜裂变 Skill',
    toolName: 'generate_4shot_storyboard',
    directive: '按「01痛点暴击-02产品微距-03实测对比-04限时促单」生成可执行分镜',
  },
  {
    id: 'ag_skill_seo_copy',
    name: '双端爆款标题与封面 Skill',
    toolName: 'synthesize_viral_cover_titles',
    directive: '同步输出抖音/小红书高点击标题、封面大字海报文案与热门标签',
  },
];

// 四大核心板块共 16 项全能创作模块（4列 × 4项对称式美学矩阵，彻底消除高度不齐与留白空洞）
export const KUAIZI_CAPABILITY_GROUPS: KuaiziCapabilityGroup[] = [
  {
    groupTitle: '01 · 编导灵感与拉片',
    items: [
      { id: 'daily_insight', label: '每日视频洞察', shortDesc: '行业飙升榜与黄金前3秒风向' },
      { id: 'smart_dissect', label: '智镜视频解析', shortDesc: '粘贴链接30秒拉片还原分镜' },
      { id: 'write_script', label: '编写分镜脚本', shortDesc: '可调宽高分镜表与单镜重写' },
      { id: 'team_templates', label: '团队脚本模板', shortDesc: '高转化爆款模板库一键套用' },
    ],
  },
  {
    groupTitle: '02 · 文案种草与数字人',
    items: [
      { id: 'xhs_copy', label: '小红书文案生成', shortDesc: '高收藏种草笔记与热门标签' },
      { id: 'multi_scene_text', label: '多场景AI文本', shortDesc: '口播/朋友圈/直播逼单话术' },
      { id: 'multi_lang_tts', label: '多语言AI配音', shortDesc: '方言/跨境多语种情感配音' },
      { id: 'digital_human', label: '数字人视频', shortDesc: '免出镜4K口型同步数字人播报' },
    ],
  },
  {
    groupTitle: '03 · 视频与图文合成',
    items: [
      { id: 'ai_oneclick_video', label: 'AI一键成片', shortDesc: '一句话生成脚本并合成成片' },
      { id: 'smart_mix', label: '短视频智能混剪', shortDesc: '多镜头自动卡点字幕与BGM' },
      { id: 'smart_graphic', label: '图文智能创作', shortDesc: '小红书多页种草图文一键生成' },
      { id: 'product_poster', label: '产品海报生成', shortDesc: '商业级高定主视觉海报排版' },
    ],
  },
  {
    groupTitle: '04 · 电商套图与矩阵投流',
    items: [
      { id: 'ecommerce_main', label: '电商主图套图', shortDesc: '商拍/卖点/场景/细节4图连出' },
      { id: 'banner_personalize', label: 'Banner千人千面', shortDesc: '多受众痛点批量裂变投流图' },
      { id: 'matrix_publish', label: '矩阵宝一键分发', shortDesc: '抖/红/快/视多账号矩阵发布' },
      { id: 'ad_placement', label: '千川广告投放', shortDesc: '前3秒留存与投流ROI智能诊断' },
    ],
  },
];

interface AgentLoopStep {
  id: string;
  phase: 'THINK' | 'TOOL_CALL' | 'FUNCTION_CALL' | 'TERMINAL' | 'DELIVERABLE';
  title: string;
  detail: string;
  codeBlock?: string;
  status: 'running' | 'done';
}

/**
 * 首页顶部：极简高颜值 AI Agent 工作台（对标豆包/WorkBuddy/ChatGPT Work/AI Studio 极简居中美学）
 * 兼顾：快速生成 vs 超能Agent模式切换、洁净大输入框、底部功能胶囊栏、为你推荐灵感词、以及对称式 4×4 全链路智能创作矩阵
 */
export const KuaiziAgentHomeWorkbench: React.FC<{
  promptValue?: string;
  onChangePrompt?: (val: string) => void;
  storeMemoryEnabled: boolean;
  activeStore: StoreMemoryProfile;
  productName?: string;
  sellingPoints?: string;
  isGenerating?: boolean;
  onPromptSubmit?: (promptText: string, mode: string) => void;
  onExecuteOmniAgent?: (mode: string, promptText: string) => void;
  onSelectCapability: (toolId: KuaiziToolId) => void;
  onOpenRagSidebar?: () => void;
  onOpenRagCopilot?: () => void;
  onOpenPersonalAgentModal?: () => void;
  onEncapsulateAsTemplate?: (newTemplate: CuratedTemplate) => void;
  onApplyAgentDeliverableToEditor?: (payload: {
    title: string;
    productName: string;
    sellingPoints: string;
    cameraAngles: string[];
    visualCues: string[];
    sceneLines: string[];
    openMixImmediately?: boolean;
  }) => void;
}> = ({
  promptValue,
  onChangePrompt,
  storeMemoryEnabled,
  activeStore,
  productName = '星澜氨基酸去屑控油洗发水',
  sellingPoints = '深层净澈头皮、72小时长效控油蓬松、温和去屑不紧绷',
  isGenerating = false,
  onPromptSubmit,
  onExecuteOmniAgent,
  onSelectCapability,
  onOpenRagSidebar,
  onOpenRagCopilot,
  onOpenPersonalAgentModal,
  onEncapsulateAsTemplate,
  onApplyAgentDeliverableToEditor,
}) => {
  const [localPrompt, setLocalPrompt] = useState('');
  const promptInput = promptValue !== undefined ? promptValue : localPrompt;
  const setPromptInput = (val: string) => {
    setLocalPrompt(val);
    onChangePrompt?.(val);
  };

  // Top "快速 | 超能" switch (matching Screenshots 3, 4, 5)
  const [agentPowerMode, setAgentPowerMode] = useState<'fast' | 'super'>('super');

  const [selectedAgentMode, setSelectedAgentMode] = useState<
    'one_click_video' | 'script' | 'dissect' | 'xhs_graphic' | 'ecommerce_poster'
  >('one_click_video');
  const [isExpandedInput, setIsExpandedInput] = useState(false);
  const [showAllCapabilities, setShowAllCapabilities] = useState(true);
  const [activeMatrixFilter, setActiveMatrixFilter] = useState<string>('ALL');

  // Custom & Built-in Skills State
  const [skills, setSkills] = useState<AgentMountedSkill[]>(DEFAULT_AGENT_SKILLS);
  const [selectedSkillIds, setSelectedSkillIds] = useState<string[]>([
    'skill_short_video_script',
    'ag_skill_hook3s',
    'ag_skill_rag_store',
    'ag_skill_matrix_storyboard',
  ]);
  const [showSkillDrawer, setShowSkillDrawer] = useState(false);
  const [isSkillMarketOpen, setIsSkillMarketOpen] = useState(false);
  const [customSkillName, setCustomSkillName] = useState('');
  const [customSkillDirective, setCustomSkillDirective] = useState('');

  // Autonomous Agent Execution Loop State
  const [isRunningAgentLoop, setIsRunningAgentLoop] = useState(false);
  const [agentSteps, setAgentSteps] = useState<AgentLoopStep[]>([]);
  const [agentDeliverable, setAgentDeliverable] = useState<{
    title: string;
    coverHeadline: string;
    coverSubhead: string;
    suitableDirection: string;
    suitableMaterial: string;
    cameraAngles: string[];
    visualCues: string[];
    sceneLines: string[];
  } | null>(null);
  const [titleVariantIdx, setTitleVariantIdx] = useState(0);
  const [coverVariantIdx, setCoverVariantIdx] = useState(0);
  const [scriptVariantIdx, setScriptVariantIdx] = useState(0);
  const [encapsulatedDone, setEncapsulatedDone] = useState(false);

  const defaultProdName = storeMemoryEnabled
    ? activeStore.signatureProducts.split('；')[0] || productName
    : productName;

  // Clean recommended starter pills matching Screenshots 2, 4, 5
  const recommendedStarters = [
    {
      tag: '黄金3秒脚本',
      tagColor: 'text-indigo-600',
      text: `为「${defaultProdName.slice(0, 14)}」生成前3秒痛点暴击4镜带货脚本`,
      fullPrompt: `帮我写一条「${defaultProdName}」前3秒强痛点带货脚本，包含4个分镜、口播台词与封面大字，并自动校验完播率`,
      mode: 'script' as const,
    },
    {
      tag: '爆款拉片复刻',
      tagColor: 'text-violet-600',
      text: '粘贴抖音/小红书同行爆款链接，30秒拆解结构并裂变3条新开头',
      fullPrompt:
        '拆解同行高赞爆款视频结构（https://v.douyin.com/iY8kL9p/），调用Skill提取爆款公式并裂变3条不同开头钩子',
      mode: 'dissect' as const,
    },
    {
      tag: '同城团购种草',
      tagColor: 'text-emerald-600',
      text: `结合「${activeStore.storeName.slice(0, 10)}」知识库生成小红书种草图文与团购话术`,
      fullPrompt: `结合「${activeStore.storeName}」RAG门店知识库，生成一套小红书高收藏种草图文与抖音团购核销脚本`,
      mode: 'xhs_graphic' as const,
    },
    {
      tag: '电商主图套图',
      tagColor: 'text-amber-600',
      text: '为新品一键生成 01商拍主图 + 02卖点对比 + 03场景海报全套视觉',
      fullPrompt: `为新品「${defaultProdName}」规划01商拍主图+02痛点对比图+03成分微距图+04促销海报全套视觉方案`,
      mode: 'ecommerce_poster' as const,
    },
  ];

  const handleToggleSkill = (id: string) => {
    setSelectedSkillIds((prev) =>
      prev.includes(id)
        ? prev.length > 1
          ? prev.filter((item) => item !== id)
          : prev
        : [...prev, id]
    );
  };

  const handleAddCustomSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSkillName.trim() || !customSkillDirective.trim()) return;
    const newSkill: AgentMountedSkill = {
      id: `custom_skill_${Date.now()}`,
      name: customSkillName.trim(),
      toolName: `custom_skill_${customSkillName.trim().slice(0, 10).replace(/\s+/g, '_')}`,
      directive: customSkillDirective.trim(),
      isCustom: true,
    };
    setSkills((prev) => [...prev, newSkill]);
    setSelectedSkillIds((prev) => [...prev, newSkill.id]);
    setCustomSkillName('');
    setCustomSkillDirective('');
  };

  // Run Autonomous Multi-Step Agent Loop (Think -> Tool Call -> Function Call -> Terminal -> Deliverable)
  const runAutonomousAgentLoop = (rawInput?: string) => {
    const cleanInput =
      (rawInput ?? promptInput).trim() || recommendedStarters[0].fullPrompt;
    setPromptInput(cleanInput);
    setIsRunningAgentLoop(true);
    setEncapsulatedDone(false);

    const activeSkills = skills.filter((s) => selectedSkillIds.includes(s.id));
    const skillNames = activeSkills.map((s) => s.name).join(' + ');
    const toolCallsJson = JSON.stringify(
      {
        agent: 'Kuaipai-Omni-Director-v3.8',
        mounted_skills: activeSkills.map((s) => ({
          tool: s.toolName,
          directive: s.directive,
        })),
        rag_knowledge_base: storeMemoryEnabled ? activeStore.storeName : '全网通用高赞爆款库',
        context_length: cleanInput.length,
      },
      null,
      2
    );

    const funcCallCode = `await invokeFunction("synthesize_storyboard_and_cover", {
  targetProduct: "${defaultProdName.slice(0, 26)}",
  storeAnchor: "${activeStore.cityLocation} · ${activeStore.storeName}",
  shotCount: 4,
  aspectRatio: "9:16",
  injectGolden3sHook: true
});`;

    const terminalLog = `$ agent-sandbox --run-workflow "${selectedAgentMode}" --skills=${activeSkills.length}
[00:00.12] [RAG] Mounted vector index: ${activeStore.storeName} (${activeStore.industry})
[00:00.38] [SKILL] Executing ${activeSkills.map((s) => s.toolName).join(', ')}...
[00:00.74] [FUNC] Generated 4 storyboard shots + 3 AB-test hooks
[00:01.05] [VERIFY] Golden 3s retention score: 86.4% (PASS > 80% threshold)
[00:01.20] [DONE] Task loop completed with 0 errors. Deliverable ready.`;

    const initialSteps: AgentLoopStep[] = [
      {
        id: 'step_1',
        phase: 'THINK',
        title: 'Step 1 · 意图解析与 RAG 知识库检索',
        detail: `已识别上下文需求（共 ${cleanInput.length} 字），自动关联「${activeStore.storeName}」核心卖点与受众痛点。`,
        status: 'done',
      },
      {
        id: 'step_2',
        phase: 'TOOL_CALL',
        title: `Step 2 · 调用已挂载 Skill 工具包 (${activeSkills.length} 项：${skillNames})`,
        detail: '正在执行 Skill 规则注入与爆款基因拆解匹配...',
        codeBlock: toolCallsJson,
        status: 'done',
      },
      {
        id: 'step_3',
        phase: 'FUNCTION_CALL',
        title: 'Step 3 · 调用分镜生成与视觉封面合成函数 (Function Calling)',
        detail: '已生成 4 镜头标准脚本、封面海报标题及适用素材分析。',
        codeBlock: funcCallCode,
        status: 'done',
      },
      {
        id: 'step_4',
        phase: 'TERMINAL',
        title: 'Step 4 · 终端沙箱循环校验与完播率压测 (Terminal Sandbox)',
        detail: '前 3 秒黄金钩子留存率预估 86.4%，符合商业投流标准。',
        codeBlock: terminalLog,
        status: 'done',
      },
    ];

    setAgentSteps(initialSteps);

    const deliverablePayload = {
      title: `【${activeStore.storeName}】${defaultProdName.slice(0, 18)} · Agent 闭环高转化脚本`,
      coverHeadline: `${defaultProdName.slice(0, 10)}实测封神`,
      coverSubhead: '前3秒痛点暴击 · 72h长效高光实测',
      suitableDirection: `${activeStore.industry}带货种草 / 抖音同城团购核销 / 小红书高收藏测评`,
      suitableMaterial: `1段痛点特写(3s) + 1段${defaultProdName.slice(0, 10)}微距镜头(4s) + 1段使用前后对比(4s) + 门店/福利尾帧(3s)`,
      cameraAngles: [
        '01 黄金前3秒钩子 (0-3s Hook)',
        '02 痛点放大与情绪共振 (3-15s Agitation)',
        '03 干货解法三步法 (15-45s Solution)',
        '04 互动促单引导完播 (45-60s CTA)',
      ],
      visualCues: [
        `【0-3s颠覆钩子】特写展示受众「${activeStore.targetAudience.slice(0, 18)}」的痛点困扰，镜头快速推近，画面反常识抓人。`,
        `【3-15s痛点共振】分屏或真实场景展示痛点反常识误区，唤起认同感与代入感。`,
        `【15-45s干货解法】4K微距展示「${defaultProdName}」3步解法与真实效果，突出「${sellingPoints.slice(0, 26)}」。`,
        `【45-60s引导完播】主理人微笑出镜引导点赞收藏，屏幕叠加「${activeStore.memoryAnchors.slice(0, 22)}」福利字卡，评论区抛梗。`,
      ],
      sceneLines: [
        `先别划走！为什么90%的人选${defaultProdName.slice(0, 10)}都踩了坑？今天教你省下冤枉钱！`,
        `很多人平时越洗越油、越护发越塌，其实根本就是踩了这几个误区！`,
        `想要根源解决只要记住3步：第一步选温和氨基酸，第二步认准长效控油，第三步就像这款${defaultProdName.slice(0, 10)}直接拉满！`,
        `担心记不住的赶紧点赞收藏备用！你在平时还踩过哪些坑？在评论区告诉我，立享专属福利！`,
      ],
    };

    setAgentDeliverable(deliverablePayload);
    setIsRunningAgentLoop(false);
  };

  // RAG Single-Item Smart Replacement inside Agent Deliverable
  const handleReplaceDeliverableTitle = () => {
    if (!agentDeliverable) return;
    const candidates = [
      `后悔没早买！${defaultProdName.slice(0, 12)}真实测评，第3秒直接被惊艳！`,
      `在${activeStore.cityLocation}火出圈！这款${defaultProdName.slice(0, 12)}凭什么全是回头客？`,
      `别再交智商税了！沉浸式实测${defaultProdName.slice(0, 12)}的核心细节`,
      `【${activeStore.storeName}店长亲测】3秒解决${activeStore.targetAudience.slice(0, 10)}最大痛点！`,
    ];
    const nextIdx = (titleVariantIdx + 1) % candidates.length;
    setTitleVariantIdx(nextIdx);
    setAgentDeliverable({
      ...agentDeliverable,
      title: candidates[nextIdx],
    });
  };

  const handleReplaceDeliverableCover = () => {
    if (!agentDeliverable) return;
    const coverPairs = [
      { h: '千万别乱买！实测对比', s: `${activeStore.storeName} · 闭眼入指南` },
      { h: '放大10倍看真实细节', s: `${sellingPoints.slice(0, 16)}` },
      { h: '同城回头客断货王', s: `${activeStore.cityLocation}口碑爆品实测` },
      { h: '3秒看懂核心反差', s: '高完播黄金钩子封神榜' },
    ];
    const nextIdx = (coverVariantIdx + 1) % coverPairs.length;
    setCoverVariantIdx(nextIdx);
    setAgentDeliverable({
      ...agentDeliverable,
      coverHeadline: coverPairs[nextIdx].h,
      coverSubhead: coverPairs[nextIdx].s,
    });
  };

  const handleReplaceDeliverableScript = () => {
    if (!agentDeliverable) return;
    const nextIdx = (scriptVariantIdx + 1) % 3;
    setScriptVariantIdx(nextIdx);
    const scriptPools = [
      [
        `${activeStore.cityLocation}的朋友注意！买${defaultProdName.slice(0, 10)}千万别只看表面包装！`,
        `今天把我们【${activeStore.storeName}】镇店的这款${defaultProdName}放大10倍给大家看细节！`,
        `核心搭载了${sellingPoints.slice(0, 26)}，实测前后反差肉眼可见！`,
        `现在左下角限时开放专属福利：${activeStore.memoryAnchors.slice(0, 22)}，刷到赶紧囤！`,
      ],
      [
        `花3秒钟把镜头拉到最近！看看真正高品质的${defaultProdName.slice(0, 10)}长什么样！`,
        `很多老顾客都是因为这一个细节，成了我们【${activeStore.storeName}】的忠实粉丝！`,
        `主打的就是${sellingPoints.slice(0, 26)}，不管是自用还是送人都超有面子！`,
        `趁现在补贴活动还在，点击下方链接直接锁单，不满意随时退！`,
      ],
      [
        `如果你也是${activeStore.targetAudience.slice(0, 14)}，这条视频能帮你省下不少冤枉钱！`,
        `我们团队实测了十几个批次，最终打磨出这款${defaultProdName}！`,
        `真正做到了${sellingPoints.slice(0, 26)}，口碑好评率高达98%以上！`,
        `点击左下角团购/商品卡，立享${activeStore.memoryAnchors.slice(0, 22)}，手慢无！`,
      ],
    ];
    setAgentDeliverable({
      ...agentDeliverable,
      sceneLines: scriptPools[nextIdx],
    });
  };

  const handlePrimarySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promptInput.trim() || recommendedStarters[0].fullPrompt;
    if (agentPowerMode === 'super') {
      runAutonomousAgentLoop(clean);
    } else if (onExecuteOmniAgent) {
      onExecuteOmniAgent(selectedAgentMode, clean);
    } else if (onPromptSubmit) {
      onPromptSubmit(clean, selectedAgentMode);
    }
  };

  const visibleGroups =
    activeMatrixFilter === 'ALL'
      ? KUAIZI_CAPABILITY_GROUPS
      : KUAIZI_CAPABILITY_GROUPS.filter((g) => g.groupTitle === activeMatrixFilter);

  return (
    <section className="relative overflow-hidden rounded-3xl border border-slate-200/80 bg-white px-4 py-8 sm:px-8 sm:py-10 shadow-2xs">
      {/* Subtle Top Pastel Aura matching Screenshot 5 & 6 */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[680px] -translate-x-1/2 rounded-full bg-gradient-to-r from-indigo-100/70 via-purple-100/60 to-sky-100/70 blur-3xl"
      />

      {/* Centered Minimalist Agent Workspace Container (Widened to 1680px/full width to eliminate empty side margins) */}
      <div className="relative mx-auto max-w-[1680px] 2xl:max-w-full w-full">
        {/* 1. Centered Clean Headline */}
        <div className="text-center">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
            需要我帮你完成什么任务？
          </h1>
          <p className="mt-2 text-xs text-slate-500">
            输入商品名称或营销需求，已搭载 {selectedSkillIds.length} 项专业 Skill 与「{activeStore.storeName}」RAG 知识库
          </p>
        </div>

        {/* 2. Scenario Category Pills Above Input Box (One-click direct mode selection & instant navigation) */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          {[
            {
              id: 'one_click_video',
              label: 'AI 一键成片',
              icon: Film,
              toolId: 'ai_oneclick_video' as KuaiziToolId,
              hint: '直达视频一键成片混剪',
            },
            {
              id: 'script',
              label: '编写分镜脚本',
              icon: FileText,
              toolId: 'write_script' as KuaiziToolId,
              hint: '直达分镜脚本精修台',
            },
            {
              id: 'dissect',
              label: '爆款视频拆解',
              icon: Scissors,
              toolId: 'smart_dissect' as KuaiziToolId,
              hint: '直达一键拉片拆解中心',
            },
            {
              id: 'xhs_graphic',
              label: '小红书种草图文',
              icon: Wand2,
              toolId: 'smart_graphic' as KuaiziToolId,
              hint: '直达图文与小红书种草创作',
            },
            {
              id: 'ecommerce_poster',
              label: '电商主图套图',
              icon: Layers,
              toolId: 'ecommerce_main' as KuaiziToolId,
              hint: '直达电商套图生成工场',
            },
          ].map((m) => {
            const Icon = m.icon;
            const active = selectedAgentMode === m.id;
            return (
              <button
                key={m.id}
                type="button"
                title={`点击立即直达「${m.label}」`}
                onClick={() => {
                  setSelectedAgentMode(
                    m.id as
                      | 'one_click_video'
                      | 'script'
                      | 'dissect'
                      | 'xhs_graphic'
                      | 'ecommerce_poster'
                  );
                  // 点击立即直达对应功能工作台，彻底修复按键无响应问题
                  onSelectCapability(m.toolId);
                }}
                className={`group inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-medium transition-all cursor-pointer shadow-xs hover:scale-105 active:scale-95 ${
                  active
                    ? 'border border-indigo-500 bg-indigo-50/90 text-indigo-700 font-semibold shadow-2xs'
                    : 'border border-slate-200/90 bg-white text-slate-600 hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50/30'
                }`}
              >
                <Icon className="h-3.5 w-3.5 transition-transform group-hover:scale-110" />
                <span>{m.label}</span>
                <span className="text-[10px] text-slate-400 group-hover:text-indigo-500 transition-colors">→</span>
              </button>
            );
          })}
        </div>

        {/* 3. Minimalist Elevated Omni-Prompt Card (Widened, resizable textarea, instant action buttons) */}
        <form onSubmit={handlePrimarySubmit} className="mt-3.5">
          <div className="overflow-hidden rounded-3xl p-[1.5px] bg-gradient-to-r from-sky-400 via-indigo-500 to-purple-500 shadow-[0_12px_36px_-10px_rgba(79,70,229,0.18)]">
            <div className="rounded-[22px] bg-white p-4 sm:p-5">
              <textarea
                rows={isExpandedInput ? 8 : 4}
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handlePrimarySubmit(e);
                  }
                }}
                placeholder="深度处理你的创作任务：输入商品卖点、粘贴同行视频链接或文案需求，回车直接执行..."
                className={`w-full resize-y bg-transparent text-sm leading-relaxed text-slate-900 placeholder:text-slate-400 focus:outline-none overflow-auto ${
                  isExpandedInput ? 'min-h-[220px]' : 'min-h-[110px]'
                }`}
              />

              {/* Bottom Action Bar inside White Card */}
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                {/* Left Dock Controls */}
                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                  <button
                    type="button"
                    onClick={() => setIsExpandedInput(!isExpandedInput)}
                    title={isExpandedInput ? '恢复标准输入框高度' : '自由拉伸扩大输入框'}
                    className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    {isExpandedInput ? (
                      <Minimize2 className="h-3.5 w-3.5" />
                    ) : (
                      <Plus className="h-4 w-4" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsSkillMarketOpen(true)}
                    className="inline-flex items-center gap-1 rounded-full border border-indigo-200 bg-indigo-50/80 px-3 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition-colors cursor-pointer"
                    title="打开 Skill 技能广场，浏览与一键装载技能"
                  >
                    <Boxes className="h-3.5 w-3.5 text-indigo-600" />
                    <span>Skill 技能广场 ({selectedSkillIds.length}已装载)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onOpenRagCopilot?.();
                      onOpenRagSidebar?.();
                    }}
                    className="inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    <Store className="h-3.5 w-3.5 text-emerald-600" />
                    <span>
                      {storeMemoryEnabled
                        ? `门店：${activeStore.storeName.slice(0, 8)}`
                        : '关联门店知识库'}
                    </span>
                  </button>

                  {onOpenPersonalAgentModal && (
                    <button
                      type="button"
                      onClick={() => onOpenPersonalAgentModal()}
                      className="inline-flex items-center gap-1.5 rounded-full border border-purple-200 bg-purple-50/80 px-3 py-1 text-xs font-semibold text-purple-700 hover:bg-purple-100 transition-colors cursor-pointer shadow-2xs"
                      title="自定义专属 AI 智能体与深度 RAG 知识库"
                    >
                      <Bot className="h-3.5 w-3.5 text-purple-600" />
                      <span>定制专属 Agent & RAG</span>
                    </button>
                  )}
                </div>

                {/* Right Send Controls */}
                <div className="flex items-center gap-2">
                  {promptInput.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setPromptInput('')}
                      className="text-xs text-slate-400 hover:text-slate-600 px-2 cursor-pointer"
                    >
                      清空
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      const clean =
                        promptInput.trim() || recommendedStarters[0].fullPrompt;
                      if (onExecuteOmniAgent) {
                        onExecuteOmniAgent(selectedAgentMode, clean);
                      }
                    }}
                    className="hidden sm:inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:border-indigo-300 hover:text-indigo-600 cursor-pointer"
                  >
                    <span>直达分镜台</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isGenerating || isRunningAgentLoop}
                    title="立即一键执行 (Enter)"
                    className="flex h-9 items-center gap-1.5 rounded-full bg-indigo-600 px-5 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50 transition-all cursor-pointer"
                  >
                    <span>{isRunningAgentLoop ? 'Agent 执行中...' : '⚡ 立即一键生成'}</span>
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Subtle Bottom Tray */}
            <div className="flex flex-wrap items-center justify-between gap-2 bg-sky-50/75 px-5 py-2 text-[11px] text-slate-600 border-t border-sky-100/80">
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-1 font-semibold text-[#24568d]">
                  <Terminal className="h-3 w-3" />
                  <span>Agent 自动调用工具链</span>
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-slate-600">
                  已装载 {selectedSkillIds.length} 项 Skill (黄金3秒 + 门店RAG + 4镜分镜)
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsSkillMarketOpen(true)}
                className="font-bold text-[#24568d] hover:underline cursor-pointer flex items-center gap-1"
              >
                <Boxes className="h-3 w-3" />
                <span>+ 浏览与装载更多 Skill</span>
              </button>
            </div>
          </div>
        </form>

        {/* Collapsible Skill & Custom Skill Drawer (Only shown when clicked) */}
        {showSkillDrawer && (
          <div className="mt-3 rounded-2xl border border-sky-200/80 bg-sky-50/40 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-800">
                挂载 Skill 技能包
              </span>
              <button
                type="button"
                onClick={() => setShowSkillDrawer(false)}
                className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                关闭
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {skills.map((sk) => {
                const active = selectedSkillIds.includes(sk.id);
                return (
                  <button
                    key={sk.id}
                    type="button"
                    title={sk.directive}
                    onClick={() => handleToggleSkill(sk.id)}
                    className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-all cursor-pointer ${
                      active
                        ? 'border-[#3572b0] bg-[#3572b0] text-white shadow-2xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-sky-300'
                    }`}
                  >
                    {active && <Check className="h-3 w-3" />}
                    <span>{sk.name}</span>
                  </button>
                );
              })}
            </div>

            <form
              onSubmit={handleAddCustomSkill}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-2 border-t border-sky-100"
            >
              <input
                type="text"
                value={customSkillName}
                onChange={(e) => setCustomSkillName(e.target.value)}
                placeholder="新 Skill 名称（如：同城团购逼单 Skill）"
                className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 focus:border-sky-500 focus:outline-none sm:w-56"
              />
              <input
                type="text"
                value={customSkillDirective}
                onChange={(e) => setCustomSkillDirective(e.target.value)}
                placeholder="Skill 规则描述（如：前3秒必须含价格锚点与反问句）"
                className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 focus:border-sky-500 focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-xl iridescent-btn px-4 py-1.5 text-xs font-semibold text-white whitespace-nowrap cursor-pointer"
              >
                + 添加挂载
              </button>
            </form>
          </div>
        )}

        {/* 5. Clean Starter Recommendations ("为你推荐 / 从这里开始" matching Screenshots 3, 4, 5) */}
        <div className="mt-5">
          <div className="text-[11px] font-medium text-slate-400 mb-2 px-1">
            为你推荐
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {recommendedStarters.map((item, idx) => (
              <button
                key={idx}
                type="button"
                title="点击自动填入指令并运行"
                onClick={() => {
                  setSelectedAgentMode(item.mode);
                  setPromptInput(item.fullPrompt);
                  if (agentPowerMode === 'super') {
                    runAutonomousAgentLoop(item.fullPrompt);
                  }
                }}
                className="group flex items-center justify-between gap-2 rounded-2xl border border-slate-200/80 bg-slate-50/60 px-4 py-2.5 text-left text-xs transition-all hover:border-sky-300 hover:bg-white hover:shadow-xs cursor-pointer"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className={`font-semibold shrink-0 ${item.tagColor}`}>
                    ✦ {item.tag}
                  </span>
                  <span className="truncate text-slate-700 group-hover:text-slate-900">
                    {item.text}
                  </span>
                </div>
                <span className="text-slate-400 group-hover:text-[#24568d] shrink-0">
                  ↗
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Autonomous Agent Loop Execution Console & Deliverable Panel */}
        {agentSteps.length > 0 && agentDeliverable && (
          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-950 text-slate-100 p-5 space-y-4 shadow-md">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-600 text-white">
                  <Terminal className="h-3.5 w-3.5" />
                </span>
                <span className="text-xs font-semibold text-white">
                  超能 Agent 闭环执行终端
                </span>
                <span className="text-[11px] font-semibold text-emerald-400">
                  · ✓ 已完成交付
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAgentSteps([]);
                  setAgentDeliverable(null);
                }}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                收起终端
              </button>
            </div>

            {/* 4 Execution Steps */}
            <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
              {agentSteps.map((st) => (
                <div
                  key={st.id}
                  className="rounded-xl border border-slate-800 bg-slate-900/90 p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-300">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                      <span>{st.title}</span>
                    </span>
                    <span className="font-mono text-[10px] text-slate-400">{st.phase}</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{st.detail}</p>
                  {st.codeBlock && (
                    <pre className="overflow-x-auto rounded-lg bg-black/60 p-2.5 font-mono text-[11px] text-emerald-300 leading-relaxed">
                      {st.codeBlock}
                    </pre>
                  )}
                </div>
              ))}
            </div>

            {/* Deliverable Card with Per-Part RAG Replacement & Encapsulate as Template */}
            <div className="rounded-xl border border-indigo-500/40 bg-slate-900 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-[11px] font-semibold text-indigo-400">
                    🎯 最终交付成果
                  </span>
                  <h3 className="mt-0.5 text-sm font-semibold text-white">
                    {agentDeliverable.title}
                  </h3>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    title="基于门店知识库切换爆款标题"
                    onClick={handleReplaceDeliverableTitle}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-indigo-300 hover:bg-slate-700 cursor-pointer"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>换标题</span>
                  </button>
                  <button
                    type="button"
                    title="基于门店知识库切换封面大字"
                    onClick={handleReplaceDeliverableCover}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-indigo-300 hover:bg-slate-700 cursor-pointer"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>换封面字</span>
                  </button>
                  <button
                    type="button"
                    title="基于门店知识库切换整套分镜台词"
                    onClick={handleReplaceDeliverableScript}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-indigo-300 hover:bg-slate-700 cursor-pointer"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>换全套脚本</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3 text-xs">
                <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">封面大字主视觉：</span>
                  <span className="font-semibold text-amber-300">
                    「{agentDeliverable.coverHeadline}」 · {agentDeliverable.coverSubhead}
                  </span>
                </div>
                <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">适用方向：</span>
                  <span className="text-slate-200">{agentDeliverable.suitableDirection}</span>
                </div>
                <div className="rounded-lg bg-slate-950/80 p-2.5 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">推荐素材：</span>
                  <span className="text-slate-200">{agentDeliverable.suitableMaterial}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {agentDeliverable.cameraAngles.map((ang, idx) => (
                  <div
                    key={idx}
                    className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 text-xs"
                  >
                    <div className="font-semibold text-indigo-400">{ang}</div>
                    <div className="mt-1 text-slate-400 line-clamp-1">
                      画面：{agentDeliverable.visualCues[idx]}
                    </div>
                    <div className="mt-0.5 text-slate-100">
                      口播：“{agentDeliverable.sceneLines[idx]}”
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
                {onEncapsulateAsTemplate && (
                  <button
                    type="button"
                    onClick={() => {
                      const newTpl: CuratedTemplate = {
                        id: `agent_tpl_${Date.now()}`,
                        title: agentDeliverable.title,
                        category: activeStore.industry || '个护',
                        templateTab: '带货口播模板',
                        contentType: '痛点对比',
                        posterHeadline: agentDeliverable.coverHeadline,
                        posterSubhead: agentDeliverable.coverSubhead,
                        posterTag: `${activeStore.industry || '爆款'} · 智能封装`,
                        sourcePlatform: '抖音原片',
                        sourceAuthor: `@${activeStore.storeName.slice(0, 10)}`,
                        sourceUrl: 'https://www.douyin.com/',
                        durationText: '00:15',
                        likesCountText: '8.9w',
                        qualityScore: 99,
                        accentFrom: '#1e1b4b',
                        accentTo: '#312e81',
                        coverSceneType: 'shampoo',
                        coverPhotoUrl:
                          'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=900&q=80',
                        hookFormula: agentDeliverable.sceneLines[0],
                        structureSummary:
                          '痛点提问(3s) + 产品微距(4s) + 实测对比(4s) + 福利促单(4s)',
                        suitableDirections: agentDeliverable.suitableDirection,
                        suitableMaterials: agentDeliverable.suitableMaterial,
                        pacingStyle: 'Agent高完播卡点',
                        bgmStyle: '轻快种草卡点律动',
                        defaultProductName: defaultProdName,
                        defaultSellingPoints: sellingPoints,
                        defaultAudience: activeStore.targetAudience,
                        cameraAngles: [...agentDeliverable.cameraAngles],
                        visualCues: [...agentDeliverable.visualCues],
                        sceneLines: [...agentDeliverable.sceneLines],
                      };
                      onEncapsulateAsTemplate(newTpl);
                      setEncapsulatedDone(true);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-amber-400/50 bg-amber-500/20 px-3.5 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-500/30 cursor-pointer"
                  >
                    <BookmarkPlus className="h-3.5 w-3.5" />
                    <span>
                      {encapsulatedDone
                        ? '✓ 已存入爆款库'
                        : '✨ 封装成模板'}
                    </span>
                  </button>
                )}

                {onApplyAgentDeliverableToEditor && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        onApplyAgentDeliverableToEditor({
                          title: agentDeliverable.title,
                          productName: defaultProdName,
                          sellingPoints,
                          cameraAngles: agentDeliverable.cameraAngles,
                          visualCues: agentDeliverable.visualCues,
                          sceneLines: agentDeliverable.sceneLines,
                          openMixImmediately: false,
                        })
                      }
                      className="inline-flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-semibold text-slate-900 hover:bg-slate-100 cursor-pointer"
                    >
                      <FileText className="h-3.5 w-3.5" />
                      <span>载入分镜台</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onApplyAgentDeliverableToEditor({
                          title: agentDeliverable.title,
                          productName: defaultProdName,
                          sellingPoints,
                          cameraAngles: agentDeliverable.cameraAngles,
                          visualCues: agentDeliverable.visualCues,
                          sceneLines: agentDeliverable.sceneLines,
                          openMixImmediately: true,
                        })
                      }
                      className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer"
                    >
                      <Play className="h-3.5 w-3.5 fill-white" />
                      <span>合成成片</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 6. Symmetrical 4×4 Creation Matrix (Widened to 1360px to fill the canvas comfortably) */}
      <div className="relative mx-auto max-w-[1360px] w-full mt-8 border-t border-slate-100 pt-6">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-slate-900">
              全链路智能创作矩阵
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {showAllCapabilities && (
              <div className="flex flex-wrap items-center gap-1 rounded-xl bg-slate-100 p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveMatrixFilter('ALL')}
                  className={`rounded-lg px-2.5 py-1 font-medium transition-colors cursor-pointer ${
                    activeMatrixFilter === 'ALL'
                      ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  全部 (16)
                </button>
                {KUAIZI_CAPABILITY_GROUPS.map((g) => (
                  <button
                    key={g.groupTitle}
                    type="button"
                    onClick={() => setActiveMatrixFilter(g.groupTitle)}
                    className={`rounded-lg px-2.5 py-1 font-medium transition-colors cursor-pointer ${
                      activeMatrixFilter === g.groupTitle
                        ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {g.groupTitle.replace(/^0\d\s·\s/, '')}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowAllCapabilities(!showAllCapabilities)}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-600 hover:border-sky-300 hover:text-[#24568d] cursor-pointer"
            >
              {showAllCapabilities ? '精简收起' : '展开工具矩阵'}
            </button>
          </div>
        </div>

        {showAllCapabilities && (
          <div
            className={`grid grid-cols-1 gap-4 ${
              visibleGroups.length === 1
                ? 'sm:grid-cols-1'
                : 'sm:grid-cols-2 lg:grid-cols-4'
            }`}
          >
            {visibleGroups.map((group) => (
              <div
                key={group.groupTitle}
                className="flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-slate-50/40 p-3.5 transition-all hover:border-sky-300/80"
              >
                {/* Group Stage Header */}
                <div className="mb-3 flex items-center justify-between px-1">
                  <span className="text-xs font-semibold text-slate-800">
                    {group.groupTitle.replace(/^0\d\s·\s/, '')}
                  </span>
                  <span className="font-mono text-[11px] text-slate-400">
                    {group.items.length} 项
                  </span>
                </div>

                {/* Clean 2x2 or 4-item Grid per Card */}
                <div className="grid grid-cols-2 gap-2">
                  {group.items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      title={item.shortDesc}
                      onClick={() => onSelectCapability(item.id)}
                      className="group/cap flex items-center justify-between gap-1.5 rounded-xl border border-slate-200/80 bg-white px-3 py-2.5 text-left transition-all hover:border-sky-300 hover:bg-sky-50/40 cursor-pointer"
                    >
                      <span className="truncate text-xs font-medium text-slate-700 group-hover/cap:text-[#24568d]">
                        {item.label}
                      </span>
                      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-300 transition-transform group-hover/cap:translate-x-0.5 group-hover/cap:text-[#3572b0]" />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Skill 技能广场弹窗 (GitHub / SkillHub 直连，页面浏览/一键装载/分类排序) */}
      <SkillHubMarketplaceModal
        isOpen={isSkillMarketOpen}
        onClose={() => setIsSkillMarketOpen(false)}
        mountedSkillIds={selectedSkillIds}
        onToggleMountSkill={(skillId) => {
          setSelectedSkillIds((prev) =>
            prev.includes(skillId)
              ? prev.filter((id) => id !== skillId)
              : [...prev, skillId]
          );
        }}
        activeStore={activeStore}
        onNotice={(type, msg) => {
          // Toast status
        }}
      />
    </section>
  );
};

/**
 * 16项全能创作工具弹窗（支持所有工具ID：每日视频洞察、多语言AI配音、数字人视频、小红书/多场景文本、矩阵宝多平台分发、Banner千人千面、广告投放ROI诊断）
 */
export const KuaiziQuickToolModal: React.FC<{
  toolId: KuaiziToolId | null;
  onClose: () => void;
  productName: string;
  sellingPoints: string;
  sceneLines: string[];
  activeStore: StoreMemoryProfile;
  onApplyTextToScript: (newLines: string[], newTitle?: string) => void;
  onOpenMixPlayer: () => void;
}> = ({
  toolId,
  onClose,
  productName,
  sellingPoints,
  sceneLines,
  activeStore,
  onApplyTextToScript,
  onOpenMixPlayer,
}) => {
  const [selectedLang, setSelectedLang] = useState('zh-CN');
  const [selectedVoiceStyle, setSelectedVoiceStyle] = useState('甜美种草女声');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState('轻奢女主播 · 林悦');
  const [selectedSceneType, setSelectedSceneType] = useState('小红书高赞种草笔记');
  const [generatedCopy, setGeneratedCopy] = useState('');
  const [copied, setCopied] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([
    '抖音短视频',
    '小红书笔记',
    '微信视频号',
  ]);
  const [matrixPublished, setMatrixPublished] = useState(false);

  if (!toolId) return null;

  const speakPreview = (text: string, lang: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = lang;
    utter.rate = 1.05;
    utter.onstart = () => setIsSpeaking(true);
    utter.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utter);
  };

  const generateMultiSceneCopy = (type: string) => {
    setSelectedSceneType(type);
    if (type === '小红书高赞种草笔记') {
      setGeneratedCopy(
        `📌 标题：后悔没早买！${productName}真实实测，第3秒直接被惊艳！\n\n姐妹们！之前踩过无数坑，直到试了【${activeStore.storeName}】的这款${productName}！\n✨ 核心亮点：${sellingPoints}\n💡 实测体验：上手质感绝了，细节完全经得起放大看，现在不管是日常自用还是囤货都超划算！\n\n#${productName.replace(/\s+/g, '')} #好物分享 #真实测评 #宝藏店铺`
      );
    } else if (type === '抖音直播高转化逼单话术') {
      setGeneratedCopy(
        `【直播间黄金60秒逼单话术】\n主播：所有刚进直播间的朋友们注意！今天不需要大家花冤枉钱，我们【${activeStore.storeName}】把招牌的「${productName}」直接拿到直播间炸福利！\n助播：核心升级了${sellingPoints}！\n主播：3、2、1 上链接！前50名拍下直接享同城/专享补贴价，手慢无！`
      );
    } else {
      setGeneratedCopy(
        `【微信视频号/朋友圈私域种草文案】\n老顾客都在问的「${productName}」终于补货了！\n主打：${sellingPoints}\n欢迎同城朋友直接到店体验（${activeStore.cityLocation}），或点击下方视频号链接一键下单！`
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
      <div className="w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">
              {toolId === 'daily_insight' && '每日视频洞察 · 行业爆款风向标'}
              {toolId === 'multi_lang_tts' && '多语言 AI 配音工作台'}
              {toolId === 'digital_human' && '4K 数字人口播视频合成'}
              {(toolId === 'xhs_copy' || toolId === 'multi_scene_text') &&
                '小红书与多场景 AI 爆款文案生成'}
              {toolId === 'banner_personalize' && 'Banner 千人千面 · 多尺寸投流裂变'}
              {toolId === 'matrix_publish' && '矩阵宝 · 多平台多账号一键分发'}
              {toolId === 'ad_placement' && '广告投放 · 千川/本地推素材 ROI 诊断'}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => {
              if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                window.speechSynthesis.cancel();
              }
              onClose();
            }}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[80vh] overflow-y-auto p-6 space-y-4">
          {toolId === 'daily_insight' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500">
                实时聚合今日抖音、小红书、快手飙升最快的 3 类黄金前 3 秒钩子公式，点击即可一键套用到当前商品「{productName}」：
              </p>
              {[
                {
                  rank: 'TOP 1',
                  title: '反常识痛点提问流（今日完播率 +41%）',
                  hook: `千万别再盲目买传统产品了！真正懂行的人选${productName}只看这1点！`,
                  rate: '前3秒留存 84.2%',
                },
                {
                  rank: 'TOP 2',
                  title: '沉浸式微距实测反差流（今日转化率 +28%）',
                  hook: `花3秒钟把镜头拉到最近，看看${productName}到底凭什么能成断货王！`,
                  rate: '组件点击率 6.4%',
                },
                {
                  rank: 'TOP 3',
                  title: '主理人真诚探厂/到店流（今日同城核销 +53%）',
                  hook: `在${activeStore.cityLocation}做了8年，今天把我们店里最招牌的${productName}底价拿出来！`,
                  rate: '赞评互动率 8.1%',
                },
              ].map((item) => (
                <div
                  key={item.rank}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50/70 p-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-mono font-bold text-indigo-600">{item.rank}</span>
                      <span className="font-bold text-slate-900">{item.title}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-emerald-600 font-medium">{item.rate}</span>
                    </div>
                    <p className="text-xs text-slate-600">黄金首句：“{item.hook}”</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const next = [...sceneLines];
                      if (next.length > 0) next[0] = item.hook;
                      else next.push(item.hook);
                      onApplyTextToScript(next, `${productName} · ${item.title}`);
                      onClose();
                    }}
                    className="shrink-0 rounded-lg bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                  >
                    一键套用此洞察
                  </button>
                </div>
              ))}
            </div>
          )}

          {toolId === 'multi_lang_tts' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {[
                  { code: 'zh-CN', label: '普通话 · 活力种草', voice: '甜美种草女声' },
                  { code: 'zh-HK', label: '粤语 · 港风探店', voice: '地道粤语主播' },
                  { code: 'en-US', label: 'English · 跨境TikTok', voice: '北美原生带货声' },
                  { code: 'ja-JP', label: '日本語 · 日系好物', voice: '东京温柔女声' },
                  { code: 'ko-KR', label: '한국어 · 韩系美妆', voice: '首尔时尚男/女声' },
                  { code: 'es-ES', label: 'Español · 拉美电商', voice: '热情拉美主播' },
                ].map((l) => (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => {
                      setSelectedLang(l.code);
                      setSelectedVoiceStyle(l.voice);
                    }}
                    className={`rounded-xl border p-3 text-left transition-all cursor-pointer ${
                      selectedLang === l.code
                        ? 'border-indigo-500 bg-indigo-50/60 text-indigo-900'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold">{l.label}</div>
                    <div className="mt-0.5 text-[11px] text-slate-500">{l.voice}</div>
                  </button>
                ))}
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <div className="text-xs font-semibold text-slate-700 mb-1.5">
                  当前配音台词预览（已自动关联您的分镜台词）：
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {sceneLines.join(' ') || `欢迎体验${productName}，${sellingPoints}！`}
                </p>
              </div>

              <div className="flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() =>
                    speakPreview(
                      sceneLines.join(' ') || `欢迎体验${productName}，${sellingPoints}`,
                      selectedLang
                    )
                  }
                  className="flex items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 cursor-pointer"
                >
                  <Volume2 className="h-4 w-4" />
                  <span>{isSpeaking ? '正在播报试听...' : `在线试听 (${selectedVoiceStyle})`}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenMixPlayer();
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <Play className="h-3.5 w-3.5 fill-white" />
                  <span>合成配音成片</span>
                </button>
              </div>
            </div>
          )}

          {toolId === 'digital_human' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">
                选择 AI 数字人主播形象，无需真人出镜即可将当前分镜口播台词合成为口型 1:1 同步的带货视频：
              </p>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                {[
                  {
                    name: '轻奢女主播 · 林悦',
                    scene: '美妆 / 个护 / 穿搭种草',
                    photo:
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
                  },
                  {
                    name: '金牌店长 · 陈诚',
                    scene: '本地生活 / 餐饮 / 家居实测',
                    photo:
                      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
                  },
                  {
                    name: '专业评测官 · 苏瑾',
                    scene: '数码 / 教育 / 宠物科普',
                    photo:
                      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
                  },
                ].map((av) => (
                  <button
                    key={av.name}
                    type="button"
                    onClick={() => setSelectedAvatar(av.name)}
                    className={`overflow-hidden rounded-xl border text-left transition-all cursor-pointer ${
                      selectedAvatar === av.name
                        ? 'border-indigo-600 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <img
                      src={av.photo}
                      alt={av.name}
                      className="h-36 w-full object-cover"
                    />
                    <div className="p-3">
                      <div className="text-xs font-bold text-slate-900">{av.name}</div>
                      <div className="mt-0.5 text-[11px] text-slate-500">{av.scene}</div>
                    </div>
                  </button>
                ))}
              </div>
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenMixPlayer();
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <UserCheck className="h-4 w-4" />
                  <span>使用「{selectedAvatar}」一键合成口播视频</span>
                </button>
              </div>
            </div>
          )}

          {(toolId === 'xhs_copy' || toolId === 'multi_scene_text') && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {[
                  '小红书高赞种草笔记',
                  '抖音直播高转化逼单话术',
                  '微信视频号/朋友圈私域种草文案',
                ].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => generateMultiSceneCopy(t)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold cursor-pointer ${
                      selectedSceneType === t
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <textarea
                rows={7}
                value={
                  generatedCopy ||
                  `📌 标题：后悔没早买！${productName}真实实测，第3秒直接被惊艳！\n\n姐妹们！之前踩过无数坑，直到试了【${activeStore.storeName}】的这款${productName}！\n✨ 核心亮点：${sellingPoints}\n💡 实测体验：上手质感绝了，细节完全经得起放大看，现在不管是日常自用还是囤货都超划算！\n\n#${productName.replace(/\s+/g, '')} #好物分享 #真实测评 #宝藏店铺`
                }
                onChange={(e) => setGeneratedCopy(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs leading-relaxed text-slate-800 focus:border-indigo-500 focus:bg-white focus:outline-none"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const text =
                      generatedCopy ||
                      `后悔没早买！${productName}真实实测，核心亮点：${sellingPoints}`;
                    navigator.clipboard.writeText(text);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2500);
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copied ? '已复制全文' : '一键复制爆款文案'}</span>
                </button>
              </div>
            </div>
          )}

          {toolId === 'matrix_publish' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">
                勾选目标分发平台，AI 将自动适配各平台标题字数、话题标签与封面比例并生成矩阵发布任务：
              </p>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                {[
                  '抖音短视频',
                  '小红书笔记',
                  '微信视频号',
                  '快手短视频',
                  'B站动态/视频',
                  '抖音来客团购门店',
                ].map((plat) => {
                  const checked = selectedPlatforms.includes(plat);
                  return (
                    <button
                      key={plat}
                      type="button"
                      onClick={() =>
                        setSelectedPlatforms((prev) =>
                          prev.includes(plat)
                            ? prev.filter((p) => p !== plat)
                            : [...prev, plat]
                        )
                      }
                      className={`flex items-center justify-between rounded-xl border p-3 text-xs font-semibold cursor-pointer ${
                        checked
                          ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900'
                          : 'border-slate-200 bg-white text-slate-600'
                      }`}
                    >
                      <span>{plat}</span>
                      {checked && <Check className="h-4 w-4 text-indigo-600" />}
                    </button>
                  );
                })}
              </div>
              {matrixPublished && (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs font-medium text-emerald-800">
                  ✓ 已为您生成 {selectedPlatforms.length} 个平台的专属标题、标签与排期分发任务！
                </div>
              )}
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setMatrixPublished(true)}
                  className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <Share2 className="h-3.5 w-3.5" />
                  <span>一键创建多平台矩阵发布 ({selectedPlatforms.length}个平台)</span>
                </button>
              </div>
            </div>
          )}

          {toolId === 'ad_placement' && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
                  <div className="text-[11px] text-slate-500">预估前3秒留存率</div>
                  <div className="mt-1 font-mono text-xl font-bold text-indigo-600">83.6%</div>
                  <div className="mt-0.5 text-[11px] text-emerald-600">优于同行业 88% 素材</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
                  <div className="text-[11px] text-slate-500">预估千川/本地推 CTR</div>
                  <div className="mt-1 font-mono text-xl font-bold text-slate-900">5.8%</div>
                  <div className="mt-0.5 text-[11px] text-slate-500">痛点与利益点清晰</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5">
                  <div className="text-[11px] text-slate-500">建议首发投流人群</div>
                  <div className="mt-1 text-xs font-bold text-slate-900 line-clamp-2">
                    {activeStore.targetAudience}
                  </div>
                </div>
              </div>
              <div className="rounded-xl border border-indigo-100 bg-indigo-50/50 p-4 text-xs text-slate-700 space-y-1.5">
                <div className="font-bold text-indigo-950">AI 投流优化建议：</div>
                <p>
                  1. 前 1.5 秒建议叠加醒目花字标签「{productName.slice(0, 10)}实测」，提升静音状态下的停留率。
                </p>
                <p>
                  2. 第 3 镜展示「{sellingPoints.slice(0, 20)}」前后对比时节奏可加快 0.5 秒，直接衔接左下角团购/小黄车组件。
                </p>
              </div>
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenMixPlayer();
                  }}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  导出千川高清投流成片
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * 右侧可折叠 RAG 知识库 AI 侧栏助手 (精准定位当前门店画像 + 爆款知识库 + 实时脚本诊断与一键注入)
 */
export const RagCopilotSidebar: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  storeMemoryEnabled: boolean;
  activeStore: StoreMemoryProfile;
  productName: string;
  sellingPoints: string;
  cameraAngles: string[];
  visualCues: string[];
  sceneLines: string[];
  onApplyHookToFirstShot: (newHookLine: string, newVisual?: string) => void;
  onApplyFullScriptFromRag: (payload: {
    title: string;
    cameraAngles: string[];
    visualCues: string[];
    sceneLines: string[];
  }) => void;
  onOpenStoreConfig: () => void;
}> = ({
  isOpen,
  onClose,
  storeMemoryEnabled,
  activeStore,
  productName,
  sellingPoints,
  cameraAngles,
  sceneLines,
  onApplyHookToFirstShot,
  onApplyFullScriptFromRag,
  onOpenStoreConfig,
}) => {
  const [inputMsg, setInputMsg] = useState('');
  const [messages, setMessages] = useState<
    {
      id: string;
      role: 'assistant' | 'user';
      text: string;
      actionHook?: string;
      actionFullScript?: {
        title: string;
        cameraAngles: string[];
        visualCues: string[];
        sceneLines: string[];
      };
    }[]
  >(() => [
    {
      id: 'welcome_rag',
      role: 'assistant',
      text: `您好！我是您的 **RAG 专属智库编导助手**。\n已实时检索挂载知识库：\n• 门店画像：${activeStore.storeName}（${activeStore.cityLocation}）\n• 核心锚点：${activeStore.memoryAnchors}\n• 当前脚本共 ${cameraAngles.length} 个镜头。\n\n您可以直接点击下方快捷指令，或输入任何问题，我会基于您的门店与商品知识库提供精准方案：`,
    },
  ]);

  if (!isOpen) return null;

  const handleQuickRagAction = (actionType: 'diagnose' | 'hooks' | 'laike' | 'full_custom') => {
    const userLabelMap = {
      diagnose: '🎯 诊断当前脚本完播率与痛点改进建议',
      hooks: '🔥 基于本店 RAG 知识库生成 3 个黄金前3秒钩子',
      laike: '📢 生成抖音来客同城到店核销促单台词',
      full_custom: '✨ 结合本店招牌卖点重新定制 4 镜高转化脚本',
    };

    const userMsg = {
      id: `u_${Date.now()}`,
      role: 'user' as const,
      text: userLabelMap[actionType],
    };

    let replyMsg: (typeof messages)[number];

    if (actionType === 'diagnose') {
      const firstLine = sceneLines[0] || '暂无首镜台词';
      replyMsg = {
        id: `a_${Date.now() + 1}`,
        role: 'assistant',
        text: `【RAG 知识库精准诊断报告】\n1. **首镜钩子评估**：当前首句为“${firstLine.slice(0, 28)}...”，建议直接前置【${activeStore.cityLocation}】地域标签或具体数字反差，前3秒留存可提升约 26%。\n2. **卖点命中度**：已覆盖「${productName}」，建议在第 3 镜强化「${activeStore.memoryAnchors.slice(0, 28)}」信任背书。`,
        actionHook: `${activeStore.cityLocation}的朋友先别划走！为什么懂行的人选${productName}都认准我们店这一个细节？`,
      };
    } else if (actionType === 'hooks') {
      const hookOption = `刚发现很多朋友买${productName}都在交智商税！今天用${activeStore.storeName}的实测对比教你3秒看懂！`;
      replyMsg = {
        id: `a_${Date.now() + 1}`,
        role: 'assistant',
        text: `已从 **RAG 门店画像库** 检索并生成 3 条高留存开头：\n\n① **痛点反问流**：“${hookOption}”\n② **同城背书流**：“在${activeStore.cityLocation}火了这么久，我们店的${productName}到底凭什么全是回头客？”\n③ **视觉微距流**：“把镜头放大10倍看细节！真正好的${productName}经得起这样实测！”`,
        actionHook: hookOption,
      };
    } else if (actionType === 'laike') {
      const ctaLine = `同城的朋友注意！现在点击左下角【${activeStore.storeName}】专属团购链接，立享${activeStore.memoryAnchors.slice(0, 22)}，随时可退、过期自动退，赶紧囤一张！`;
      replyMsg = {
        id: `a_${Date.now() + 1}`,
        role: 'assistant',
        text: `已为您定制符合 **抖音来客 POI 团购规范** 的高转化收尾台词：\n\n“${ctaLine}”`,
        actionHook: ctaLine,
      };
    } else {
      const customPayload = {
        title: `${activeStore.storeName} · ${productName.slice(0, 12)}专属定制脚本`,
        cameraAngles: [
          '01 同城痛点强钩子',
          '02 镇店爆品微距特写',
          '03 核心卖点实测对比',
          '04 抖音来客团购逼单',
        ],
        visualCues: [
          `【${activeStore.cityLocation}门店实景】主理人出镜直击「${activeStore.targetAudience}」高频痛点。`,
          `4K微距推镜展示「${productName}」的核心质感与细节。`,
          `分屏实测「${sellingPoints}」的前后明显对比效果。`,
          `展示门店真实好评墙与左下角团购福利字卡。`,
        ],
        sceneLines: [
          `${activeStore.cityLocation}的朋友注意！选${productName}千万别再盲目跟风了！`,
          `看看我们【${activeStore.storeName}】镇店的这款${productName}，细节质感直接拉满！`,
          `它最大的优势就是${sellingPoints}，用过一次就知道为什么回头客这么多了！`,
          `现在点击左下角团购专属福利：${activeStore.memoryAnchors.slice(0, 26)}，赶紧抢购体验吧！`,
        ],
      };
      replyMsg = {
        id: `a_${Date.now() + 1}`,
        role: 'assistant',
        text: `已结合 **${activeStore.storeName}** 长期记忆库为您生成全套 4 镜专属脚本，点击下方按钮即可一键载入分镜表：`,
        actionFullScript: customPayload,
      };
    }

    setMessages((prev) => [...prev, userMsg, replyMsg]);
  };

  const handleSendCustomQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;
    const q = inputMsg.trim();
    setInputMsg('');

    const userMsg = {
      id: `u_${Date.now()}`,
      role: 'user' as const,
      text: q,
    };

    const customHook = `针对您提到的「${q.slice(0, 18)}」，推荐黄金首句：为什么90%的人在选${productName}时都忽略了这个核心细节？`;
    const replyMsg = {
      id: `a_${Date.now() + 1}`,
      role: 'assistant' as const,
      text: `已检索 **${activeStore.storeName}** 知识库与行业爆款库为您精准定位解答：\n\n• **核心策略**：结合您门店「${activeStore.storePersona}」人设，建议在前 3 秒直接用视觉反差切入，中段突出「${sellingPoints.slice(0, 28)}」，结尾挂载同城/专属福利锚点。\n• **可直接套用的高赞口播**：“${customHook}”`,
      actionHook: customHook,
    };

    setMessages((prev) => [...prev, userMsg, replyMsg]);
  };

  return (
    <aside className="fixed inset-y-0 right-0 z-40 flex w-88 flex-col border-l border-slate-200 bg-white shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3.5">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white">
            <Bot className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-900">RAG 智库 AI 编导助手</h3>
            <p className="text-[10px] text-emerald-600">
              {storeMemoryEnabled ? `已挂载：${activeStore.storeName.slice(0, 12)}` : '通用行业爆款库已就绪'}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Mounted Knowledge Base Status Strip */}
      <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-2 text-[11px]">
        <div className="flex items-center gap-1.5 text-slate-600 truncate">
          <Store className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
          <span className="truncate">知识源：{activeStore.storeName}</span>
        </div>
        <button
          type="button"
          onClick={onOpenStoreConfig}
          className="shrink-0 font-semibold text-indigo-600 hover:underline cursor-pointer"
        >
          切换/配置知识库
        </button>
      </div>

      {/* Chat Messages Area */}
      <div className="flex-1 space-y-3 overflow-y-auto p-4 text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[92%] rounded-2xl px-3.5 py-2.5 leading-relaxed whitespace-pre-line ${
                m.role === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'border border-slate-200/90 bg-slate-50/90 text-slate-800'
              }`}
            >
              {m.text}

              {m.actionHook && (
                <div className="mt-2.5 border-t border-slate-200/80 pt-2">
                  <button
                    type="button"
                    onClick={() => onApplyHookToFirstShot(m.actionHook!)}
                    className="flex w-full items-center justify-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                  >
                    <Check className="h-3 w-3" />
                    <span>一键填入当前脚本首镜台词</span>
                  </button>
                </div>
              )}

              {m.actionFullScript && (
                <div className="mt-2.5 border-t border-slate-200/80 pt-2">
                  <button
                    type="button"
                    onClick={() => onApplyFullScriptFromRag(m.actionFullScript!)}
                    className="flex w-full items-center justify-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                  >
                    <Sparkles className="h-3 w-3" />
                    <span>一键替换并载入此 4 镜脚本</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Precision Action Prompts */}
      <div className="border-t border-slate-100 bg-slate-50/60 px-3.5 py-2.5">
        <div className="mb-1.5 text-[10px] font-semibold text-slate-400">
          RAG 精准定位快捷指令：
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            type="button"
            onClick={() => handleQuickRagAction('diagnose')}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-left text-[11px] font-medium text-slate-700 hover:border-indigo-400 hover:text-indigo-600 truncate cursor-pointer"
          >
            🎯 诊断当前脚本完播率
          </button>
          <button
            type="button"
            onClick={() => handleQuickRagAction('hooks')}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-left text-[11px] font-medium text-slate-700 hover:border-indigo-400 hover:text-indigo-600 truncate cursor-pointer"
          >
            🔥 生成3个本店前3秒钩子
          </button>
          <button
            type="button"
            onClick={() => handleQuickRagAction('laike')}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-left text-[11px] font-medium text-slate-700 hover:border-indigo-400 hover:text-indigo-600 truncate cursor-pointer"
          >
            📢 抖音来客核销促单话术
          </button>
          <button
            type="button"
            onClick={() => handleQuickRagAction('full_custom')}
            className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-left text-[11px] font-medium text-slate-700 hover:border-indigo-400 hover:text-indigo-600 truncate cursor-pointer"
          >
            ✨ 定制本店4镜专属脚本
          </button>
        </div>
      </div>

      {/* Input Box */}
      <form
        onSubmit={handleSendCustomQuestion}
        className="flex items-center gap-2 border-t border-slate-200 bg-white p-3"
      >
        <input
          type="text"
          value={inputMsg}
          onChange={(e) => setInputMsg(e.target.value)}
          placeholder="向 RAG 智库提问，例如：怎么突出同城价格优势..."
          className="h-9 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none"
        />
        <button
          type="submit"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
        >
          <Send className="h-3.5 w-3.5" />
        </button>
      </form>
    </aside>
  );
};
