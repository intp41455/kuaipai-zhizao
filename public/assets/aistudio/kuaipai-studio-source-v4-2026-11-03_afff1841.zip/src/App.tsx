import React, { useEffect, useState, useMemo } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';
import {
  Sparkles,
  Film,
  Scissors,
  LayoutGrid,
  FolderKanban,
  Wand2,
  Search,
  Play,
  Star,
  Plus,
  Trash2,
  Check,
  ChevronLeft,
  RefreshCw,
  LogIn,
  LogOut,
  Save,
  Copy,
  FileText,
  Table,
  Zap,
  BookmarkCheck,
  AlertCircle,
  Crown,
  KeyRound,
  Share2,
  Download,
  ExternalLink,
  Store,
  BrainCircuit,
  GitBranch,
  ArrowUp,
  ArrowDown,
  Image as ImageIcon,
  SlidersHorizontal,
  Cpu,
  Phone,
  Layers,
  ChevronRight,
} from 'lucide-react';
import {
  auth,
  db,
  googleProvider,
  OperationType,
  handleFirestoreError,
  buildUserProfileCreatePayload,
  buildUserProfileBillingUpdatePayload,
  buildVideoProjectCreatePayload,
  buildVideoProjectUpdatePayload,
  buildViralTemplateCreatePayload,
  buildVideoDissectionCreatePayload,
  buildSharedProjectLinkCreatePayload,
  buildStoreProfileCreatePayload,
  buildStoreProfileUpdatePayload,
} from './firebase';
import {
  CURATED_TEMPLATES,
  CuratedTemplate,
  TEMPLATE_TABS,
  INDUSTRY_CATEGORIES,
  CONTENT_TYPES,
  QUICK_DISSECT_SAMPLES,
  PRESET_STORE_PROFILES,
  StoreMemoryProfile,
  DISSECT_SKILL_PACKAGES,
} from './data/curatedTemplates';
import { VideoMixPlayerModal } from './components/VideoMixPlayerModal';
import {
  OriginalWorkCoverScene,
  ShareAndPlatformModal,
  MultiAssetExportModal,
  ProjectExportData,
} from './components/ShareAndExportModals';
import {
  HoverTip,
  DomesticLoginModal,
  DomesticUserSession,
  AIModelGatewayModal,
  AIModelGatewayConfig,
  DEFAULT_GATEWAY_CONFIG,
  EcommerceSuiteAndGraphicWorkspace,
  SystemManualModal,
} from './components/DomesticAuthAndGatewayModals';
import { MerchantManagementCenter } from './components/MerchantAndWorkspaceModules';
import {
  ViralTemplateStudioModal,
  ViralDissectionWorkspace,
} from './components/ViralTemplateStudioModal';
import {
  KuaiziAgentHomeWorkbench,
  KuaiziQuickToolModal,
  RagCopilotSidebar,
  KuaiziToolId,
} from './components/KuaiziAgentWorkbenchAndRagCopilot';
import {
  AIVideoRemixDualStudio,
  RemixStudioMode,
} from './components/AIVideoRemixDualStudio';
import {
  PersonalAgentRagStudioModal,
  CustomAIAgent,
} from './components/PersonalAgentRagStudioModal';
import {
  Users,
  PanelLeftClose,
  PanelLeftOpen,
  GripVertical,
  Globe,
  Bot,
  Sparkles as SparklesIcon,
  ChevronsUp,
  ChevronsDown,
  History,
  ChevronDown,
  ChevronUp,
  Sliders,
} from 'lucide-react';

type NavTab =
  | 'workbench'
  | 'templates'
  | 'video_remix'
  | 'graphic_suite'
  | 'store_kb'
  | 'editor'
  | 'dissect'
  | 'my_projects'
  | 'my_saved'
  | 'pricing';

interface UserHistoryRecord {
  id: string;
  type: 'prompt' | 'action' | 'project';
  title: string;
  subtitle: string;
  timeText: string;
  targetNav: NavTab;
  payloadPrompt?: string;
}

interface CloudVideoProject {
  id: string;
  ownerId: string;
  title: string;
  productName: string;
  sellingPoints: string;
  targetAudience: string;
  category: string;
  aspectRatio: '9:16' | '16:9' | '4:3';
  bgmStyle: string;
  voiceTone: string;
  pacingTip: string;
  sceneLines: string[];
  visualCues: string[];
  cameraAngles: string[];
}

interface CloudViralTemplate {
  id: string;
  ownerId: string;
  title: string;
  category: string;
  hookFormula: string;
  structureSummary: string;
  pacingStyle: string;
  bgmStyle: string;
  sceneLines: string[];
  visualCues: string[];
  cameraAngles: string[];
}

interface CloudDissection {
  id: string;
  ownerId: string;
  sourceTitle: string;
  sourceContent: string;
  hookAnalysis: string;
  retentionSecret: string;
  conversionTrigger: string;
  extractedFormula: string;
  sceneBreakdown: string[];
}

interface CloudStoreProfile extends StoreMemoryProfile {
  ownerId: string;
}

const QUICK_PRODUCT_PRESETS = [
  {
    label: '去屑控油洗发水',
    productName: '星澜氨基酸去屑控油洗发水',
    sellingPoints: '深层净澈头皮、72小时长效控油高颅顶、温和去屑止痒',
    targetAudience: '熬夜油头、有头屑困扰的上班族与学生党',
    category: '个护',
  },
  {
    label: '低温烘焙鲜肉猫粮',
    productName: '90%高鲜肉低温烘焙全价猫粮',
    sellingPoints: '0谷物0肉粉低敏护肠胃、颗粒干爽不黑下巴、适口性极佳',
    targetAudience: '养猫铲屎官、挑食猫咪家庭',
    category: '宠物',
  },
  {
    label: '原木风全屋定制套餐',
    productName: '谷木ENF级原木奶油风全屋定制套餐',
    sellingPoints: '全屋同色系直拼无色差、ENF级零醛环保板材、同城免费上门量房送3D图',
    targetAudience: '准备毛坯装修、老房翻新的同城业主家庭',
    category: '家居',
  },
  {
    label: '冷萃闪溶黑咖啡',
    productName: '庄园级阿拉比卡冷萃冻干黑咖啡',
    sellingPoints: '冰水牛奶3秒即溶、0蔗糖0脂肪、一杯不到3元还原现磨油脂',
    targetAudience: '早八通勤打工人、减脂健身人群',
    category: '咖啡',
  },
];

const BUILTIN_VOUCHERS: Record<
  string,
  { tier: 'free' | 'pro' | 'enterprise'; addCredits: number; label: string }
> = {
  'VIP-PRO-2026': {
    tier: 'pro',
    addCredits: 1000,
    label: '专业创作者月卡（+1,000 算力点）',
  },
  'VIP-MAX-2026': {
    tier: 'enterprise',
    addCredits: 10000,
    label: '企业MCN尊享版（+10,000 算力点）',
  },
  'CREDITS-200': {
    tier: 'free',
    addCredits: 200,
    label: '200 算力加油包',
  },
};

export default function App() {
  // Navigation & Auth State (Default home is 'workbench' AI Agent dialog workbench)
  const [activeNav, setActiveNav] = useState<NavTab>('workbench');
  const [remixStudioMode, setRemixStudioMode] = useState<RemixStudioMode>('foolproof');
  const [merchantSubTab, setMerchantSubTab] = useState<'staff' | 'stores' | 'materials'>('stores');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [navSectionsOpen, setNavSectionsOpen] = useState<{
    workbench: boolean;
    creation: boolean;
    merchant: boolean;
    data: boolean;
    history: boolean;
  }>({
    workbench: true,
    creation: true,
    merchant: true,
    data: true,
    history: true,
  });

  const toggleNavSection = (section: keyof typeof navSectionsOpen) => {
    setNavSectionsOpen((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const [isHistoryPanelOpen, setIsHistoryPanelOpen] = useState<boolean>(true);
  const [historyFilterTab, setHistoryFilterTab] = useState<'all' | 'prompt' | 'action' | 'project'>('all');
  const [historyRecords, setHistoryRecords] = useState<UserHistoryRecord[]>([
    {
      id: 'hist_01',
      type: 'prompt',
      title: '生成星澜去屑洗发水前3秒痛点脚本',
      subtitle: '超能 Agent · 自动挂载黄金3秒Skill',
      timeText: '刚刚',
      targetNav: 'workbench',
      payloadPrompt: '帮我写一条星澜氨基酸去屑控油洗发水的前3秒痛点短视频脚本，并直接合成混剪预览',
    },
    {
      id: 'hist_02',
      type: 'project',
      title: '拯救头屑大作战：星澜洗发水成片',
      subtitle: '4镜分镜表 · 9:16竖屏混剪工程',
      timeText: '5分钟前',
      targetNav: 'editor',
    },
    {
      id: 'hist_03',
      type: 'action',
      title: '傻瓜式套用「前3秒痛点反差带货模板」',
      subtitle: 'AI 视频混剪成片中心',
      timeText: '12分钟前',
      targetNav: 'video_remix',
    },
    {
      id: 'hist_04',
      type: 'action',
      title: '生成 01-04 全套电商商拍与种草海报',
      subtitle: '电商套图 Pro · 流光轻奢质感',
      timeText: '25分钟前',
      targetNav: 'graphic_suite',
    },
  ]);
  const [showQuickGenDrawer, setShowQuickGenDrawer] = useState(false);
  const [studioModalTemplate, setStudioModalTemplate] = useState<CuratedTemplate | null>(null);
  const [kuaiziToolModalId, setKuaiziToolModalId] = useState<KuaiziToolId | null>(null);
  const [isRagCopilotOpen, setIsRagCopilotOpen] = useState<boolean>(false);
  const [selectedShotIndices, setSelectedShotIndices] = useState<number[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [domesticUser, setDomesticUser] = useState<DomesticUserSession | null>(null);
  const [isDomesticLoginOpen, setIsDomesticLoginOpen] = useState(false);
  const [isGatewayModalOpen, setIsGatewayModalOpen] = useState(false);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [isPersonalAgentModalOpen, setIsPersonalAgentModalOpen] = useState(false);
  const [gatewayConfig, setGatewayConfig] =
    useState<AIModelGatewayConfig>(DEFAULT_GATEWAY_CONFIG);
  const [quickHeroPrompt, setQuickHeroPrompt] = useState('');
  const [authReady, setAuthReady] = useState(false);
  const [authBusy, setAuthBusy] = useState(false);

  // Commercial SaaS Credits & Subscription Tier State
  const [planTier, setPlanTier] = useState<'free' | 'pro' | 'enterprise'>('free');
  const [credits, setCredits] = useState<number>(100);
  const [voucherCode, setVoucherCode] = useState<string>('');
  const [generatedCustomCodes, setGeneratedCustomCodes] = useState<
    { code: string; tier: 'pro' | 'enterprise'; credits: number }[]
  >([]);

  // Cloud Firestore Data + Domestic Phone/Email Account Local Sync Data
  const [cloudProjects, setCloudProjects] = useState<CloudVideoProject[]>([]);
  const [localProjects, setLocalProjects] = useState<CloudVideoProject[]>([
    {
      id: 'local_proj_01',
      ownerId: 'cn_default_creator',
      title: '拯救头屑大作战：星澜洗发水同城爆款成片',
      productName: '星澜氨基酸去屑控油洗发水',
      sellingPoints: '深层净澈头皮、72小时长效控油蓬松、温和去屑不紧绷',
      targetAudience: '熬夜油头、有头屑困扰的年轻上班族与学生党',
      category: '个护',
      aspectRatio: '9:16',
      bgmStyle: '轻快种草卡点律动',
      voiceTone: '活力种草女声',
      pacingTip: '前3秒镜前抓头发痛点切入，第2镜微距泡沫特写，结尾引导左下角团购转化。',
      cameraAngles: CURATED_TEMPLATES[2].cameraAngles,
      visualCues: CURATED_TEMPLATES[2].visualCues,
      sceneLines: CURATED_TEMPLATES[2].sceneLines,
    },
  ]);
  const [cloudTemplates, setCloudTemplates] = useState<CloudViralTemplate[]>([]);
  const [localTemplates, setLocalTemplates] = useState<CloudViralTemplate[]>([
    {
      id: 'local_tpl_01',
      ownerId: 'cn_default_creator',
      title: '拯救头屑大作战（拉片拆解复用模板）',
      category: '个护',
      hookFormula: '前3秒镜前抓头皮屑+穿黑衣尴尬视觉痛点提问，锁定油头人群停留',
      structureSummary: '视觉痛点暴击(3s) + 产品高颜微距(4s) + 使用前后爽感反差(5s) + 门店团购福利逼单(3s)',
      pacingStyle: 'AI拆解高完播节奏',
      bgmStyle: '轻快种草卡点律动',
      cameraAngles: CURATED_TEMPLATES[2].cameraAngles,
      visualCues: CURATED_TEMPLATES[2].visualCues,
      sceneLines: CURATED_TEMPLATES[2].sceneLines,
    },
  ]);
  const [cloudDissections, setCloudDissections] = useState<CloudDissection[]>([]);
  const [cloudStores, setCloudStores] = useState<CloudStoreProfile[]>([]);
  const [localStores, setLocalStores] = useState<StoreMemoryProfile[]>([]);

  // Merged Projects & Templates for Domestic Phone/Email or Cloud Users
  const allUserProjects = useMemo(
    () => [...cloudProjects, ...localProjects],
    [cloudProjects, localProjects]
  );
  const allUserTemplates = useMemo(
    () => [...cloudTemplates, ...localTemplates],
    [cloudTemplates, localTemplates]
  );

  // Douyin Laike Store / Brand Persona Long-Term Memory Knowledge Base State
  const [activeStoreId, setActiveStoreId] = useState<string>(PRESET_STORE_PROFILES[0].id);
  const [storeMemoryEnabled, setStoreMemoryEnabled] = useState<boolean>(true);
  const [editingStoreId, setEditingStoreId] = useState<string | null>(null);
  const [storeNameInput, setStoreNameInput] = useState<string>(
    PRESET_STORE_PROFILES[0].storeName
  );
  const [storeTypeInput, setStoreTypeInput] = useState<string>(
    PRESET_STORE_PROFILES[0].storeType
  );
  const [storeIndustryInput, setStoreIndustryInput] = useState<string>(
    PRESET_STORE_PROFILES[0].industry
  );
  const [storeCityInput, setStoreCityInput] = useState<string>(
    PRESET_STORE_PROFILES[0].cityLocation
  );
  const [storeProductsInput, setStoreProductsInput] = useState<string>(
    PRESET_STORE_PROFILES[0].signatureProducts
  );
  const [storePersonaInput, setStorePersonaInput] = useState<string>(
    PRESET_STORE_PROFILES[0].storePersona
  );
  const [storeAudienceInput, setStoreAudienceInput] = useState<string>(
    PRESET_STORE_PROFILES[0].targetAudience
  );
  const [storeAnchorsInput, setStoreAnchorsInput] = useState<string>(
    PRESET_STORE_PROFILES[0].memoryAnchors
  );
  const [isSavingStore, setIsSavingStore] = useState<boolean>(false);

  // Combine preset stores + user's local & cloud stores
  const allStoreProfiles: StoreMemoryProfile[] = useMemo(() => {
    return [...cloudStores, ...localStores, ...PRESET_STORE_PROFILES];
  }, [cloudStores, localStores]);

  const activeStoreProfile: StoreMemoryProfile = useMemo(() => {
    return (
      allStoreProfiles.find((s) => s.id === activeStoreId) ||
      ({
        id: 'custom_draft',
        storeName: storeNameInput,
        storeType: storeTypeInput,
        industry: storeIndustryInput,
        cityLocation: storeCityInput,
        signatureProducts: storeProductsInput,
        storePersona: storePersonaInput,
        targetAudience: storeAudienceInput,
        memoryAnchors: storeAnchorsInput,
      } as StoreMemoryProfile)
    );
  }, [
    activeStoreId,
    allStoreProfiles,
    storeAnchorsInput,
    storeAudienceInput,
    storeCityInput,
    storeIndustryInput,
    storeNameInput,
    storePersonaInput,
    storeProductsInput,
    storeTypeInput,
  ]);

  // Template Library Filters + Custom Encapsulated Templates
  const [customEncapsulatedTemplates, setCustomEncapsulatedTemplates] = useState<
    CuratedTemplate[]
  >([]);
  const allCuratedTemplates = useMemo(
    () => [...customEncapsulatedTemplates, ...CURATED_TEMPLATES],
    [customEncapsulatedTemplates]
  );
  const [selectedTemplateTab, setSelectedTemplateTab] = useState<string>('全部模板');
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [selectedContentType, setSelectedContentType] = useState<string>('全部类型');
  const [searchKeyword, setSearchKeyword] = useState<string>('');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(['kuaizi_shampoo_01', 'huotu_pet_02']);

  // Script Detail & Smart Editor State
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [projectTitle, setProjectTitle] = useState<string>('拯救头屑大作战：星澜洗发水来了');
  const [productName, setProductName] = useState<string>('星澜氨基酸去屑控油洗发水');
  const [sellingPoints, setSellingPoints] = useState<string>(
    '深层净澈头皮、72小时长效控油蓬松、温和去屑不紧绷'
  );
  const [targetAudience, setTargetAudience] = useState<string>(
    '熬夜油头、有头屑困扰的年轻上班族与学生党'
  );
  const [projectCategory, setProjectCategory] = useState<string>('个护');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9' | '4:3'>('9:16');
  const [bgmStyle, setBgmStyle] = useState<string>('轻快种草卡点律动');
  const [voiceTone, setVoiceTone] = useState<string>('活力种草女声');
  const [pacingTip, setPacingTip] = useState<string>(
    '前1.5秒使用镜前抓头发痛点特写切入，第2镜头切换产品清爽近景，第3镜头甩头动作卡音乐重音，提升完播率与点击转化。'
  );
  const [recommendedTitles, setRecommendedTitles] = useState<string[]>([
    '头屑油头必看！洗完3天依然高颅顶的宝藏洗发水',
    '杭州武林商圈店长实测：为什么你洗头越洗越油？',
    '穿黑衣服再也不怕尴尬！68元深层头皮去屑SPA同款配方',
  ]);
  const [cameraAngles, setCameraAngles] = useState<string[]>(
    CURATED_TEMPLATES[2].cameraAngles
  );
  const [visualCues, setVisualCues] = useState<string[]>(CURATED_TEMPLATES[2].visualCues);
  const [sceneLines, setSceneLines] = useState<string[]>(CURATED_TEMPLATES[2].sceneLines);
  // Per-shot fine-grained editing metadata (durations & camera movement) + Resizable Columns/Rows
  const [shotDurations, setShotDurations] = useState<number[]>([3.5, 4.0, 4.0, 3.5]);
  const [shotMovements, setShotMovements] = useState<string[]>([
    '特写推镜',
    '产品近景',
    '前后对比',
    '固定促单',
  ]);
  const [editorColWidths, setEditorColWidths] = useState<[number, number, number, number]>([
    280, 360, 380, 185,
  ]);
  const [editorRowHeights, setEditorRowHeights] = useState<Record<number, number>>({});
  const [resizingColIdx, setResizingColIdx] = useState<number | null>(null);
  const [resizingRowIdx, setResizingRowIdx] = useState<number | null>(null);
  const [dragArmedRowIdx, setDragArmedRowIdx] = useState<number | null>(null);
  const [draggedShotIdx, setDraggedShotIdx] = useState<number | null>(null);
  const [dragOverShotIdx, setDragOverShotIdx] = useState<number | null>(null);
  const [scriptViewMode, setScriptViewMode] = useState<'table' | 'pro9' | 'text'>('table');

  // Shared Link Banner State
  const [sharedViewBanner, setSharedViewBanner] = useState<string | null>(null);

  // AI Loading & Feedback States
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [assistBusyType, setAssistBusyType] = useState<string | null>(null);
  const [isSavingCloud, setIsSavingCloud] = useState(false);
  const [bannerNotice, setBannerNotice] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Modals: Video Mix Player, Share & Platform Jump Modal, Multi-Asset Export Modal
  const [isMixPlayerOpen, setIsMixPlayerOpen] = useState(false);
  const [shareModalProject, setShareModalProject] = useState<ProjectExportData | null>(null);
  const [exportModalProject, setExportModalProject] = useState<ProjectExportData | null>(null);

  // One-Click Viral Dissection State + SkillHub/GitHub Workflow Skills
  const [dissectTitle, setDissectTitle] = useState<string>(QUICK_DISSECT_SAMPLES[0].title);
  const [dissectCategory, setDissectCategory] = useState<string>(
    QUICK_DISSECT_SAMPLES[0].category
  );
  const [dissectContent, setDissectContent] = useState<string>(
    QUICK_DISSECT_SAMPLES[0].content
  );
  const [selectedSkillIds, setSelectedSkillIds] = useState<string[]>([
    'skill_douyin_golden3s',
    'skill_laike_poi_funnel',
    'skill_kuaizi_matrix',
  ]);
  const [isDissecting, setIsDissecting] = useState(false);
  const [dissectResult, setDissectResult] = useState<{
    sourceTitle: string;
    sourceContent: string;
    hookAnalysis: string;
    retentionSecret: string;
    conversionTrigger: string;
    extractedFormula: string;
    skillWorkflowOutput?: string;
    sceneBreakdown: string[];
    cameraAngles: string[];
    visualCues: string[];
    sceneLines: string[];
  }>({
    sourceTitle: QUICK_DISSECT_SAMPLES[0].title,
    sourceContent: QUICK_DISSECT_SAMPLES[0].content,
    hookAnalysis:
      '前3秒采用“镜前抓头皮屑+穿黑衣尴尬”高共鸣视觉痛点提问，瞬间锁定油头与头屑人群停留。',
    retentionSecret:
      '第4-10秒迅速给出解决方案并展示绵密泡沫微距特写，第11-14秒用洗后甩头蓬松反差制造爽感。',
    conversionTrigger:
      '结尾强调“洗完三天依然蓬松”具体可感知利益点，配合左下角抖音来客团购/小黄车限时买赠降低决策门槛。',
    extractedFormula:
      '视觉痛点暴击(3s) + 产品高颜微距(4s) + 使用前后爽感反差(5s) + 门店团购福利逼单(3s)',
    skillWorkflowOutput:
      '【GitHub: Viral-Hook-3S-Analyzer & 抖音来客技能包输出】\n① 钩子A（痛点反问）：刚洗完头不到半天又扁塌泛油？別急着换洗发水！\n② 钩子B（同城背书）：杭州油头姐妹注意！武林商圈这家头皮SPA把同款配方做成了洗发水！\n③ 钩子C（视觉测试）：黑衣服肩膀全是雪花屑？教你一招72小时控油高颅顶！',
    sceneBreakdown: [
      '01 开场引入痛点｜画面：一个人在镜子前抓着头发，显得很苦恼，镜头拉近显示头屑问题。｜口播：头屑问题让你头疼不已？快来看看这个办法！',
      '02 产品介绍｜画面：展示星澜洗发水的产品近景，包装简洁清爽。｜口播：我最近入手了一个神奇的洗发水——星澜洗发水！',
      '03 产品卖点｜画面：洗头后轻松甩头，表现出自信与满意的面部表情。｜口播：这个洗发水真的太好用了，去屑效果超赞，用过后头发清爽舒适！',
      '04 强力促单转化｜画面：手持洗发水微笑展示活动字卡。｜口播：油头扁塌的朋友闭眼冲，赶紧点击左下角链接试试吧！',
    ],
    cameraAngles: CURATED_TEMPLATES[2].cameraAngles,
    visualCues: CURATED_TEMPLATES[2].visualCues,
    sceneLines: CURATED_TEMPLATES[2].sceneLines,
  });

  const showNotice = (type: 'success' | 'error', text: string) => {
    setBannerNotice({ type, text });
    setTimeout(() => {
      setBannerNotice((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  };

  const recordHistoryEntry = (
    type: UserHistoryRecord['type'],
    title: string,
    subtitle: string,
    targetNav: NavTab,
    payloadPrompt?: string
  ) => {
    setHistoryRecords((prev) => [
      {
        id: `hist_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        type,
        title: title.slice(0, 32),
        subtitle: subtitle.slice(0, 36),
        timeText: '刚刚',
        targetNav,
        payloadPrompt,
      },
      ...prev.slice(0, 19),
    ]);
  };

  // Select a store profile into the Store Memory Knowledge Base form
  const handleSelectStoreProfile = (profile: StoreMemoryProfile) => {
    setActiveStoreId(profile.id);
    setEditingStoreId(profile.id.startsWith('store_') ? null : profile.id);
    setStoreNameInput(profile.storeName);
    setStoreTypeInput(profile.storeType);
    setStoreIndustryInput(profile.industry);
    setStoreCityInput(profile.cityLocation);
    setStoreProductsInput(profile.signatureProducts);
    setStorePersonaInput(profile.storePersona);
    setStoreAudienceInput(profile.targetAudience);
    setStoreAnchorsInput(profile.memoryAnchors);
  };

  // Current active project export payload helper
  const currentEditorExportData: ProjectExportData = useMemo(
    () => ({
      id: currentProjectId,
      title: projectTitle,
      productName,
      sellingPoints,
      targetAudience,
      category: projectCategory,
      aspectRatio,
      bgmStyle,
      voiceTone,
      pacingTip,
      cameraAngles,
      visualCues,
      sceneLines,
    }),
    [
      aspectRatio,
      bgmStyle,
      cameraAngles,
      currentProjectId,
      pacingTip,
      productName,
      projectCategory,
      projectTitle,
      sceneLines,
      sellingPoints,
      targetAudience,
      visualCues,
      voiceTone,
    ]
  );

  // Check URL query parameters on boot for temporary public share links (?share=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shareToken = params.get('share');
    if (shareToken) {
      try {
        const decodedJson = decodeURIComponent(escape(atob(shareToken)));
        const payload = JSON.parse(decodedJson);
        if (payload.expiresAtMs && Date.now() > payload.expiresAtMs) {
          showNotice('error', '该临时公共共享链接已过期。');
          return;
        }
        if (payload.title) setProjectTitle(payload.title);
        if (payload.productName) setProductName(payload.productName);
        if (payload.sellingPoints) setSellingPoints(payload.sellingPoints);
        if (payload.category) setProjectCategory(payload.category);
        if (payload.aspectRatio) setAspectRatio(payload.aspectRatio);
        if (payload.pacingTip) setPacingTip(payload.pacingTip);
        if (Array.isArray(payload.cameraAngles)) setCameraAngles(payload.cameraAngles);
        if (Array.isArray(payload.visualCues)) setVisualCues(payload.visualCues);
        if (Array.isArray(payload.sceneLines)) setSceneLines(payload.sceneLines);

        const expDateStr = payload.expiresAtMs
          ? new Date(payload.expiresAtMs).toLocaleString('zh-CN')
          : '有效期内';
        setSharedViewBanner(
          `您正在查看客户/协作者共享的爆款项目「${payload.title || ''}」（临时链接有效至：${expDateStr}）`
        );
        setActiveNav('editor');
      } catch {
        // Ignore malformed share token
      }
    }
  }, []);

  // Create Temporary Public Share Link
  const handleCreateTemporaryShareLink = async (
    targetProj: ProjectExportData,
    expireHours: number
  ): Promise<string> => {
    const expiresAtMs = Date.now() + expireHours * 3600 * 1000;
    let shareDocId = '';

    if (user) {
      try {
        const docRef = await addDoc(
          collection(db, 'shared_links'),
          buildSharedProjectLinkCreatePayload({
            ownerId: user.uid,
            title: targetProj.title,
            productName: targetProj.productName,
            category: targetProj.category,
            aspectRatio: targetProj.aspectRatio,
            pacingTip: targetProj.pacingTip,
            sceneLines: targetProj.sceneLines,
            visualCues: targetProj.visualCues,
            cameraAngles: targetProj.cameraAngles,
            expiresAtMs,
          })
        );
        shareDocId = docRef.id;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, 'shared_links');
      }
    }

    const tokenObj = {
      shareId: shareDocId || undefined,
      title: targetProj.title,
      productName: targetProj.productName,
      sellingPoints: targetProj.sellingPoints,
      category: targetProj.category,
      aspectRatio: targetProj.aspectRatio,
      pacingTip: targetProj.pacingTip,
      cameraAngles: targetProj.cameraAngles,
      visualCues: targetProj.visualCues,
      sceneLines: targetProj.sceneLines,
      expiresAtMs,
    };

    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(tokenObj))));
    const baseUrl = window.location.origin + window.location.pathname;
    return `${baseUrl}?share=${encoded}`;
  };

  // Helper to consume AI compute credits & persist in Firestore if logged in
  const consumeCredits = async (cost: number): Promise<boolean> => {
    if (credits < cost) {
      showNotice(
        'error',
        `当前剩余算力（${credits}点）不足本次消耗（${cost}点），请前往「会员与算力中心」一键充值或兑换激活码。`
      );
      setActiveNav('pricing');
      return false;
    }

    const nextCredits = Math.max(0, credits - cost);
    setCredits(nextCredits);

    if (user) {
      try {
        await updateDoc(
          doc(db, 'users', user.uid),
          buildUserProfileBillingUpdatePayload({
            planTier,
            credits: nextCredits,
          })
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    }
    return true;
  };

  // 1. Firebase Auth Listener & Automatic UserProfile Bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);

      if (currentUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        try {
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            await setDoc(
              userRef,
              buildUserProfileCreatePayload({
                uid: currentUser.uid,
                displayName: currentUser.displayName || 'AI创作者',
                brandName: '我的爆款视频工坊',
                industry: '个护',
              })
            );
            setPlanTier('free');
            setCredits(100);
          } else {
            const data = snap.data();
            if (data?.planTier === 'pro' || data?.planTier === 'enterprise') {
              setPlanTier(data.planTier);
            } else {
              setPlanTier('free');
            }
            if (typeof data?.credits === 'number') {
              setCredits(data.credits);
            }
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `users/${currentUser.uid}`);
        }
      } else {
        setPlanTier('free');
        setCredits(100);
      }
    });
    return () => unsub();
  }, []);

  // 2. Real-time Firestore Listeners for User's Cloud Projects, Templates, Dissections, and Store Profiles
  useEffect(() => {
    if (!authReady || !user) {
      setCloudProjects([]);
      setCloudTemplates([]);
      setCloudDissections([]);
      setCloudStores([]);
      return;
    }

    const qProjects = query(collection(db, 'projects'), where('ownerId', '==', user.uid));
    const unsubProjects = onSnapshot(
      qProjects,
      (snap) => {
        const items: CloudVideoProject[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CloudVideoProject, 'id'>),
        }));
        setCloudProjects(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'projects')
    );

    const qTemplates = query(collection(db, 'templates'), where('ownerId', '==', user.uid));
    const unsubTemplates = onSnapshot(
      qTemplates,
      (snap) => {
        const items: CloudViralTemplate[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CloudViralTemplate, 'id'>),
        }));
        setCloudTemplates(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'templates')
    );

    const qDissections = query(
      collection(db, 'dissections'),
      where('ownerId', '==', user.uid)
    );
    const unsubDissections = onSnapshot(
      qDissections,
      (snap) => {
        const items: CloudDissection[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CloudDissection, 'id'>),
        }));
        setCloudDissections(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'dissections')
    );

    const qStores = query(
      collection(db, 'store_profiles'),
      where('ownerId', '==', user.uid)
    );
    const unsubStores = onSnapshot(
      qStores,
      (snap) => {
        const items: CloudStoreProfile[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CloudStoreProfile, 'id'>),
        }));
        setCloudStores(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'store_profiles')
    );

    return () => {
      unsubProjects();
      unsubTemplates();
      unsubDissections();
      unsubStores();
    };
  }, [authReady, user]);

  // Auth Actions: Default to Domestic Phone / Email Modal (No Google requirement in China Mainland)
  const handleGoogleLogin = async () => {
    setIsDomesticLoginOpen(true);
  };

  const handleLogout = async () => {
    if (user) {
      await signOut(auth);
    }
    setDomesticUser(null);
    showNotice('success', '已安全退出登录。');
  };

  // Save Store Persona Memory Profile to Cloud Firestore
  const handleSaveStoreProfileToCloud = async () => {
    if (!user) {
      showNotice(
        'success',
        '当前门店画像记忆已实时生效！如需永久跨设备保存，请点击右上角「一键登录/注册」。'
      );
      return;
    }

    setIsSavingStore(true);
    try {
      if (editingStoreId) {
        await updateDoc(
          doc(db, 'store_profiles', editingStoreId),
          buildStoreProfileUpdatePayload({
            storeName: storeNameInput,
            storeType: storeTypeInput,
            industry: storeIndustryInput,
            cityLocation: storeCityInput,
            signatureProducts: storeProductsInput,
            storePersona: storePersonaInput,
            targetAudience: storeAudienceInput,
            memoryAnchors: storeAnchorsInput,
          })
        );
        showNotice('success', `门店「${storeNameInput}」长期记忆画像已更新同步至云端！`);
      } else {
        const created = await addDoc(
          collection(db, 'store_profiles'),
          buildStoreProfileCreatePayload({
            ownerId: user.uid,
            storeName: storeNameInput,
            storeType: storeTypeInput,
            industry: storeIndustryInput,
            cityLocation: storeCityInput,
            signatureProducts: storeProductsInput,
            storePersona: storePersonaInput,
            targetAudience: storeAudienceInput,
            memoryAnchors: storeAnchorsInput,
          })
        );
        setEditingStoreId(created.id);
        setActiveStoreId(created.id);
        showNotice('success', `已将「${storeNameInput}」存入您的云端门店长期记忆库！`);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'store_profiles');
    } finally {
      setIsSavingStore(false);
    }
  };

  // Filtered Templates for Template Library (Includes user-encapsulated templates)
  const filteredTemplates = useMemo(() => {
    return allCuratedTemplates.filter((tpl) => {
      if (selectedTemplateTab !== '全部模板' && tpl.templateTab !== selectedTemplateTab) {
        return false;
      }
      if (selectedCategory === '我的收藏' && !favoriteIds.includes(tpl.id)) {
        return false;
      }
      if (
        selectedCategory !== '全部' &&
        selectedCategory !== '我的收藏' &&
        tpl.category !== selectedCategory
      ) {
        return false;
      }
      if (selectedContentType !== '全部类型' && tpl.contentType !== selectedContentType) {
        return false;
      }
      if (searchKeyword.trim()) {
        const kw = searchKeyword.trim().toLowerCase();
        const match =
          tpl.title.toLowerCase().includes(kw) ||
          tpl.posterHeadline.toLowerCase().includes(kw) ||
          tpl.category.toLowerCase().includes(kw) ||
          tpl.defaultProductName.toLowerCase().includes(kw);
        if (!match) return false;
      }
      return true;
    });
  }, [
    allCuratedTemplates,
    favoriteIds,
    searchKeyword,
    selectedCategory,
    selectedContentType,
    selectedTemplateTab,
  ]);

  // Foolproof 1-Click Action: Apply Template ("一键做同款" or "按本店画像套用")
  const handleApplyTemplate = (
    tpl: CuratedTemplate,
    openMixImmediately = false,
    injectStoreMemory = false
  ) => {
    setCurrentProjectId(null);

    if (injectStoreMemory && storeMemoryEnabled) {
      setProjectTitle(`${activeStoreProfile.storeName} · ${tpl.posterHeadline}`);
      setProductName(activeStoreProfile.signatureProducts.slice(0, 48));
      setSellingPoints(activeStoreProfile.memoryAnchors);
      setTargetAudience(activeStoreProfile.targetAudience);
      setProjectCategory(activeStoreProfile.industry);
      setBgmStyle(tpl.bgmStyle);
      setPacingTip(
        `【已注入门店长期记忆：${activeStoreProfile.storeName}】人设：${activeStoreProfile.storePersona}｜${tpl.hookFormula}`
      );
      setCameraAngles([...tpl.cameraAngles]);
      setVisualCues(
        tpl.visualCues.map((cue, idx) =>
          idx === 1
            ? `展示【${activeStoreProfile.storeName}】（${activeStoreProfile.cityLocation}）实景与招牌爆品：${activeStoreProfile.signatureProducts}`
            : cue
        )
      );
      setSceneLines(
        tpl.sceneLines.map((line, idx) =>
          idx === tpl.sceneLines.length - 1
            ? `同城和线上的朋友注意！我们【${activeStoreProfile.storeName}】现在推出专属福利：${activeStoreProfile.memoryAnchors}，赶紧点击左下角抢购吧！`
            : line
        )
      );
    } else {
      setProjectTitle(tpl.title.replace('模板', ''));
      setProductName(tpl.defaultProductName);
      setSellingPoints(tpl.defaultSellingPoints);
      setTargetAudience(tpl.defaultAudience);
      setProjectCategory(tpl.category);
      setBgmStyle(tpl.bgmStyle);
      setPacingTip(`【${tpl.pacingStyle}】${tpl.hookFormula}`);
      setCameraAngles([...tpl.cameraAngles]);
      setVisualCues([...tpl.visualCues]);
      setSceneLines([...tpl.sceneLines]);
    }

    setShotDurations(tpl.cameraAngles.map(() => 4.0));
    setShotMovements(['特写推镜', '产品近景', '前后对比', '固定促单']);
    setActiveNav('editor');

    if (openMixImmediately) {
      setIsMixPlayerOpen(true);
    } else {
      showNotice(
        'success',
        injectStoreMemory
          ? `已结合「${activeStoreProfile.storeName}」门店画像记忆，一键定制「${tpl.posterHeadline}」专属脚本！`
          : `已一键载入「${tpl.posterHeadline}」同款脚本，可在下方表格对任意镜头与台词进行精修！`
      );
    }
  };

  // Foolproof 1-Click Action: Dissect Template
  const handleDissectFromTemplate = (tpl: CuratedTemplate) => {
    const combinedScript = tpl.cameraAngles
      .map((angle, i) => `${angle}｜画面：${tpl.visualCues[i]}｜台词：“${tpl.sceneLines[i]}”`)
      .join('\n');
    setDissectTitle(tpl.title);
    setDissectCategory(tpl.category);
    setDissectContent(combinedScript);
    setActiveNav('dissect');
    handleRunDissection(tpl.title, combinedScript, tpl.category);
  };

  // AI Action 1: One-Click Generate Viral Script & Storyboard (-10 Credits)
  const handleAIGenerateScript = async (
    customTemplateHook?: string,
    customStructure?: string,
    overrideProduct?: string,
    overridePoints?: string,
    overrideAudience?: string,
    overrideCat?: string
  ) => {
    const targetProd = overrideProduct ?? productName;
    const targetPts = overridePoints ?? sellingPoints;
    const targetAud = overrideAudience ?? targetAudience;
    const targetCat = overrideCat ?? projectCategory;

    if (!targetProd.trim() || !targetPts.trim()) {
      showNotice('error', '请先填写商品名称和核心卖点（或点击上方快捷示例一键填入）。');
      return;
    }

    const ok = await consumeCredits(10);
    if (!ok) return;

    setIsGeneratingScript(true);
    try {
      let data: {
        title: string;
        pacingTip: string;
        bgmStyle: string;
        voiceTone: string;
        recommendedTitles?: string[];
        cameraAngles: string[];
        visualCues: string[];
        sceneLines: string[];
      } | null = null;

      try {
        const res = await fetch('/api/ai/generate-project', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(auth.currentUser ? { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` } : {}) },
          body: JSON.stringify({
            productName: targetProd,
            sellingPoints: targetPts,
            targetAudience: targetAud,
            category: targetCat,
            templateHook: customTemplateHook,
            templateStructure: customStructure,
            storeMemory: storeMemoryEnabled ? activeStoreProfile : null,
            gatewayConfig,
          }),
        });
        if (res.ok) {
          data = await res.json();
        }
      } catch {
        // Fallback to edge client synthesis when running on static Cloudflare Pages CDN
      }

      if (!data) throw new Error('AI 服务未返回有效结果，请检查部署端密钥、网络和配额；未生成替代内容。');

      setProjectTitle(data.title);
      setPacingTip(data.pacingTip);
      setBgmStyle(data.bgmStyle);
      setVoiceTone(data.voiceTone);
      if (Array.isArray(data.recommendedTitles) && data.recommendedTitles.length > 0) {
        setRecommendedTitles(data.recommendedTitles);
      }
      setCameraAngles(data.cameraAngles);
      setVisualCues(data.visualCues);
      setSceneLines(data.sceneLines);
      setShotDurations(data.cameraAngles.map(() => 4.0));
      setShotMovements(
        data.cameraAngles.map((_: string, i: number) =>
          i === 0 ? '特写推镜' : i === 1 ? '产品近景' : i === 2 ? '前后对比' : '固定促单'
        )
      );
      showNotice(
        'success',
        storeMemoryEnabled
          ? `AI 已基于「${activeStoreProfile.storeName}」长期记忆生成定制分镜脚本与小红书标题（消耗 10 算力点）！`
          : 'AI 已一键生成全套分镜脚本与混剪参数（消耗 10 算力点）！'
      );
    } catch (err) {
      showNotice('error', err instanceof Error ? err.message : 'AI 生成请求异常');
    } finally {
      setIsGeneratingScript(false);
    }
  };

  // AI Action 2: Smart Editing Assist & Per-Shot / Per-Line Precision Polish (-5 Credits)
  const handleAISmartAssist = async (
    actionType:
      | 'hook_boost'
      | 'punchy_copy'
      | 'visual_upgrade'
      | 'single_shot_rewrite'
      | 'line_pain_boost'
      | 'line_colloquial'
      | 'line_laike_cta'
      | 'shot_visual_ai_paint',
    targetShotIndex?: number
  ) => {
    const ok = await consumeCredits(5);
    if (!ok) return;

    const busyKey =
      targetShotIndex !== undefined ? `${actionType}_${targetShotIndex}` : actionType;
    setAssistBusyType(busyKey);

    try {
      let data: {
        pacingTip: string;
        cameraAngles: string[];
        visualCues: string[];
        sceneLines: string[];
      } | null = null;

      try {
        const res = await fetch('/api/ai/smart-assist', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(auth.currentUser ? { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` } : {}) },
          body: JSON.stringify({
            actionType,
            productName,
            sellingPoints,
            cameraAngles,
            visualCues,
            sceneLines,
            targetShotIndex,
            storeMemory: storeMemoryEnabled ? activeStoreProfile : null,
            gatewayConfig,
          }),
        });
        if (res.ok) {
          data = await res.json();
        }
      } catch {
        // Fallback to edge client polish when running on static Cloudflare Pages CDN
      }

      if (!data) throw new Error('AI 服务未返回有效结果，请检查部署端密钥、网络和配额；未生成替代内容。');

      setPacingTip(data.pacingTip);
      setCameraAngles(data.cameraAngles);
      setVisualCues(data.visualCues);
      setSceneLines(data.sceneLines);
      showNotice('success', 'AI 精修已完成并实时同步至分镜表（消耗 5 算力点）！');
    } catch (err) {
      showNotice('error', err instanceof Error ? err.message : 'AI 辅助请求失败');
    } finally {
      setAssistBusyType(null);
    }
  };

  // Per-Shot Structural Manipulation (Drag-and-Drop Reorder / Add / Delete / Move Up / Move Down)
  const handleReorderShots = (fromIdx: number, toIdx: number) => {
    if (
      fromIdx === toIdx ||
      fromIdx < 0 ||
      toIdx < 0 ||
      fromIdx >= cameraAngles.length ||
      toIdx >= cameraAngles.length
    ) {
      return;
    }

    const reorderArray = <T,>(arr: T[], fallback: T): T[] => {
      const normalized = cameraAngles.map((_, i) => (arr[i] !== undefined ? arr[i] : fallback));
      const [moved] = normalized.splice(fromIdx, 1);
      normalized.splice(toIdx, 0, moved);
      return normalized;
    };

    const reorderedAngles = reorderArray(cameraAngles, '分镜').map((angle, newIdx) => {
      const cleanLabel = angle.replace(/^0?\d+\s*/, '');
      return `0${newIdx + 1} ${cleanLabel}`;
    });
    const reorderedVisuals = reorderArray(visualCues, '');
    const reorderedLines = reorderArray(sceneLines, '');
    const reorderedDurations = reorderArray(shotDurations, 4.0);
    const reorderedMovements = reorderArray(shotMovements, '特写推镜');

    setCameraAngles(reorderedAngles);
    setVisualCues(reorderedVisuals);
    setSceneLines(reorderedLines);
    setShotDurations(reorderedDurations);
    setShotMovements(reorderedMovements);
    showNotice(
      'success',
      `已将第 ${fromIdx + 1} 镜拖拽调整至第 ${toIdx + 1} 镜，并同步更新对应的分镜时长 (${reorderedDurations[toIdx]}s) 与运镜参数 (${reorderedMovements[toIdx]})！`
    );
  };

  const handleMoveShot = (idx: number, direction: -1 | 1) => {
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= cameraAngles.length) return;
    handleReorderShots(idx, targetIdx);
  };

  const handleInsertShotAfter = (idx: number) => {
    if (cameraAngles.length >= 8) {
      showNotice('error', '单条短视频建议控制在 8 个分镜以内，以确保节奏紧凑高完播。');
      return;
    }
    if (cameraAngles.length === 0 || idx < 0) {
      setCameraAngles(['01 开场黄金钩子']);
      setVisualCues([
        `近景特写展示${productName}的核心细节与使用实测对比画面，光线通透。`,
      ]);
      setSceneLines([
        `先别划走！真正懂行的人选${productName}都看准这几个核心细节！`,
      ]);
      setShotDurations([4.0]);
      setShotMovements(['特写推镜']);
      showNotice('success', '已添加第 1 个分镜镜头！');
      return;
    }
    const newNum = idx + 2;
    const insertAt = <T,>(arr: T[], val: T) => [
      ...arr.slice(0, idx + 1),
      val,
      ...arr.slice(idx + 1),
    ];

    setCameraAngles(insertAt(cameraAngles, `0${newNum} 新增特写分镜`));
    setVisualCues(
      insertAt(
        visualCues,
        `近景特写展示${productName}的核心细节与使用实测对比画面，光线通透。`
      )
    );
    setSceneLines(
      insertAt(
        sceneLines,
        `细节真的经得起放大看，用过一次就知道为什么回头客这么多了！`
      )
    );
    setShotDurations(insertAt(shotDurations, 3.5));
    setShotMovements(insertAt(shotMovements, '特写推镜'));
    showNotice('success', `已在第 ${idx + 1} 镜下方插入新分镜！`);
  };

  const handleDeleteShot = (idx: number) => {
    setCameraAngles(cameraAngles.filter((_, i) => i !== idx));
    setVisualCues(visualCues.filter((_, i) => i !== idx));
    setSceneLines(sceneLines.filter((_, i) => i !== idx));
    setShotDurations(shotDurations.filter((_, i) => i !== idx));
    setShotMovements(shotMovements.filter((_, i) => i !== idx));
    setSelectedShotIndices((prev) =>
      prev.filter((i) => i !== idx).map((i) => (i > idx ? i - 1 : i))
    );
  };

  // Focus Mode Enhancement: Quick Duplicate Shot Row
  const handleDuplicateShot = (idx: number) => {
    if (cameraAngles.length >= 10) {
      showNotice('error', '镜头总数建议控制在 10 镜以内，保持紧凑完播节奏。');
      return;
    }
    const insertAt = <T,>(arr: T[], val: T) => [
      ...arr.slice(0, idx + 1),
      val,
      ...arr.slice(idx + 1),
    ];
    const cleanName = (cameraAngles[idx] || '分镜').replace(/^0?\d+\s*/, '');
    const nextAngles = insertAt(cameraAngles, `${cleanName} (副本)`).map((a, i) => {
      const label = a.replace(/^0?\d+\s*/, '');
      return `0${i + 1} ${label}`;
    });
    setCameraAngles(nextAngles);
    setVisualCues(insertAt(visualCues, visualCues[idx] || ''));
    setSceneLines(insertAt(sceneLines, sceneLines[idx] || ''));
    setShotDurations(insertAt(shotDurations, shotDurations[idx] ?? 4.0));
    setShotMovements(insertAt(shotMovements, shotMovements[idx] || '特写推镜'));
    showNotice('success', `已快速复制第 ${idx + 1} 镜并插入到第 ${idx + 2} 镜！`);
  };

  // Focus Mode Enhancement: Move Shot to Top or Bottom
  const handleMoveShotToEdge = (idx: number, edge: 'top' | 'bottom') => {
    const targetIdx = edge === 'top' ? 0 : cameraAngles.length - 1;
    if (idx === targetIdx) return;
    handleReorderShots(idx, targetIdx);
  };

  // Focus Mode Enhancement: Bulk Delete Selected Shots
  const handleBulkDeleteShots = () => {
    if (selectedShotIndices.length === 0) {
      showNotice('error', '请先勾选需要批量操作的镜头行。');
      return;
    }
    const keepFilter = (_: unknown, i: number) => !selectedShotIndices.includes(i);
    const nextAngles = cameraAngles.filter(keepFilter).map((a, i) => {
      const label = a.replace(/^0?\d+\s*/, '');
      return `0${i + 1} ${label}`;
    });
    setCameraAngles(nextAngles);
    setVisualCues(visualCues.filter(keepFilter));
    setSceneLines(sceneLines.filter(keepFilter));
    setShotDurations(shotDurations.filter(keepFilter));
    setShotMovements(shotMovements.filter(keepFilter));
    const removedCount = selectedShotIndices.length;
    setSelectedShotIndices([]);
    showNotice('success', `已批量删除选中的 ${removedCount} 个分镜镜头！`);
  };

  // Focus Mode Enhancement: Clear All Shots
  const handleClearAllShots = () => {
    setCameraAngles([]);
    setVisualCues([]);
    setSceneLines([]);
    setShotDurations([]);
    setShotMovements([]);
    setSelectedShotIndices([]);
    showNotice('success', '已清空全部分镜镜头，可点击「添加第一个镜头」重新开始。');
  };

  // Focus Mode Enhancement: Bulk Export Selected or All Shots as CSV
  const handleBulkExportShotsCsv = () => {
    const targetIndices =
      selectedShotIndices.length > 0
        ? [...selectedShotIndices].sort((a, b) => a - b)
        : cameraAngles.map((_, i) => i);
    if (targetIndices.length === 0) {
      showNotice('error', '当前暂无可导出的镜头数据。');
      return;
    }
    const rows = [
      ['镜号', '镜头分组', '运镜方式', '时长(秒)', '画面描述', '台词口播'],
      ...targetIndices.map((idx, n) => [
        `0${n + 1}`,
        `"${(cameraAngles[idx] || '').replace(/"/g, '""')}"`,
        `"${(shotMovements[idx] || '特写推镜').replace(/"/g, '""')}"`,
        String(shotDurations[idx] ?? 4.0),
        `"${(visualCues[idx] || '').replace(/"/g, '""')}"`,
        `"${(sceneLines[idx] || '').replace(/"/g, '""')}"`,
      ]),
    ];
    const csv = '\uFEFF' + rows.map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectTitle || '爆款分镜脚本'}_批量导出(${targetIndices.length}镜).csv`;
    a.click();
    URL.revokeObjectURL(url);
    showNotice('success', `已批量导出 ${targetIndices.length} 个分镜镜头表格 (CSV)！`);
  };

  // Interactive Column Width & Row Height Drag Resizers for Storyboard Table (Fixed so <tr draggable> never hijacks mouse drags)
  const startResizeEditorCol = (colIndex: 0 | 1 | 2 | 3, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragArmedRowIdx(null);
    setResizingColIdx(colIndex);
    const startX = e.clientX;
    const startW = editorColWidths[colIndex];
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';

    const onMove = (moveEvent: MouseEvent) => {
      const delta = moveEvent.clientX - startX;
      setEditorColWidths((prev) => {
        const next: [number, number, number, number] = [...prev] as [
          number,
          number,
          number,
          number,
        ];
        const minW = colIndex === 0 ? 230 : colIndex === 3 ? 140 : 180;
        next[colIndex] = Math.max(minW, Math.min(780, startW + delta));
        return next;
      });
    };
    const onUp = () => {
      setResizingColIdx(null);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const startResizeEditorRow = (rowIndex: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragArmedRowIdx(null);
    setResizingRowIdx(rowIndex);
    const startY = e.clientY;
    const startH = editorRowHeights[rowIndex] ?? 142;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';

    const onMove = (moveEvent: MouseEvent) => {
      const delta = moveEvent.clientY - startY;
      setEditorRowHeights((prev) => ({
        ...prev,
        [rowIndex]: Math.max(104, Math.min(420, startH + delta)),
      }));
    };
    const onUp = () => {
      setResizingRowIdx(null);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  // Encapsulate a Dissected or Agent-Generated Structure into the Viral Template Library
  const handleEncapsulateAsTemplate = (newTpl: CuratedTemplate) => {
    setCustomEncapsulatedTemplates((prev) => [newTpl, ...prev]);
    showNotice(
      'success',
      `已将「${newTpl.title}」封装成标准模板并加入「海量爆款库」！`
    );
  };

  // AI Action 3: One-Click Viral Video Dissection with SkillHub/GitHub Skills (-5 Credits)
  const handleRunDissection = async (
    overrideTitle?: string,
    overrideContent?: string,
    overrideCategory?: string
  ) => {
    const targetTitle = overrideTitle ?? dissectTitle;
    const targetContent = overrideContent ?? dissectContent;
    const targetCat = overrideCategory ?? dissectCategory;

    if (!targetContent.trim()) {
      showNotice('error', '请输入或选择一段需要拆解的爆款视频文案。');
      return;
    }

    const ok = await consumeCredits(5);
    if (!ok) return;

    const activeSkillDirectives = DISSECT_SKILL_PACKAGES.filter((s) =>
      selectedSkillIds.includes(s.id)
    ).map((s) => s.promptDirective);

    setIsDissecting(true);
    try {
      let data: typeof dissectResult | null = null;
      try {
        const res = await fetch('/api/ai/dissect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(auth.currentUser ? { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` } : {}) },
          body: JSON.stringify({
            sourceTitle: targetTitle,
            sourceContent: targetContent,
            category: targetCat,
            skillDirectives: activeSkillDirectives,
            storeMemory: storeMemoryEnabled ? activeStoreProfile : null,
            gatewayConfig,
          }),
        });
        if (res.ok) {
          data = await res.json();
        }
      } catch {
        // Fallback to edge dissection when running on static Cloudflare Pages CDN
      }

      if (!data) throw new Error('AI 服务未返回有效结果，请检查部署端密钥、网络和配额；未生成替代内容。');

      setDissectResult(data);
      showNotice(
        'success',
        `AI 已调用 ${activeSkillDirectives.length} 个 SkillHub 技能包完成深度拆解（消耗 5 算力点）！`
      );
    } catch (err) {
      showNotice('error', err instanceof Error ? err.message : 'AI 拆解请求异常');
    } finally {
      setIsDissecting(false);
    }
  };

  // Commercial SaaS Voucher Redemption & Instant Upgrade
  const handleRedeemVoucher = async (codeToRedeem?: string) => {
    const cleanCode = (codeToRedeem ?? voucherCode).trim().toUpperCase();
    if (!cleanCode) {
      showNotice('error', '请输入卡密/激活码，或直接点击下方体验激活码一键填入。');
      return;
    }

    const matchedBuiltin = BUILTIN_VOUCHERS[cleanCode];
    const matchedCustom = generatedCustomCodes.find((c) => c.code === cleanCode);

    if (!matchedBuiltin && !matchedCustom) {
      showNotice('error', '无效的激活码，请核对后重试（可使用测试码 VIP-PRO-2026）。');
      return;
    }

    const nextTier = matchedCustom
      ? matchedCustom.tier
      : matchedBuiltin.tier === 'free'
      ? planTier
      : matchedBuiltin.tier;
    const addAmount = matchedCustom ? matchedCustom.credits : matchedBuiltin.addCredits;
    const nextCredits = Math.min(1000000, credits + addAmount);

    setPlanTier(nextTier);
    setCredits(nextCredits);
    setVoucherCode('');

    if (user) {
      try {
        await updateDoc(
          doc(db, 'users', user.uid),
          buildUserProfileBillingUpdatePayload({
            planTier: nextTier,
            credits: nextCredits,
          })
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    }

    showNotice(
      'success',
      `激活成功！已为您增加 ${addAmount} 算力点，当前可用余额：${nextCredits} 点。`
    );
  };

  // Save Project (Supports Domestic Phone/Email Account & Cloud Firestore, No Google Required)
  const handleSaveProjectToCloud = async () => {
    if (!user && !domesticUser) {
      setIsDomesticLoginOpen(true);
      showNotice('error', '请先使用手机号或邮箱登录以保存作品。');
      return;
    }

    setIsSavingCloud(true);
    try {
      if (!user) {
        // Domestic Phone/Email Account Save
        const newId = currentProjectId || `local_proj_${Date.now()}`;
        const savedItem: CloudVideoProject = {
          id: newId,
          ownerId: domesticUser?.uid || 'cn_default_creator',
          title: projectTitle,
          productName,
          sellingPoints,
          targetAudience,
          category: projectCategory,
          aspectRatio,
          bgmStyle,
          voiceTone,
          pacingTip,
          sceneLines: [...sceneLines],
          visualCues: [...visualCues],
          cameraAngles: [...cameraAngles],
        };
        setLocalProjects((prev) => {
          const exists = prev.some((p) => p.id === newId);
          return exists ? prev.map((p) => (p.id === newId ? savedItem : p)) : [savedItem, ...prev];
        });
        setCurrentProjectId(newId);
        showNotice('success', '作品已成功保存至「我的作品」库！');
        return;
      }

      if (currentProjectId && !currentProjectId.startsWith('local_')) {
        const ref = doc(db, 'projects', currentProjectId);
        await updateDoc(
          ref,
          buildVideoProjectUpdatePayload({
            title: projectTitle,
            productName,
            sellingPoints,
            targetAudience,
            category: projectCategory,
            aspectRatio,
            bgmStyle,
            voiceTone,
            pacingTip,
            sceneLines,
            visualCues,
            cameraAngles,
          })
        );
        showNotice('success', '作品修改已同步更新至云端作品库！');
      } else {
        const created = await addDoc(
          collection(db, 'projects'),
          buildVideoProjectCreatePayload({
            ownerId: user.uid,
            title: projectTitle,
            productName,
            sellingPoints,
            targetAudience,
            category: projectCategory,
            aspectRatio,
            bgmStyle,
            voiceTone,
            pacingTip,
            sceneLines,
            visualCues,
            cameraAngles,
          })
        );
        setCurrentProjectId(created.id);
        showNotice('success', '作品已成功保存至「我的作品」库！');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'projects');
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Save Dissected Formula to Templates & Dissections (Supports Domestic Phone/Email Account)
  const handleSaveDissectionToCloud = async () => {
    if (!user && !domesticUser) {
      setIsDomesticLoginOpen(true);
      showNotice('error', '请先使用手机号或邮箱登录以保存拆解模板。');
      return;
    }

    if (!user) {
      const newTpl: CloudViralTemplate = {
        id: `local_tpl_${Date.now()}`,
        ownerId: domesticUser?.uid || 'cn_default_creator',
        title: `${dissectResult.sourceTitle}（拆解复用模板）`,
        category: dissectCategory,
        hookFormula: dissectResult.hookAnalysis,
        structureSummary: dissectResult.extractedFormula,
        pacingStyle: 'AI拆解高完播节奏',
        bgmStyle: '轻快种草卡点律动',
        sceneLines: [...dissectResult.sceneLines],
        visualCues: [...dissectResult.visualCues],
        cameraAngles: [...dissectResult.cameraAngles],
      };
      setLocalTemplates((prev) => [newTpl, ...prev]);
      showNotice('success', '已将该爆款结构存入您的「拆解报告库」与专属模板！');
      return;
    }

    try {
      await addDoc(
        collection(db, 'dissections'),
        buildVideoDissectionCreatePayload({
          ownerId: user.uid,
          sourceTitle: dissectResult.sourceTitle,
          sourceContent: dissectResult.sourceContent,
          hookAnalysis: dissectResult.hookAnalysis,
          retentionSecret: dissectResult.retentionSecret,
          conversionTrigger: dissectResult.conversionTrigger,
          extractedFormula: dissectResult.extractedFormula,
          sceneBreakdown: dissectResult.sceneBreakdown,
        })
      );

      await addDoc(
        collection(db, 'templates'),
        buildViralTemplateCreatePayload({
          ownerId: user.uid,
          title: `${dissectResult.sourceTitle}（拆解复用模板）`,
          category: dissectCategory,
          hookFormula: dissectResult.hookAnalysis,
          structureSummary: dissectResult.extractedFormula,
          pacingStyle: 'AI拆解高完播节奏',
          bgmStyle: '轻快种草卡点律动',
          sceneLines: dissectResult.sceneLines,
          visualCues: dissectResult.visualCues,
          cameraAngles: dissectResult.cameraAngles,
        })
      );

      showNotice('success', '已将该爆款结构存入您的云端拆解库与自定义模板库！');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'dissections');
    }
  };

  const navTitleMap: Record<NavTab, string> = {
    workbench: 'AI 工作台',
    templates: '海量爆款库',
    graphic_suite: '电商套图Pro · 一句话图文',
    store_kb: '抖音来客 · 门店记忆库',
    editor: '智能分镜精修与混剪',
    dissect: 'SkillHub 爆款拆解',
    my_projects: '我的成片作品',
    my_saved: '拆解与专属模板',
    pricing: '会员与算力中心',
    video_remix: 'AI 视频混剪成片中心',
  };

  const tierLabelMap: Record<'free' | 'pro' | 'enterprise', string> = {
    free: '体验版',
    pro: '专业版 Pro',
    enterprise: '企业 MCN 版',
  };

  const activeAccountName =
    user?.displayName || domesticUser?.displayName || null;

  const filteredHistoryRecords = historyRecords.filter((item) =>
    historyFilterTab === 'all' ? true : item.type === historyFilterTab
  );

  return (
    <div className="flex min-h-screen bg-transparent text-slate-800">
      {/* Left Sidebar Navigation (Light-Blue Frosted Glass + Collapsible History Panel) */}
      <aside
        className={`hidden shrink-0 flex-col justify-between border-r border-sky-200/75 bg-white/80 backdrop-blur-md transition-all duration-200 lg:flex ${
          sidebarCollapsed ? 'w-16 p-2.5' : 'w-64 p-3.5'
        }`}
      >
        <div className="flex flex-1 flex-col space-y-4 overflow-y-auto pr-0.5">
          {/* Brand Logo + Collapse Toggle */}
          <div className="flex items-center justify-between px-1.5 pt-1">
            <button
              type="button"
              onClick={() => setActiveNav('workbench')}
              className="flex items-center gap-2.5 text-left cursor-pointer min-w-0"
            >
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg iridescent-btn text-white text-sm font-bold shadow-xs">
                快
              </div>
              {!sidebarCollapsed && (
                <div className="min-w-0">
                  <span className="text-sm font-bold tracking-tight text-slate-900 block truncate">
                    快拍智造
                  </span>
                  <span className="text-[10px] text-slate-500 block truncate">
                    AI 爆款视频工场
                  </span>
                </div>
              )}
            </button>
            <button
              type="button"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-sky-50 hover:text-slate-700 cursor-pointer"
              title={sidebarCollapsed ? '展开导航栏' : '收起导航栏'}
            >
              {sidebarCollapsed ? (
                <PanelLeftOpen className="h-4 w-4" />
              ) : (
                <PanelLeftClose className="h-4 w-4" />
              )}
            </button>
          </div>

          {/* Group 1: 工作台 (可收起/可展开主功能模块) */}
          <div className="space-y-1">
            {!sidebarCollapsed ? (
              <button
                type="button"
                onClick={() => toggleNavSection('workbench')}
                className="flex w-full items-center justify-between px-2.5 py-1 text-left text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer select-none"
              >
                <span className="flex items-center gap-1.5">
                  <LayoutGrid className="h-3.5 w-3.5 text-sky-600" />
                  <span>工作台</span>
                  <span className="rounded bg-sky-100/90 px-1.5 py-0.2 text-[9px] font-bold text-sky-800">3</span>
                </span>
                {navSectionsOpen.workbench ? (
                  <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                )}
              </button>
            ) : null}

            {(!sidebarCollapsed ? navSectionsOpen.workbench : true) && (
              <nav className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => setActiveNav('workbench')}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'workbench'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="AI 工作台"
                >
                  <SparklesIcon className="h-4 w-4 shrink-0 text-indigo-500" />
                  {!sidebarCollapsed && <span>AI 工作台</span>}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveNav('templates')}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'templates'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="海量爆款库"
                >
                  <span className="flex items-center gap-2.5">
                    <LayoutGrid className="h-4 w-4 shrink-0 text-sky-600" />
                    {!sidebarCollapsed && <span>海量爆款库</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="rounded bg-sky-100/80 px-1.5 py-0.5 text-[10px] font-semibold text-sky-700">
                      HOT
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveNav('my_projects')}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'my_projects'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="我的作品"
                >
                  <span className="flex items-center gap-2.5">
                    <FolderKanban className="h-4 w-4 shrink-0 text-amber-500" />
                    {!sidebarCollapsed && <span>我的作品</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="font-mono text-[11px] text-slate-400">
                      {allUserProjects.length}
                    </span>
                  )}
                </button>
              </nav>
            )}
          </div>

          {/* Group 2: 内容创作 (可收起/可展开主功能模块) */}
          <div className="space-y-1">
            {!sidebarCollapsed ? (
              <button
                type="button"
                onClick={() => toggleNavSection('creation')}
                className="flex w-full items-center justify-between px-2.5 py-1 text-left text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer select-none"
              >
                <span className="flex items-center gap-1.5">
                  <Film className="h-3.5 w-3.5 text-indigo-600" />
                  <span>内容创作</span>
                  <span className="rounded bg-indigo-100/90 px-1.5 py-0.2 text-[9px] font-bold text-indigo-700">4</span>
                </span>
                {navSectionsOpen.creation ? (
                  <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                )}
              </button>
            ) : null}

            {(!sidebarCollapsed ? navSectionsOpen.creation : true) && (
              <nav className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => setActiveNav('editor')}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'editor'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="AI 脚本与分镜"
                >
                  <Film className="h-4 w-4 shrink-0 text-indigo-500" />
                  {!sidebarCollapsed && <span>AI 脚本与分镜</span>}
                </button>

                {/* AI 视频混剪成片 (双模式及直达快捷子项，完全响应点击并联动模式) */}
                <div className="space-y-1">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveNav('video_remix');
                      showNotice('success', '已进入：AI 视频混剪成片中心');
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                      activeNav === 'video_remix'
                        ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                        : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                    }`}
                    title="AI 视频混剪成片"
                  >
                    <div className="flex items-center gap-2.5">
                      <Play className="h-4 w-4 shrink-0 text-sky-600" />
                      {!sidebarCollapsed && <span>AI 视频混剪成片</span>}
                    </div>
                    {!sidebarCollapsed && (
                      <span className="rounded bg-sky-100/80 px-1.5 py-0.5 text-[10px] font-semibold text-sky-700">
                        双模式
                      </span>
                    )}
                  </button>

                  {!sidebarCollapsed && (
                    <div className="mx-1 flex items-center justify-between gap-1 rounded-xl border border-sky-200/80 bg-sky-50/50 p-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setRemixStudioMode('foolproof');
                          setActiveNav('video_remix');
                          showNotice('success', '已切换至：⚡ 傻瓜套模板极速混剪');
                        }}
                        className={`flex-1 flex items-center justify-center gap-1 rounded-lg py-1 px-1 text-[11px] font-medium transition-all cursor-pointer ${
                          activeNav === 'video_remix' && remixStudioMode === 'foolproof'
                            ? 'bg-white text-indigo-700 font-bold shadow-2xs'
                            : 'text-slate-600 hover:bg-white/80 hover:text-slate-900'
                        }`}
                        title="点击直接进入傻瓜套模板极速成片"
                      >
                        <span className="text-amber-500">⚡</span>
                        <span>傻瓜套模板</span>
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setRemixStudioMode('pro_nle');
                          setActiveNav('video_remix');
                          showNotice('success', '已切换至：🎛️ 专业微操多轨混剪台');
                        }}
                        className={`flex-1 flex items-center justify-center gap-1 rounded-lg py-1 px-1 text-[11px] font-medium transition-all cursor-pointer ${
                          activeNav === 'video_remix' && remixStudioMode === 'pro_nle'
                            ? 'bg-white text-indigo-700 font-bold shadow-2xs'
                            : 'text-slate-600 hover:bg-white/80 hover:text-slate-900'
                        }`}
                        title="点击直接进入专业多轨时间线微操混剪台"
                      >
                        <span className="text-indigo-500">🎛️</span>
                        <span>专业微操台</span>
                      </button>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setActiveNav('dissect')}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'dissect'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="一键拉片拆解"
                >
                  <Scissors className="h-4 w-4 shrink-0 text-rose-500" />
                  {!sidebarCollapsed && <span>一键拉片拆解</span>}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveNav('graphic_suite')}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'graphic_suite'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="电商套图 · 图文"
                >
                  <span className="flex items-center gap-2.5">
                    <Layers className="h-4 w-4 shrink-0 text-purple-500" />
                    {!sidebarCollapsed && <span>电商套图 · 图文</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="rounded bg-indigo-50 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-600">
                      PRO
                    </span>
                  )}
                </button>
              </nav>
            )}
          </div>

          {/* Group 3: 商铺经营 (可收起/可展开主功能模块) */}
          <div className="space-y-1">
            {!sidebarCollapsed ? (
              <button
                type="button"
                onClick={() => toggleNavSection('merchant')}
                className="flex w-full items-center justify-between px-2.5 py-1 text-left text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer select-none"
              >
                <span className="flex items-center gap-1.5">
                  <Store className="h-3.5 w-3.5 text-emerald-600" />
                  <span>商铺经营</span>
                  <span className="rounded bg-emerald-100/90 px-1.5 py-0.2 text-[9px] font-bold text-emerald-800">可选</span>
                </span>
                {navSectionsOpen.merchant ? (
                  <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                )}
              </button>
            ) : null}

            {(!sidebarCollapsed ? navSectionsOpen.merchant : true) && (
              <nav className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => {
                    setMerchantSubTab('stores');
                    setActiveNav('store_kb');
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'store_kb' && merchantSubTab === 'stores'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="门店管理"
                >
                  <Store className="h-4 w-4 shrink-0 text-emerald-500" />
                  {!sidebarCollapsed && <span>门店管理</span>}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMerchantSubTab('staff');
                    setActiveNav('store_kb');
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'store_kb' && merchantSubTab === 'staff'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="员工管理"
                >
                  <Users className="h-4 w-4 shrink-0 text-blue-500" />
                  {!sidebarCollapsed && <span>员工管理</span>}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setMerchantSubTab('materials');
                    setActiveNav('store_kb');
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'store_kb' && merchantSubTab === 'materials'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="素材管理"
                >
                  <ImageIcon className="h-4 w-4 shrink-0 text-violet-500" />
                  {!sidebarCollapsed && <span>素材管理</span>}
                </button>
              </nav>
            )}
          </div>

          {/* Group 4: 数据与模型 (可收起/可展开主功能模块) */}
          <div className="space-y-1">
            {!sidebarCollapsed ? (
              <button
                type="button"
                onClick={() => toggleNavSection('data')}
                className="flex w-full items-center justify-between px-2.5 py-1 text-left text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer select-none"
              >
                <span className="flex items-center gap-1.5">
                  <Cpu className="h-3.5 w-3.5 text-purple-600" />
                  <span>数据与模型</span>
                  <span className="rounded bg-purple-100/90 px-1.5 py-0.2 text-[9px] font-bold text-purple-800">4</span>
                </span>
                {navSectionsOpen.data ? (
                  <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                )}
              </button>
            ) : null}

            {(!sidebarCollapsed ? navSectionsOpen.data : true) && (
              <nav className="space-y-0.5">
                <button
                  type="button"
                  onClick={() => setActiveNav('my_saved')}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'my_saved'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="拆解报告库"
                >
                  <span className="flex items-center gap-2.5">
                    <BookmarkCheck className="h-4 w-4 shrink-0 text-amber-500" />
                    {!sidebarCollapsed && <span>拆解报告库</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="font-mono text-[11px] text-slate-400">
                      {allUserTemplates.length + cloudDissections.length}
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setIsGatewayModalOpen(true)}
                  className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium text-slate-600 hover:bg-sky-50/60 hover:text-slate-900 transition-colors cursor-pointer"
                  title="AI 模型网关"
                >
                  <span className="flex items-center gap-2.5">
                    <Cpu className="h-4 w-4 shrink-0 text-indigo-500" />
                    {!sidebarCollapsed && <span>AI 模型网关</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveNav('pricing')}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    activeNav === 'pricing'
                      ? 'bg-indigo-50 text-indigo-600 font-semibold shadow-2xs'
                      : 'text-slate-600 hover:bg-sky-50/60 hover:text-slate-900'
                  }`}
                  title="订阅与算力"
                >
                  <span className="flex items-center gap-2.5">
                    <Crown className="h-4 w-4 shrink-0 text-amber-500" />
                    {!sidebarCollapsed && <span>订阅与算力</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="font-mono text-[11px] text-indigo-600">
                      {credits}点
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setIsManualModalOpen(true)}
                  title="查看完整操作指南与系统架构文档"
                  className="flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium text-slate-600 hover:bg-sky-50/60 hover:text-slate-900 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2.5">
                    <FileText className="h-4 w-4 shrink-0 text-sky-600" />
                    {!sidebarCollapsed && <span>说明文档</span>}
                  </span>
                  {!sidebarCollapsed && (
                    <span className="rounded bg-sky-100/80 px-1.5 py-0.5 text-[10px] font-semibold text-sky-700">
                      指南
                    </span>
                  )}
                </button>
              </nav>
            )}
          </div>

          {/* Group 5: 历史记录 (可收起/可展开主功能模块，高度大幅加高扩大，杜绝狭窄局促) */}
          {!sidebarCollapsed ? (
            <div className="pt-2 border-t border-sky-100/90 flex-1 min-h-0 flex flex-col">
              <button
                type="button"
                onClick={() => toggleNavSection('history')}
                className="flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-sky-50/70 transition-colors cursor-pointer select-none"
              >
                <span className="flex items-center gap-2">
                  <History className="h-3.5 w-3.5 text-indigo-600" />
                  <span>历史记录</span>
                  <span className="rounded-full bg-sky-100/90 px-2 py-0.5 font-mono text-[10px] text-sky-800 font-bold">
                    {historyRecords.length}
                  </span>
                </span>
                {navSectionsOpen.history ? (
                  <ChevronUp className="h-3.5 w-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
                )}
              </button>

              {navSectionsOpen.history && (
                <div className="mt-2 flex-1 min-h-[220px] max-h-[380px] flex flex-col space-y-2 rounded-2xl border border-sky-200/80 bg-gradient-to-b from-sky-50/70 to-white/90 p-2.5 shadow-xs overflow-hidden">
                  {/* 分类筛选小标签 + 清空 */}
                  <div className="flex items-center justify-between gap-1 shrink-0 pb-1.5 border-b border-sky-100">
                    <div className="flex items-center gap-0.5 rounded-lg bg-slate-100/90 p-0.5 border border-sky-200/60 text-[10px]">
                      {(
                        [
                          { id: 'all', label: '全部' },
                          { id: 'prompt', label: '提问' },
                          { id: 'action', label: '操作' },
                          { id: 'project', label: '项目' },
                        ] as const
                      ).map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() => setHistoryFilterTab(tab.id)}
                          className={`rounded px-1.5 py-0.5 font-medium transition-all cursor-pointer ${
                            historyFilterTab === tab.id
                              ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                              : 'text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                    {historyRecords.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setHistoryRecords([])}
                        className="text-[10px] text-slate-400 hover:text-rose-600 cursor-pointer px-1.5 py-0.5 rounded hover:bg-rose-50 transition-colors"
                        title="清空历史记录"
                      >
                        清空
                      </button>
                    )}
                  </div>

                  {/* 历史记录列表 (大气卡片式展示，杜绝折叠截断) */}
                  {filteredHistoryRecords.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-6 text-center text-xs text-slate-400">
                      <History className="h-6 w-6 text-slate-300 mb-1" />
                      <span>暂无相关历史记录</span>
                    </div>
                  ) : (
                    <div className="flex-1 space-y-1.5 overflow-y-auto pr-0.5">
                      {filteredHistoryRecords.map((rec) => {
                        const typeBadge =
                          rec.type === 'prompt'
                            ? { label: '提问', color: 'bg-purple-100 text-purple-700 border-purple-200' }
                            : rec.type === 'project'
                            ? { label: '项目', color: 'bg-amber-100 text-amber-800 border-amber-200' }
                            : { label: '混剪', color: 'bg-sky-100 text-sky-800 border-sky-200' };

                        return (
                          <div
                            key={rec.id}
                            onClick={() => {
                              if (rec.payloadPrompt) {
                                setQuickHeroPrompt(rec.payloadPrompt);
                              }
                              setActiveNav(rec.targetNav);
                              showNotice('success', `已恢复历史记录：「${rec.title}」`);
                            }}
                            title={`点击恢复并前往对应工作台：\n${rec.title}\n${rec.subtitle}`}
                            className="group flex w-full flex-col rounded-xl border border-slate-200/90 bg-white p-2 text-left hover:border-indigo-400 hover:shadow-xs hover:bg-indigo-50/20 transition-all cursor-pointer"
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className={`rounded px-1 py-0.2 text-[9px] font-semibold border ${typeBadge.color}`}>
                                {typeBadge.label}
                              </span>
                              <span className="shrink-0 text-[10px] text-slate-400 font-mono">
                                {rec.timeText}
                              </span>
                            </div>
                            <div className="mt-1 text-xs font-semibold text-slate-800 group-hover:text-indigo-600 line-clamp-2 leading-snug">
                              {rec.title}
                            </div>
                            <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-50 pt-1">
                              <span className="truncate max-w-[130px]">{rec.subtitle}</span>
                              <span className="shrink-0 text-[10px] font-bold text-indigo-600 opacity-80 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all">
                                恢复 →
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                setSidebarCollapsed(false);
                setNavSectionsOpen((prev) => ({ ...prev, history: true }));
              }}
              className="flex w-full justify-center rounded-lg p-2 text-slate-500 hover:bg-sky-50 hover:text-indigo-600 cursor-pointer"
              title="展开查看历史记录"
            >
              <History className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Bottom Primary Account Info (Phone / Email Primary Binding) */}
        <div className="border-t border-slate-100 pt-3">
          {!sidebarCollapsed ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between rounded-lg bg-slate-50 px-2.5 py-2 border border-slate-200/70">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    <span className="text-[11px] font-semibold text-slate-700 truncate">
                      {storeMemoryEnabled
                        ? `门店：${activeStoreProfile.storeName.slice(0, 8)}`
                        : '个人创作模式'}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    店铺/店员为可选附加项
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setStoreMemoryEnabled(!storeMemoryEnabled)}
                  className="text-[11px] font-medium text-indigo-600 hover:underline cursor-pointer shrink-0"
                >
                  {storeMemoryEnabled ? '解绑' : '启用'}
                </button>
              </div>

              <div className="flex items-center justify-between px-1">
                <button
                  type="button"
                  onClick={() => setIsDomesticLoginOpen(true)}
                  className="min-w-0 text-left cursor-pointer"
                >
                  <p className="truncate text-xs font-semibold text-slate-800">
                    {activeAccountName || '点击登录账号'}
                  </p>
                  <p className="truncate text-[11px] text-slate-400">
                    {domesticUser?.contact || user?.email || '支持手机号/邮箱登录'}
                  </p>
                </button>
                {activeAccountName && (
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
                    title="退出账号"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsDomesticLoginOpen(true)}
              className="flex w-full justify-center rounded-lg p-2 text-slate-600 hover:bg-slate-100 cursor-pointer"
              title="账号中心"
            >
              <Phone className="h-4 w-4 text-indigo-600" />
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Clean Top Header Bar (Light-Blue Frosted Glass + Responsive flex-wrap) */}
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-sky-200/75 bg-white/80 backdrop-blur-md px-4 sm:px-6 py-2.5">
          {/* Left: Global Search / AI Command Bar */}
          <div className="flex items-center gap-3 flex-1 min-w-[220px] max-w-xl">
            <div className="relative flex-1 min-w-0">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={quickHeroPrompt}
                onChange={(e) => setQuickHeroPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && quickHeroPrompt.trim()) {
                    const q = quickHeroPrompt.trim();
                    recordHistoryEntry('prompt', q, '顶部全局搜索回车生成', 'editor', q);
                    setProductName(q);
                    setActiveNav('editor');
                    handleAIGenerateScript(
                      undefined,
                      undefined,
                      q,
                      activeStoreProfile.memoryAnchors,
                      activeStoreProfile.targetAudience,
                      activeStoreProfile.industry
                    );
                  }
                }}
                placeholder="搜爆款脚本 / 职人管理 / 输入商品卖点回车直接生成脚本..."
                className="h-8 w-full rounded-full border border-sky-200/80 bg-white/90 pl-8 pr-12 text-xs text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none"
              />
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[11px] font-semibold text-indigo-600">
                AI+
              </span>
            </div>
          </div>

          {/* Right: Manual Doc + RAG Copilot + Credits + Model Gateway + Account (Phone/Email) */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setIsManualModalOpen(true)}
              title="查看产品操作说明与系统架构手册"
              className="flex items-center gap-1.5 rounded-lg border border-sky-200/85 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:border-sky-400 hover:text-[#24568d] whitespace-nowrap cursor-pointer"
            >
              <FileText className="h-3.5 w-3.5 text-[#3572b0] shrink-0" />
              <span>说明文档</span>
            </button>

            <button
              type="button"
              onClick={() => setIsRagCopilotOpen(!isRagCopilotOpen)}
              title="打开门店知识库 AI 侧栏助手"
              className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                isRagCopilotOpen
                  ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                  : 'border-indigo-200 bg-indigo-50/80 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              <Bot className="h-3.5 w-3.5 shrink-0" />
              <span>AI 智库助手</span>
            </button>

            <button
              type="button"
              onClick={() => setIsPersonalAgentModalOpen(true)}
              title="定制专属 AI 智能体与深度 RAG 知识库"
              className="flex items-center gap-1.5 rounded-lg border border-purple-200 bg-purple-50/90 px-2.5 py-1.5 text-xs font-semibold text-purple-700 hover:bg-purple-100 whitespace-nowrap cursor-pointer transition-colors shadow-2xs"
            >
              <BrainCircuit className="h-3.5 w-3.5 text-purple-600 shrink-0" />
              <span className="hidden xl:inline">专属智能体 & RAG</span>
              <span className="xl:hidden">智能体RAG</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveNav('pricing')}
              title="查看订阅等级与算力余额"
              className="hidden sm:flex items-center gap-1.5 rounded-lg border border-sky-200/80 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:border-indigo-300 whitespace-nowrap cursor-pointer"
            >
              <Crown className="h-3.5 w-3.5 text-amber-500 shrink-0" />
              <span>算力：{credits}</span>
            </button>

            <button
              type="button"
              onClick={() => setShareModalProject(currentEditorExportData)}
              className="flex items-center gap-1.5 rounded-lg border border-amber-200 bg-amber-50/80 px-2.5 py-1.5 text-xs font-semibold text-amber-800 hover:bg-amber-100 whitespace-nowrap cursor-pointer"
              title="生成中国大陆秒开推广链接"
            >
              <Globe className="h-3.5 w-3.5 text-amber-600 shrink-0" />
              <span className="hidden sm:inline">国内直连分享</span>
            </button>

            <button
              type="button"
              onClick={() => setIsGatewayModalOpen(true)}
              title="切换模型网关接口"
              className="flex items-center gap-1.5 rounded-lg border border-sky-200/80 bg-white/90 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:border-indigo-300 whitespace-nowrap cursor-pointer"
            >
              <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
              <span className="hidden md:inline">{gatewayConfig.providerName.slice(0, 6)}</span>
              <Cpu className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => setIsDomesticLoginOpen(true)}
              title="切换或绑定手机号/邮箱账号"
              className="flex items-center gap-2 rounded-lg border border-sky-200/80 bg-white/90 px-3 py-1.5 text-xs font-medium text-slate-800 hover:border-indigo-300 whitespace-nowrap cursor-pointer"
            >
              <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-[10px] font-semibold text-white">
                {(activeAccountName || '手')[0]}
              </div>
              <span className="truncate max-w-[110px]">{activeAccountName || '手机号/邮箱登录'}</span>
            </button>
          </div>
        </header>

        {/* Responsive Compact Horizontal Nav Bar for Narrow Windows (< 1024px) */}
        <div className="flex lg:hidden items-center gap-1.5 overflow-x-auto border-b border-sky-200/80 bg-white/85 backdrop-blur-md px-4 py-2 text-xs">
          {(
            [
              { id: 'workbench', label: 'AI 工作台' },
              { id: 'templates', label: '海量爆款库' },
              { id: 'video_remix', label: 'AI 视频混剪成片' },
              { id: 'editor', label: 'AI 脚本与分镜' },
              { id: 'dissect', label: '一键拉片拆解' },
              { id: 'graphic_suite', label: '电商套图·图文' },
              { id: 'store_kb', label: '门店/员工/素材' },
              { id: 'my_projects', label: '我的作品' },
              { id: 'pricing', label: '订阅与算力' },
            ] as { id: NavTab; label: string }[]
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveNav(item.id)}
              className={`rounded-lg px-2.5 py-1 font-medium whitespace-nowrap transition-colors cursor-pointer ${
                activeNav === item.id
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'bg-sky-50 text-slate-600 hover:bg-sky-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Shared Client Review Banner */}
        {sharedViewBanner && (
          <div className="flex items-center justify-between border-b border-indigo-200 bg-indigo-50 px-6 py-2.5 text-xs font-medium text-indigo-900">
            <span>{sharedViewBanner}</span>
            <button
              type="button"
              onClick={() => setSharedViewBanner(null)}
              className="text-xs font-semibold underline"
            >
              我知道了
            </button>
          </div>
        )}

        {/* Global Notification Toast Banner */}
        {bannerNotice && (
          <div
            className={`flex items-center justify-between border-b px-6 py-2.5 text-xs font-medium ${
              bannerNotice.type === 'error'
                ? 'border-red-200 bg-red-50 text-red-800'
                : 'border-emerald-200 bg-emerald-50 text-emerald-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {bannerNotice.type === 'error' ? (
                <AlertCircle className="h-4 w-4 shrink-0 text-red-600" />
              ) : (
                <Check className="h-4 w-4 shrink-0 text-emerald-600" />
              )}
              <span>{bannerNotice.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setBannerNotice(null)}
              className="text-xs underline"
            >
              关闭
            </button>
          </div>
        )}

        {/* VIEW 0A: 双模式「AI 视频混剪成片中心」(全宽自适应，无多余白边) */}
        {activeNav === 'video_remix' && (
          <main className="w-full flex-1 p-4 sm:p-6 lg:p-8">
            <AIVideoRemixDualStudio
              initialMode={remixStudioMode}
              projectTitle={projectTitle}
              setProjectTitle={setProjectTitle}
              productName={productName}
              setProductName={setProductName}
              sellingPoints={sellingPoints}
              setSellingPoints={setSellingPoints}
              category={projectCategory}
              aspectRatio={aspectRatio}
              setAspectRatio={setAspectRatio}
              bgmStyle={bgmStyle}
              setBgmStyle={setBgmStyle}
              voiceTone={voiceTone}
              setVoiceTone={setVoiceTone}
              cameraAngles={cameraAngles}
              setCameraAngles={setCameraAngles}
              visualCues={visualCues}
              setVisualCues={setVisualCues}
              sceneLines={sceneLines}
              setSceneLines={setSceneLines}
              shotDurations={shotDurations}
              setShotDurations={setShotDurations}
              shotMovements={shotMovements}
              setShotMovements={setShotMovements}
              activeStore={activeStoreProfile}
              onShowNotice={showNotice}
              onNavigateToEditor={() => setActiveNav('editor')}
              onOpenCustomAgentModal={() => setIsPersonalAgentModalOpen(true)}
            />
          </main>
        )}

        {/* VIEW 0B: 电商套图Pro & 一句话图文工作台 (全宽自适应) */}
        {activeNav === 'graphic_suite' && (
          <main className="w-full flex-1 p-4 sm:p-6 lg:p-8">
            <EcommerceSuiteAndGraphicWorkspace
              activeStore={activeStoreProfile}
              onExportSuccess={(msg) => {
                recordHistoryEntry('action', msg, '电商套图Pro · 图文生成', 'graphic_suite');
                showNotice('success', msg);
              }}
            />
          </main>
        )}

        {/* VIEW 1A: 独立「AI 工作台」首页 (全宽自适应，彻底消除两边留白) */}
        {activeNav === 'workbench' && (
          <main className="w-full flex-1 space-y-6 p-4 sm:p-6 lg:p-8">
            <KuaiziAgentHomeWorkbench
              promptValue={quickHeroPrompt}
              onChangePrompt={setQuickHeroPrompt}
              storeMemoryEnabled={storeMemoryEnabled}
              activeStore={activeStoreProfile}
              onOpenRagCopilot={() => setIsRagCopilotOpen(true)}
              onOpenPersonalAgentModal={() => setIsPersonalAgentModalOpen(true)}
              onEncapsulateAsTemplate={(tpl) => {
                recordHistoryEntry('action', `封装爆款模板：${tpl.title}`, '工作台一键封装', 'templates');
                handleEncapsulateAsTemplate(tpl);
              }}
              onApplyAgentDeliverableToEditor={(payload) => {
                recordHistoryEntry('project', payload.title, '超能Agent交付分镜工程', 'editor');
                setProjectTitle(payload.title);
                setCameraAngles([...payload.cameraAngles]);
                setVisualCues([...payload.visualCues]);
                setSceneLines([...payload.sceneLines]);
                setShotDurations(payload.cameraAngles.map(() => 4.0));
                setActiveNav('editor');
                showNotice('success', `已将 Agent 交付成果「${payload.title}」载入分镜精修台！`);
              }}
              onExecuteOmniAgent={(mode, promptText) => {
                const targetVal =
                  promptText.trim() || activeStoreProfile.signatureProducts.slice(0, 36);
                recordHistoryEntry(
                  'prompt',
                  targetVal,
                  `AI工作台 · ${mode}`,
                  mode === 'dissect'
                    ? 'dissect'
                    : mode === 'xhs_graphic' || mode === 'ecommerce_poster'
                    ? 'graphic_suite'
                    : 'editor',
                  targetVal
                );
                if (mode === 'dissect') {
                  setDissectContent(targetVal);
                  setActiveNav('dissect');
                  handleRunDissection(undefined, targetVal, activeStoreProfile.industry);
                } else if (mode === 'xhs_graphic' || mode === 'ecommerce_poster') {
                  setActiveNav('graphic_suite');
                } else if (mode === 'one_click_video') {
                  setProductName(targetVal);
                  setSellingPoints(activeStoreProfile.memoryAnchors);
                  setRemixStudioMode('foolproof');
                  setActiveNav('video_remix');
                } else {
                  setProductName(targetVal);
                  setSellingPoints(activeStoreProfile.memoryAnchors);
                  setActiveNav('editor');
                  handleAIGenerateScript(
                    undefined,
                    undefined,
                    targetVal,
                    activeStoreProfile.memoryAnchors,
                    activeStoreProfile.targetAudience,
                    activeStoreProfile.industry
                  );
                }
              }}
              onSelectCapability={(toolId) => {
                const promptDraft = quickHeroPrompt.trim();
                if (promptDraft) {
                  if (toolId === 'smart_dissect') {
                    setDissectContent(promptDraft);
                  } else {
                    setProductName(promptDraft);
                  }
                }
                if (toolId === 'write_script') {
                  setActiveNav('editor');
                  showNotice('success', '已进入：AI 脚本与分镜创作精修台');
                } else if (toolId === 'smart_dissect') {
                  setActiveNav('dissect');
                  showNotice('success', '已进入：一键拉片拆解中心');
                } else if (toolId === 'team_templates') {
                  setActiveNav('templates');
                  showNotice('success', '已进入：高转化爆款模板库');
                } else if (
                  toolId === 'smart_graphic' ||
                  toolId === 'product_poster' ||
                  toolId === 'ecommerce_main' ||
                  toolId === 'banner_personalize'
                ) {
                  setActiveNav('graphic_suite');
                  showNotice('success', '已进入：电商套图与图文创作工场');
                } else if (toolId === 'smart_mix') {
                  setRemixStudioMode('pro_nle');
                  setActiveNav('video_remix');
                  showNotice('success', '已进入：🎛️ 专业微操多轨混剪台');
                } else if (toolId === 'ai_oneclick_video') {
                  setRemixStudioMode('foolproof');
                  setActiveNav('video_remix');
                  showNotice('success', '已进入：⚡ 傻瓜套模板极速成片中心');
                } else {
                  setKuaiziToolModalId(toolId);
                }
              }}
            />

            {/* 下方封装好评度最高的 6 款精选爆款模板推荐（点击「查看全部爆款库」进入独立爆款库页面） */}
            <section className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-amber-50 px-2 py-0.5 text-xs font-bold text-amber-700 border border-amber-200/70 whitespace-nowrap">
                    ★ 98%+ 好评率
                  </span>
                  <h2 className="text-sm font-bold text-slate-900">
                    高分好评爆款模板推荐（一键换素材 · 同款裂变）
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveNav('templates')}
                  className="inline-flex items-center gap-1 rounded-lg border border-indigo-200 bg-indigo-50/70 px-3 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 whitespace-nowrap cursor-pointer"
                >
                  <span>进入海量爆款库 ({allCuratedTemplates.length}款)</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                {allCuratedTemplates.slice(0, 6).map((tpl) => (
                  <article
                    key={tpl.id}
                    onClick={() => setStudioModalTemplate(tpl)}
                    className="group flex flex-col justify-between overflow-hidden rounded-xl border border-slate-200/90 bg-white transition-all duration-200 hover:-translate-y-0.5 hover:border-indigo-400 hover:shadow-md cursor-pointer"
                  >
                    <div className="relative aspect-3/4 w-full overflow-hidden bg-slate-900">
                      <OriginalWorkCoverScene
                        sceneType={tpl.coverSceneType}
                        coverPhotoUrl={tpl.coverPhotoUrl}
                        headline={tpl.posterHeadline}
                        subhead={tpl.posterSubhead}
                      />
                      <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between p-2">
                        <span className="rounded bg-black/60 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white backdrop-blur-xs">
                          ★ {tpl.qualityScore}分
                        </span>
                      </div>
                      <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-1.5 bg-slate-950/60 p-2.5 opacity-0 backdrop-blur-[2px] transition-opacity duration-200 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setStudioModalTemplate(tpl);
                          }}
                          className="w-full rounded-lg bg-[#4F46E5] py-1.5 text-xs font-bold text-white hover:bg-[#4338CA] cursor-pointer"
                        >
                          ⚡ 一键做同款
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApplyTemplate(tpl, false, storeMemoryEnabled);
                          }}
                          className="w-full rounded-lg bg-white/95 py-1.5 text-[11px] font-semibold text-slate-900 hover:bg-white cursor-pointer"
                        >
                          载入分镜台
                        </button>
                      </div>
                    </div>
                    <div className="p-2.5">
                      <h4 className="line-clamp-1 text-xs font-bold text-slate-800 group-hover:text-indigo-600">
                        {tpl.title}
                      </h4>
                      <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-500">
                        <span className="truncate">{tpl.category}</span>
                        <span className="font-mono font-semibold text-indigo-600">
                          ♥ {tpl.likesCountText}
                        </span>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          </main>
        )}

        {/* VIEW 1B: 独立「海量爆款库」页面 (全宽自适应，专注筛选、搜索与卡槽套模板) */}
        {activeNav === 'templates' && (
          <main className="w-full flex-1 space-y-5 p-4 sm:p-6 lg:p-8">
            {/* Filter & Category Panel */}
            <section className="rounded-2xl border border-slate-200/90 bg-white p-5 shadow-2xs space-y-4">
              {/* Row 1: Template Mode Tabs + Search Input */}
              <div className="flex flex-col justify-between gap-3 border-b border-slate-100 pb-4 lg:flex-row lg:items-center">
                <div className="flex flex-wrap items-center gap-2">
                  {TEMPLATE_TABS.map((tab) => {
                    const active = selectedTemplateTab === tab;
                    return (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setSelectedTemplateTab(tab)}
                        className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                          active
                            ? 'bg-[#6D28D9] text-white shadow-2xs'
                            : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:text-slate-900'
                        }`}
                      >
                        {tab === '全部模板' ? '高级模板 Pro' : tab}
                      </button>
                    );
                  })}
                </div>

                {/* Search Input matching Screenshot 1 */}
                <div className="flex items-center w-full lg:w-80 rounded-full border border-slate-200 bg-slate-50/70 pl-3.5 pr-1 py-1 focus-within:border-[#6D28D9] focus-within:bg-white">
                  <Search className="h-3.5 w-3.5 text-slate-400 shrink-0 mr-2" />
                  <input
                    type="text"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    placeholder="海量灵感，一键同款..."
                    className="w-full bg-transparent text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none"
                  />
                  {searchKeyword && (
                    <button
                      type="button"
                      onClick={() => setSearchKeyword('')}
                      className="px-1.5 text-[11px] text-slate-400 hover:text-slate-600"
                    >
                      清空
                    </button>
                  )}
                  <span className="flex h-6 w-7 shrink-0 items-center justify-center rounded-full bg-[#6D28D9] text-white">
                    <Search className="h-3 w-3" />
                  </span>
                </div>
              </div>

              {/* Row 2: Pill Categories matching Screenshot 1 */}
              <div className="flex flex-wrap items-center gap-2">
                {INDUSTRY_CATEGORIES.map((cat) => {
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={`rounded-full px-3.5 py-1 text-xs font-medium transition-all cursor-pointer whitespace-nowrap ${
                        active
                          ? 'bg-[#6D28D9] text-white font-semibold shadow-2xs'
                          : 'border border-slate-200 bg-white text-slate-600 hover:border-purple-300 hover:text-[#6D28D9]'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>

              {/* Row 3: Content Type Filter & Count */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100 text-xs">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-slate-400 mr-1">展现形式：</span>
                  {CONTENT_TYPES.map((ct) => {
                    const active = selectedContentType === ct;
                    return (
                      <button
                        key={ct}
                        type="button"
                        onClick={() => setSelectedContentType(ct)}
                        className={`rounded-md px-2.5 py-1 text-xs transition-colors cursor-pointer ${
                          active
                            ? 'bg-slate-900 text-white font-semibold'
                            : 'text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {ct}
                      </button>
                    );
                  })}
                </div>

                <span className="text-xs text-slate-400">
                  共 <strong className="text-slate-800">{filteredTemplates.length}</strong> 款高转化模板（点击卡片打开「卡槽换素材 & AI裂变工坊」）
                </span>
              </div>
            </section>

            {/* High-Density Clean Poster Grid */}
            {filteredTemplates.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
                <p className="text-sm font-semibold text-slate-800">没有找到匹配的爆款模板</p>
                <p className="mt-1 text-xs text-slate-500">
                  您可以重置筛选条件，或返回「AI 工作台」用一句话直接生成脚本。
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTemplateTab('全部模板');
                    setSelectedCategory('全部');
                    setSelectedContentType('全部类型');
                    setSearchKeyword('');
                  }}
                  className="mt-4 rounded-lg bg-[#4F46E5] px-4 py-2 text-xs font-semibold text-white hover:bg-[#4338CA] cursor-pointer"
                >
                  重置全部筛选
                </button>
              </div>
            ) : (
              <section className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
                {filteredTemplates.map((tpl) => {
                  const isFav = favoriteIds.includes(tpl.id);
                  return (
                    <article
                      key={tpl.id}
                      onClick={() => setStudioModalTemplate(tpl)}
                      className="group flex flex-col justify-between overflow-hidden rounded-xl border border-slate-200/90 bg-white transition-all duration-200 hover:-translate-y-0.5 hover:border-indigo-400 hover:shadow-md cursor-pointer"
                    >
                      {/* Top 3:4 Magazine Poster Cover */}
                      <div className="relative aspect-3/4 w-full overflow-hidden bg-slate-900">
                        <OriginalWorkCoverScene
                          sceneType={tpl.coverSceneType}
                          coverPhotoUrl={tpl.coverPhotoUrl}
                          headline={tpl.posterHeadline}
                          subhead={tpl.posterSubhead}
                        />

                        {/* Top Bar: Score Badge + Favorite Star */}
                        <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between p-2.5">
                          <span className="rounded bg-black/55 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white backdrop-blur-xs">
                            {tpl.sourcePlatform.slice(0, 3)} · {tpl.qualityScore}分
                          </span>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setFavoriteIds((prev) =>
                                prev.includes(tpl.id)
                                  ? prev.filter((id) => id !== tpl.id)
                                  : [...prev, tpl.id]
                              );
                            }}
                            className="flex h-6 w-6 items-center justify-center rounded-full bg-white/90 text-slate-600 shadow-2xs transition-transform hover:scale-110"
                            title={isFav ? '取消收藏' : '收藏模板'}
                          >
                            <Star
                              className={`h-3.5 w-3.5 ${
                                isFav
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-amber-500'
                              }`}
                            />
                          </button>
                        </div>

                        {/* Hover Interactive Overlay: 3 Instant Pro Workflows */}
                        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 bg-slate-950/60 p-3 opacity-0 backdrop-blur-[2px] transition-opacity duration-200 group-hover:opacity-100">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setStudioModalTemplate(tpl);
                            }}
                            className="w-full rounded-lg bg-[#4F46E5] py-2 text-xs font-bold text-white shadow-sm hover:bg-[#4338CA] cursor-pointer"
                          >
                            ⚡ 套模板 / 换素材
                          </button>

                          <div className="grid w-full grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleApplyTemplate(tpl, false, storeMemoryEnabled);
                              }}
                              className="rounded-lg bg-white/95 py-1.5 text-[11px] font-semibold text-slate-900 hover:bg-white cursor-pointer"
                            >
                              一键改脚本
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDissectFromTemplate(tpl);
                              }}
                              className="rounded-lg bg-white/95 py-1.5 text-[11px] font-semibold text-indigo-700 hover:bg-white cursor-pointer"
                            >
                              AI 拉片拆解
                            </button>
                          </div>

                          <a
                            href={tpl.sourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="mt-1 inline-flex items-center gap-1 text-[11px] font-medium text-amber-300 hover:underline"
                          >
                            <span>查看原视频/图文</span>
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </div>

                        {/* Bottom Scrim: Author & Duration */}
                        <div className="absolute inset-x-0 bottom-0 z-10 flex items-center justify-between bg-gradient-to-t from-black/80 via-black/35 to-transparent px-2.5 py-2 text-[11px] text-white">
                          <span className="truncate max-w-[70%]">{tpl.sourceAuthor}</span>
                          <span className="font-mono text-[10px] opacity-90">{tpl.durationText}</span>
                        </div>
                      </div>

                      {/* Clean Card Footer */}
                      <div className="flex flex-1 flex-col justify-between p-3">
                        <h4 className="line-clamp-2 break-words text-xs font-bold text-slate-800 leading-snug group-hover:text-indigo-600 transition-colors">
                          {tpl.title}
                        </h4>

                        <div className="mt-2.5 flex items-center justify-between pt-1 text-[11px]">
                          <span className="rounded bg-slate-100 px-2 py-0.5 font-medium text-slate-600 truncate max-w-[55%]">
                            {tpl.posterTag || tpl.category}
                          </span>
                          <span className="font-mono font-semibold text-[#6D28D9] shrink-0">
                            ♥ {tpl.likesCountText}
                          </span>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </section>
            )}
          </main>
        )}

        {/* VIEW 2: 抖音来客同款 · 商铺经营中心 (全宽自适应) */}
        {activeNav === 'store_kb' && (
          <main className="w-full flex-1 p-4 sm:p-6 lg:p-8">
            <MerchantManagementCenter
              subTab={merchantSubTab}
              onChangeSubTab={setMerchantSubTab}
              accountContact={domesticUser?.contact || user?.email || '138****8000'}
              storeMemoryEnabled={storeMemoryEnabled}
              onToggleStoreMemory={setStoreMemoryEnabled}
              stores={allStoreProfiles}
              activeStoreId={activeStoreId}
              onSelectStore={handleSelectStoreProfile}
              onSaveStore={async (storeDraft, editId) => {
                if (editId) {
                  setLocalStores((prev) =>
                    prev.map((s) => (s.id === editId ? { ...storeDraft, id: editId } : s))
                  );
                  showNotice('success', `门店「${storeDraft.storeName}」档案已更新！`);
                } else {
                  const newStore: StoreMemoryProfile = {
                    ...storeDraft,
                    id: `custom_store_${Date.now()}`,
                  };
                  setLocalStores((prev) => [newStore, ...prev]);
                  setActiveStoreId(newStore.id);
                  showNotice('success', `已新建门店档案「${storeDraft.storeName}」并设为当前门店！`);
                }
              }}
              onDeleteStore={async (storeId) => {
                if (storeId.startsWith('custom_store_')) {
                  setLocalStores((prev) => prev.filter((s) => s.id !== storeId));
                  showNotice('success', '已删除该门店档案。');
                  return;
                }
                if (user) {
                  try {
                    await deleteDoc(doc(db, 'store_profiles', storeId));
                    showNotice('success', '已删除该门店记录。');
                  } catch (err) {
                    handleFirestoreError(err, OperationType.DELETE, `store_profiles/${storeId}`);
                  }
                }
              }}
              onUseStoreForScript={(st) => {
                handleSelectStoreProfile(st);
                setStoreMemoryEnabled(true);
                setProductName(st.signatureProducts.slice(0, 48));
                setSellingPoints(st.memoryAnchors);
                setTargetAudience(st.targetAudience);
                setProjectCategory(st.industry);
                setActiveNav('editor');
                handleAIGenerateScript(
                  undefined,
                  undefined,
                  st.signatureProducts.slice(0, 48),
                  st.memoryAnchors,
                  st.targetAudience,
                  st.industry
                );
              }}
              onShowNotice={showNotice}
            />
          </main>
        )}

        {/* VIEW 3: 筷子科技同款 · 脚本详情 & 公司宣传片9列拍摄脚本表 (全宽自适应，彻底消除两边留白) */}
        {activeNav === 'editor' && (
          <main className="w-full flex-1 space-y-4 p-4 sm:p-6 lg:p-8">
            {/* Clean Compact AI Generator Strip (Collapsible so it never clutters the Script Detail view) */}
            <section className="rounded-xl border border-slate-200/90 bg-white px-5 py-3.5 shadow-2xs">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 flex-1 min-w-[260px]">
                  <span className="rounded-md bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-600 shrink-0">
                    AI 编导设定
                  </span>
                  <input
                    type="text"
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    placeholder="输入推广商品或宣传片主题..."
                    className="h-8 flex-1 rounded-lg border border-slate-200 bg-slate-50/70 px-3 text-xs text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none"
                  />
                  <input
                    type="text"
                    value={sellingPoints}
                    onChange={(e) => setSellingPoints(e.target.value)}
                    placeholder="核心卖点 / 镜头要求..."
                    className="hidden md:block h-8 flex-1 rounded-lg border border-slate-200 bg-slate-50/70 px-3 text-xs text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowQuickGenDrawer(!showQuickGenDrawer)}
                    className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    {showQuickGenDrawer ? '收起参数' : '更多参数'}
                  </button>
                  <button
                    type="button"
                    disabled={isGeneratingScript}
                    onClick={() => handleAIGenerateScript()}
                    className="flex items-center gap-1.5 rounded-lg bg-[#4F46E5] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#4338CA] disabled:opacity-50 cursor-pointer"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>{isGeneratingScript ? '生成中...' : 'AI 一键生成脚本'}</span>
                  </button>
                </div>
              </div>

              {showQuickGenDrawer && (
                <div className="mt-3 grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 sm:grid-cols-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      快捷预设行业商品
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {QUICK_PRODUCT_PRESETS.map((preset) => (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => {
                            setProductName(preset.productName);
                            setSellingPoints(preset.sellingPoints);
                            setTargetAudience(preset.targetAudience);
                            setProjectCategory(preset.category);
                          }}
                          className="rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-600 hover:border-indigo-300 hover:text-indigo-600 cursor-pointer"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      成片画幅比例
                    </label>
                    <select
                      value={aspectRatio}
                      onChange={(e) =>
                        setAspectRatio(e.target.value as '9:16' | '16:9' | '4:3')
                      }
                      className="h-8 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs text-slate-800"
                    >
                      <option value="9:16">9:16 竖屏短视频</option>
                      <option value="16:9">16:9 横屏宣传片</option>
                      <option value="4:3">4:3 种草图文</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">
                      AI 锐化辅助
                    </label>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={assistBusyType !== null}
                        onClick={() => handleAISmartAssist('hook_boost')}
                        className="rounded border border-slate-200 bg-white px-2.5 py-1 text-xs text-slate-700 hover:border-indigo-400 hover:text-indigo-600 cursor-pointer"
                      >
                        强化前3秒
                      </button>
                      <button
                        type="button"
                        disabled={assistBusyType !== null}
                        onClick={() => handleAISmartAssist('punchy_copy')}
                        className="rounded border border-slate-200 bg-white px-2.5 py-1 text-xs text-slate-700 hover:border-indigo-400 hover:text-indigo-600 cursor-pointer"
                      >
                        口播提纯
                      </button>
                      <button
                        type="button"
                        disabled={assistBusyType !== null}
                        onClick={() => handleAISmartAssist('visual_upgrade')}
                        className="rounded border border-slate-200 bg-white px-2.5 py-1 text-xs text-slate-700 hover:border-indigo-400 hover:text-indigo-600 cursor-pointer"
                      >
                        画面升级
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* Main Script Detail Card (1:1 Match with Screenshot 6 `< 脚本详情` & Screenshot 4 `公司宣传片拍摄脚本`) */}
            <section className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-2xs">
              {/* Top Action Header Bar matching Screenshot 6 */}
              <div className="flex flex-col justify-between gap-4 border-b border-slate-100 pb-4 lg:flex-row lg:items-center">
                <button
                  type="button"
                  onClick={() => setActiveNav('templates')}
                  className="flex items-center gap-1.5 text-sm font-bold text-slate-800 hover:text-indigo-600 cursor-pointer w-fit"
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span>脚本详情</span>
                </button>

                {/* Right Buttons matching Screenshot 6: [素材收集] [文本视图 | 表格视图 | 9列拍摄表] [更多/导出] [视频混剪] [编辑/保存] */}
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setMerchantSubTab('materials');
                      setActiveNav('store_kb');
                    }}
                    className="rounded-lg border border-pink-400 bg-white px-3.5 py-1.5 text-xs font-semibold text-pink-600 hover:bg-pink-50 transition-colors cursor-pointer"
                  >
                    素材收集
                  </button>

                  {/* View Switcher Segmented Control */}
                  <div className="flex items-center rounded-lg bg-slate-100 p-0.5 text-xs">
                    <button
                      type="button"
                      onClick={() => setScriptViewMode('text')}
                      className={`rounded-md px-3 py-1.5 font-medium transition-all cursor-pointer ${
                        scriptViewMode === 'text'
                          ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      文本视图
                    </button>
                    <button
                      type="button"
                      onClick={() => setScriptViewMode('table')}
                      className={`rounded-md px-3 py-1.5 font-medium transition-all cursor-pointer ${
                        scriptViewMode === 'table'
                          ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      表格视图
                    </button>
                    <button
                      type="button"
                      onClick={() => setScriptViewMode('pro9')}
                      className={`rounded-md px-3 py-1.5 font-medium transition-all cursor-pointer ${
                        scriptViewMode === 'pro9'
                          ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      拍摄脚本(9列)
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setExportModalProject(currentEditorExportData)}
                    className="rounded-lg border border-indigo-500 bg-white px-3.5 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 transition-colors cursor-pointer"
                  >
                    导出
                  </button>

                  <button
                    type="button"
                    onClick={() => setShareModalProject(currentEditorExportData)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:border-indigo-300 hover:text-indigo-600 transition-colors cursor-pointer"
                  >
                    共享
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setRemixStudioMode('foolproof');
                      setActiveNav('video_remix');
                    }}
                    className="rounded-lg bg-[#4F46E5] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#4338CA] transition-colors cursor-pointer"
                  >
                    ⚡ 傻瓜混剪
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setRemixStudioMode('pro_nle');
                      setActiveNav('video_remix');
                    }}
                    className="rounded-lg border border-sky-300 bg-sky-50 px-3.5 py-1.5 text-xs font-semibold text-sky-800 hover:bg-sky-100 transition-colors cursor-pointer"
                  >
                    🎛️ 专业微操混剪
                  </button>

                  <button
                    type="button"
                    disabled={isSavingCloud}
                    onClick={handleSaveProjectToCloud}
                    className="rounded-lg bg-[#4338CA] px-4 py-1.5 text-xs font-semibold text-white hover:bg-indigo-800 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {isSavingCloud ? '保存中...' : '保存'}
                  </button>
                </div>
              </div>

              {/* Script Title Row & Table Resize Controls */}
              <div className="mt-5 flex flex-wrap items-center justify-between gap-2">
                <input
                  type="text"
                  value={projectTitle}
                  onChange={(e) => setProjectTitle(e.target.value)}
                  className="w-full sm:w-auto flex-1 min-w-[220px] max-w-2xl rounded-lg border border-transparent px-1 py-1 text-base font-bold text-slate-900 hover:border-slate-200 focus:border-indigo-500 focus:bg-white focus:outline-none"
                />
                <div className="flex flex-wrap items-center gap-2.5 text-xs text-slate-500 shrink-0">
                  <span className="rounded-md bg-sky-50 border border-sky-200/80 px-2 py-0.5 text-[11px] font-medium text-sky-800">
                    ↔ 按住表头「可拖宽」调列宽 · ↕ 按住行底调行高
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setEditorColWidths([280, 360, 380, 185]);
                      setEditorRowHeights({});
                      showNotice('success', '已重置表格全部列宽与行高！');
                    }}
                    className="rounded-md border border-slate-200 bg-white px-2.5 py-0.5 text-[11px] font-medium text-slate-600 hover:border-indigo-300 hover:text-indigo-600 whitespace-nowrap cursor-pointer"
                  >
                    重置宽高
                  </button>
                  <span>·</span>
                  <span>共 {cameraAngles.length} 镜</span>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => handleInsertShotAfter(cameraAngles.length - 1)}
                    className="font-semibold text-indigo-600 hover:underline whitespace-nowrap cursor-pointer"
                  >
                    + 新增镜头
                  </button>
                </div>
              </div>

              {/* Storyboard Table View (Fixed Pixel Widths + Colgroup so Column & Row Drag Resizing Works 100%) */}
              {scriptViewMode === 'table' ? (
                <div className="relative">
                  <div className="mt-5 overflow-x-auto rounded-xl border border-sky-200/90 bg-white/90 scroll-smooth relative">
                    <table
                      className="table-fixed border-collapse text-left"
                      style={{
                        width: `${editorColWidths.reduce((acc, w) => acc + w, 0)}px`,
                        minWidth: '100%',
                      }}
                    >
                      <colgroup>
                        <col style={{ width: `${editorColWidths[0]}px` }} />
                        <col style={{ width: `${editorColWidths[1]}px` }} />
                        <col style={{ width: `${editorColWidths[2]}px` }} />
                        <col style={{ width: `${editorColWidths[3]}px` }} />
                      </colgroup>
                      <thead>
                        <tr className="border-b border-sky-200/90 bg-[#E6F1FB] text-xs font-bold text-slate-700 select-none">
                          {/* Column 0 Header */}
                          <th
                            style={{ width: `${editorColWidths[0]}px` }}
                            className="sticky left-0 z-20 relative bg-[#E6F1FB] py-3.5 px-4 shadow-[1px_0_0_0_#cbd5e1]"
                          >
                            <div className="flex items-center justify-between gap-1 whitespace-nowrap">
                              <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={
                                    cameraAngles.length > 0 &&
                                    selectedShotIndices.length === cameraAngles.length
                                  }
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setSelectedShotIndices(
                                        cameraAngles.map((_, i) => i)
                                      );
                                    } else {
                                      setSelectedShotIndices([]);
                                    }
                                  }}
                                  className="h-3.5 w-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                />
                                <span>镜头分组</span>
                              </label>
                              <span
                                onMouseDown={(e) => startResizeEditorCol(0, e)}
                                title="按住鼠标左右拖动调整列宽"
                                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold cursor-col-resize transition-colors ${
                                  resizingColIdx === 0
                                    ? 'bg-sky-600 text-white'
                                    : 'bg-white/80 text-sky-800 hover:bg-sky-200/70'
                                }`}
                              >
                                ↔ 调宽 ({editorColWidths[0]}px)
                              </span>
                            </div>
                            {/* Wide 12px Column 0 Right Resize Handle */}
                            <div
                              onMouseDown={(e) => startResizeEditorCol(0, e)}
                              title="按住左右拖拽调整「镜头分组」列宽"
                              className={`absolute right-0 top-0 bottom-0 w-3 cursor-col-resize transition-colors ${
                                resizingColIdx === 0
                                  ? 'bg-sky-500/60'
                                  : 'hover:bg-sky-400/45'
                              }`}
                            />
                          </th>

                          {/* Column 1 Header */}
                          <th
                            style={{ width: `${editorColWidths[1]}px` }}
                            className="relative py-3.5 px-5 border-r border-dashed border-sky-200/90"
                          >
                            <div className="flex items-center justify-between whitespace-nowrap">
                              <span>画面描述</span>
                              <span
                                onMouseDown={(e) => startResizeEditorCol(1, e)}
                                title="按住鼠标左右拖动调整「画面描述」列宽"
                                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold cursor-col-resize transition-colors ${
                                  resizingColIdx === 1
                                    ? 'bg-sky-600 text-white'
                                    : 'bg-white/80 text-sky-800 hover:bg-sky-200/70'
                                }`}
                              >
                                ↔ 可拖宽 ({editorColWidths[1]}px)
                              </span>
                            </div>
                            <div
                              onMouseDown={(e) => startResizeEditorCol(1, e)}
                              title="按住左右拖拽调整「画面描述」列宽"
                              className={`absolute right-0 top-0 bottom-0 w-3 cursor-col-resize transition-colors ${
                                resizingColIdx === 1
                                  ? 'bg-sky-500/60'
                                  : 'hover:bg-sky-400/45'
                              }`}
                            />
                          </th>

                          {/* Column 2 Header */}
                          <th
                            style={{ width: `${editorColWidths[2]}px` }}
                            className="relative py-3.5 px-5 border-r border-dashed border-sky-200/90"
                          >
                            <div className="flex items-center justify-between whitespace-nowrap">
                              <span>台词口播</span>
                              <span
                                onMouseDown={(e) => startResizeEditorCol(2, e)}
                                title="按住鼠标左右拖动调整「台词口播」列宽"
                                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold cursor-col-resize transition-colors ${
                                  resizingColIdx === 2
                                    ? 'bg-sky-600 text-white'
                                    : 'bg-white/80 text-sky-800 hover:bg-sky-200/70'
                                }`}
                              >
                                ↔ 可拖宽 ({editorColWidths[2]}px)
                              </span>
                            </div>
                            <div
                              onMouseDown={(e) => startResizeEditorCol(2, e)}
                              title="按住左右拖拽调整「台词口播」列宽"
                              className={`absolute right-0 top-0 bottom-0 w-3 cursor-col-resize transition-colors ${
                                resizingColIdx === 2
                                  ? 'bg-sky-500/60'
                                  : 'hover:bg-sky-400/45'
                              }`}
                            />
                          </th>

                          {/* Column 3 Header */}
                          <th
                            style={{ width: `${editorColWidths[3]}px` }}
                            className="relative py-3.5 px-4"
                          >
                            <div className="flex items-center justify-between whitespace-nowrap">
                              <span>素材与智能辅助</span>
                              <span
                                onMouseDown={(e) => startResizeEditorCol(3, e)}
                                title="按住鼠标左右拖动调整列宽"
                                className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold cursor-col-resize transition-colors ${
                                  resizingColIdx === 3
                                    ? 'bg-sky-600 text-white'
                                    : 'bg-white/80 text-sky-800 hover:bg-sky-200/70'
                                }`}
                              >
                                ↔ {editorColWidths[3]}px
                              </span>
                            </div>
                            <div
                              onMouseDown={(e) => startResizeEditorCol(3, e)}
                              title="按住左右拖拽调整列宽"
                              className={`absolute right-0 top-0 bottom-0 w-3 cursor-col-resize transition-colors ${
                                resizingColIdx === 3
                                  ? 'bg-sky-500/60'
                                  : 'hover:bg-sky-400/45'
                              }`}
                            />
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200/80 text-xs bg-white/90">
                        {cameraAngles.length === 0 ? (
                          <tr className="py-4 even:bg-slate-50">
                            <td colSpan={4} className="py-14 px-6 text-center bg-slate-50/40">
                              <div className="mx-auto flex max-w-md flex-col items-center justify-center space-y-3">
                                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 shadow-2xs">
                                  <Film className="h-5 w-5" />
                                </div>
                                <div>
                                  <p className="text-sm font-bold text-slate-800">
                                    当前脚本暂无分镜镜头
                                  </p>
                                  <p className="mt-1 text-xs text-slate-500">
                                    点击下方按钮添加您的第一个分镜，或使用 AI 一键生成全套高转化分镜脚本。
                                  </p>
                                </div>
                                <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                                  <button
                                    type="button"
                                    onClick={() => handleInsertShotAfter(-1)}
                                    className="flex items-center gap-1.5 rounded-xl bg-[#4F46E5] px-4 py-2 text-xs font-semibold text-white hover:bg-[#4338CA] shadow-xs transition-all cursor-pointer"
                                  >
                                    <Plus className="h-3.5 w-3.5" />
                                    <span>添加第一个镜头</span>
                                  </button>
                                  <button
                                    type="button"
                                    disabled={isGeneratingScript}
                                    onClick={() => handleAIGenerateScript()}
                                    className="flex items-center gap-1.5 rounded-xl border border-indigo-200 bg-indigo-50/70 px-4 py-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition-all cursor-pointer"
                                  >
                                    <Sparkles className="h-3.5 w-3.5" />
                                    <span>AI 一键生成 4 镜脚本</span>
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          cameraAngles.map((angle, idx) => {
                            const isDragging = draggedShotIdx === idx;
                            const isDragOver =
                              dragOverShotIdx === idx && draggedShotIdx !== idx;
                            const isSelected = selectedShotIndices.includes(idx);
                            const rowHeight = editorRowHeights[idx] || 142;
                            return (
                              <tr
                                key={idx}
                                draggable={dragArmedRowIdx === idx}
                                style={{ height: `${rowHeight}px` }}
                                onDragStart={(e) => {
                                  if (dragArmedRowIdx !== idx) {
                                    e.preventDefault();
                                    return;
                                  }
                                  setDraggedShotIdx(idx);
                                  e.dataTransfer.effectAllowed = 'move';
                                  e.dataTransfer.setData('text/plain', String(idx));
                                }}
                                onDragOver={(e) => {
                                  e.preventDefault();
                                  e.dataTransfer.dropEffect = 'move';
                                  if (dragOverShotIdx !== idx) {
                                    setDragOverShotIdx(idx);
                                  }
                                }}
                                onDragEnter={(e) => {
                                  e.preventDefault();
                                  setDragOverShotIdx(idx);
                                }}
                                onDragLeave={() => {
                                  if (dragOverShotIdx === idx) {
                                    setDragOverShotIdx(null);
                                  }
                                }}
                                onDrop={(e) => {
                                  e.preventDefault();
                                  const fromIdx =
                                    draggedShotIdx !== null
                                      ? draggedShotIdx
                                      : Number(e.dataTransfer.getData('text/plain'));
                                  if (!Number.isNaN(fromIdx)) {
                                    handleReorderShots(fromIdx, idx);
                                  }
                                  setDraggedShotIdx(null);
                                  setDragOverShotIdx(null);
                                  setDragArmedRowIdx(null);
                                }}
                                onDragEnd={() => {
                                  setDraggedShotIdx(null);
                                  setDragOverShotIdx(null);
                                  setDragArmedRowIdx(null);
                                }}
                                className={`group/row py-4 even:bg-slate-50 transition-all ${
                                  isDragging
                                    ? 'opacity-45 bg-sky-50/50'
                                    : isDragOver
                                    ? 'bg-sky-50/90 ring-2 ring-inset ring-sky-500'
                                    : isSelected
                                    ? 'bg-sky-50/40 hover:bg-sky-50/60'
                                    : 'hover:bg-sky-50/30'
                                }`}
                              >
                                {/* Sticky Left Column: 镜头分组 + 勾选框 + 专属拖拽手柄 + 悬停快捷操作菜单 */}
                                <td className="sticky left-0 z-10 relative align-top bg-inherit py-4 px-3.5 transition-colors shadow-[1px_0_0_0_#e2e8f0]">
                                  <div className="flex items-center gap-1.5">
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={(e) => {
                                        if (e.target.checked) {
                                          setSelectedShotIndices((prev) =>
                                            prev.includes(idx) ? prev : [...prev, idx]
                                          );
                                        } else {
                                          setSelectedShotIndices((prev) =>
                                            prev.filter((i) => i !== idx)
                                          );
                                        }
                                      }}
                                      className="h-3.5 w-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer shrink-0"
                                      title="勾选此镜头进行批量操作"
                                    />
                                    <span
                                      onMouseEnter={() => setDragArmedRowIdx(idx)}
                                      onMouseLeave={() => {
                                        if (draggedShotIdx === null) setDragArmedRowIdx(null);
                                      }}
                                      onMouseDown={() => setDragArmedRowIdx(idx)}
                                      title="按住此手柄上下拖拽调整镜头顺序"
                                      className="cursor-grab active:cursor-grabbing rounded p-0.5 text-slate-400 hover:bg-sky-100 hover:text-sky-700 shrink-0"
                                    >
                                      <GripVertical className="h-4 w-4" />
                                    </span>
                                    <span className="font-mono text-sm font-bold text-indigo-600 shrink-0">
                                      0{idx + 1}
                                    </span>
                                    <input
                                      type="text"
                                      value={angle.replace(/^0?\d+\s*/, '')}
                                      onChange={(e) => {
                                        const next = [...cameraAngles];
                                        next[idx] = `0${idx + 1} ${e.target.value}`;
                                        setCameraAngles(next);
                                      }}
                                      className="w-full min-w-0 rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-slate-800 hover:border-slate-200 focus:border-indigo-500 focus:bg-white focus:outline-none"
                                    />
                                  </div>

                                  {/* Synced shotDurations & shotMovements badges */}
                                  <div className="mt-2 flex items-center gap-1.5 pl-6">
                                    <select
                                      value={shotMovements[idx] || '特写推镜'}
                                      onChange={(e) => {
                                        const next = [...shotMovements];
                                        next[idx] = e.target.value;
                                        setShotMovements(next);
                                      }}
                                      className="rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[11px] font-medium text-slate-700 focus:border-indigo-500 focus:outline-none"
                                    >
                                      <option value="特写推镜">特写推镜</option>
                                      <option value="产品近景">产品近景</option>
                                      <option value="前后对比">前后对比</option>
                                      <option value="固定促单">固定促单</option>
                                      <option value="远景航拍">远景航拍</option>
                                    </select>

                                    <div className="flex items-center rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[11px] font-mono text-slate-700">
                                      <input
                                        type="number"
                                        step="0.5"
                                        min="1"
                                        max="30"
                                        value={shotDurations[idx] ?? 4.0}
                                        onChange={(e) => {
                                          const next = [...shotDurations];
                                          next[idx] = Math.max(
                                            1,
                                            parseFloat(e.target.value) || 4.0
                                          );
                                          setShotDurations(next);
                                        }}
                                        className="w-8 bg-transparent text-right focus:outline-none"
                                      />
                                      <span className="ml-0.5 text-slate-400">s</span>
                                    </div>
                                  </div>

                                  {/* Hover-Activated Action Menu on each row in tbody ('Quick Duplicate' & 'Move to Top/Bottom') */}
                                  <div className="mt-2.5 pl-6 opacity-85 group-hover/row:opacity-100 focus-within:opacity-100 transition-opacity">
                                    <div className="inline-flex items-center whitespace-nowrap rounded-lg border border-sky-200/90 bg-white shadow-2xs divide-x divide-slate-100 text-[11px]">
                                      <button
                                        type="button"
                                        onClick={() => handleDuplicateShot(idx)}
                                        title="Quick Duplicate (快速复制当前镜头)"
                                        className="px-2 py-1 font-semibold text-indigo-600 hover:bg-sky-50 rounded-l-lg transition-colors cursor-pointer"
                                      >
                                        复制
                                      </button>
                                      <button
                                        type="button"
                                        disabled={idx === 0}
                                        onClick={() => handleMoveShotToEdge(idx, 'top')}
                                        title="Move to Top (一键置顶该镜头)"
                                        className="px-2 py-1 text-slate-600 hover:bg-sky-50 hover:text-indigo-600 disabled:opacity-35 transition-colors cursor-pointer"
                                      >
                                        置顶
                                      </button>
                                      <button
                                        type="button"
                                        disabled={idx === cameraAngles.length - 1}
                                        onClick={() => handleMoveShotToEdge(idx, 'bottom')}
                                        title="Move to Bottom (一键置底该镜头)"
                                        className="px-2 py-1 text-slate-600 hover:bg-sky-50 hover:text-indigo-600 disabled:opacity-35 transition-colors cursor-pointer"
                                      >
                                        置底
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleInsertShotAfter(idx)}
                                        title="在下方插入新镜头"
                                        className="px-2 py-1 text-slate-600 hover:bg-sky-50 hover:text-indigo-600 transition-colors cursor-pointer"
                                      >
                                        插入
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteShot(idx)}
                                        title="删除当前镜头"
                                        className="px-2 py-1 text-slate-500 hover:bg-red-50 hover:text-red-600 rounded-r-lg transition-colors cursor-pointer"
                                      >
                                        删除
                                      </button>
                                    </div>
                                  </div>

                                  {/* Row Bottom Resize Handle */}
                                  <div
                                    onMouseDown={(e) => startResizeEditorRow(idx, e)}
                                    title="按住上下拖拽调整当前镜头行高度"
                                    className={`absolute inset-x-0 bottom-0 h-2.5 cursor-row-resize transition-colors ${
                                      resizingRowIdx === idx
                                        ? 'bg-sky-500/60'
                                        : 'hover:bg-sky-400/45'
                                    }`}
                                  />
                                </td>

                                {/* Column 2: 画面描述 (Resizable Row & Textarea) */}
                                <td className="relative align-top py-4 px-4 border-r border-dashed border-slate-200/80">
                                  <textarea
                                    style={{ height: `${Math.max(82, rowHeight - 36)}px` }}
                                    value={visualCues[idx] || ''}
                                    onChange={(e) => {
                                      const next = [...visualCues];
                                      next[idx] = e.target.value;
                                      setVisualCues(next);
                                    }}
                                    placeholder="输入该镜头的画面场景与动作描述..."
                                    className="w-full resize-none rounded-lg border border-slate-200/80 bg-white/95 p-2.5 text-xs leading-relaxed text-slate-700 hover:border-sky-300 focus:border-indigo-500 focus:bg-white focus:outline-none transition-colors"
                                  />
                                  <div
                                    onMouseDown={(e) => startResizeEditorRow(idx, e)}
                                    title="按住上下拖拽调整当前行高度"
                                    className={`absolute inset-x-0 bottom-0 h-2.5 cursor-row-resize flex items-center justify-center transition-colors ${
                                      resizingRowIdx === idx
                                        ? 'bg-sky-500/60'
                                        : 'hover:bg-sky-400/45'
                                    }`}
                                  />
                                </td>

                                {/* Column 3: 台词口播 (Resizable Row & Textarea) */}
                                <td className="relative align-top py-4 px-4 border-r border-dashed border-slate-200/80">
                                  <textarea
                                    style={{ height: `${Math.max(82, rowHeight - 36)}px` }}
                                    value={sceneLines[idx] || ''}
                                    onChange={(e) => {
                                      const next = [...sceneLines];
                                      next[idx] = e.target.value;
                                      setSceneLines(next);
                                    }}
                                    placeholder="输入该镜头的台词或旁白口播..."
                                    className="w-full resize-none rounded-lg border border-slate-200/80 bg-white/95 p-2.5 text-xs leading-relaxed text-slate-800 hover:border-sky-300 focus:border-indigo-500 focus:bg-white focus:outline-none transition-colors"
                                  />
                                  <div
                                    onMouseDown={(e) => startResizeEditorRow(idx, e)}
                                    title="按住上下拖拽调整当前行高度"
                                    className={`absolute inset-x-0 bottom-0 h-2.5 cursor-row-resize transition-colors ${
                                      resizingRowIdx === idx
                                        ? 'bg-sky-500/60'
                                        : 'hover:bg-sky-400/45'
                                    }`}
                                  />
                                </td>

                                {/* Column 4: 素材与智能辅助 */}
                                <td className="relative align-top py-4 px-4">
                                  <div className="flex flex-col gap-2">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setRemixStudioMode('pro_nle');
                                        setActiveNav('video_remix');
                                      }}
                                      className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50/70 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 whitespace-nowrap hover:bg-indigo-100 transition-all cursor-pointer"
                                    >
                                      <Play className="h-3 w-3 shrink-0 fill-indigo-600 text-indigo-600" />
                                      <span>混剪微操</span>
                                    </button>

                                    <button
                                      type="button"
                                      disabled={assistBusyType !== null}
                                      onClick={() =>
                                        handleAISmartAssist('single_shot_rewrite', idx)
                                      }
                                      className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 whitespace-nowrap hover:border-indigo-400 hover:text-indigo-600 disabled:opacity-50 transition-all cursor-pointer"
                                    >
                                      <RefreshCw
                                        className={`h-3 w-3 shrink-0 ${
                                          assistBusyType === `single_shot_rewrite_${idx}`
                                            ? 'animate-spin text-indigo-600'
                                            : 'text-slate-400'
                                        }`}
                                      />
                                      <span>
                                        {assistBusyType === `single_shot_rewrite_${idx}`
                                          ? '重写中...'
                                          : 'AI 换此镜'}
                                      </span>
                                    </button>

                                    <button
                                      type="button"
                                      onMouseDown={(e) => startResizeEditorRow(idx, e)}
                                      title="按住鼠标上下拖动调整本行高度"
                                      className="mt-0.5 flex w-full items-center justify-center gap-1 rounded border border-dashed border-sky-200 bg-sky-50/50 py-1 text-[10px] font-medium text-sky-700 cursor-row-resize hover:bg-sky-100/70"
                                    >
                                      <span>↕ 按住拖高 ({rowHeight}px)</span>
                                    </button>
                                  </div>
                                  <div
                                    onMouseDown={(e) => startResizeEditorRow(idx, e)}
                                    title="按住上下拖拽调整当前行高度"
                                    className={`absolute inset-x-0 bottom-0 h-2.5 cursor-row-resize transition-colors ${
                                      resizingRowIdx === idx
                                        ? 'bg-sky-500/60'
                                        : 'hover:bg-sky-400/45'
                                    }`}
                                  />
                                </td>
                              </tr>
                            );
                          })
                        )}

                        {/* Persistent Bulk Actions Row at the Bottom of tbody */}
                        <tr className="py-4 even:bg-slate-50 bg-slate-50/95 border-t border-slate-200 text-xs">
                          <td colSpan={4} className="py-3.5 px-4">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <div className="flex flex-wrap items-center gap-3">
                                <label className="flex items-center gap-1.5 font-semibold text-slate-700 whitespace-nowrap cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={
                                      cameraAngles.length > 0 &&
                                      selectedShotIndices.length === cameraAngles.length
                                    }
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedShotIndices(
                                          cameraAngles.map((_, i) => i)
                                        );
                                      } else {
                                        setSelectedShotIndices([]);
                                      }
                                    }}
                                    className="h-3.5 w-3.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                  />
                                  <span>
                                    批量操作 (已选 {selectedShotIndices.length}/{cameraAngles.length} 镜)
                                  </span>
                                </label>
                                <button
                                  type="button"
                                  onClick={() => handleInsertShotAfter(cameraAngles.length - 1)}
                                  className="inline-flex items-center gap-1 rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 whitespace-nowrap cursor-pointer"
                                >
                                  <Plus className="h-3.5 w-3.5" />
                                  <span>新增镜头行</span>
                                </button>
                              </div>

                              <div className="flex flex-wrap items-center gap-2">
                                <button
                                  type="button"
                                  disabled={selectedShotIndices.length === 0}
                                  onClick={handleBulkDeleteShots}
                                  className="inline-flex items-center gap-1 rounded-lg border border-red-200 bg-white px-2.5 py-1 text-xs font-medium text-red-600 hover:bg-red-50 disabled:opacity-40 whitespace-nowrap cursor-pointer"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  <span>删除选中</span>
                                </button>
                                <button
                                  type="button"
                                  disabled={cameraAngles.length === 0}
                                  onClick={handleClearAllShots}
                                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 disabled:opacity-40 whitespace-nowrap cursor-pointer"
                                >
                                  <span>清空全部镜头</span>
                                </button>
                                <button
                                  type="button"
                                  disabled={cameraAngles.length === 0}
                                  onClick={handleBulkExportShotsCsv}
                                  className="inline-flex items-center gap-1 rounded-lg bg-[#4F46E5] px-3 py-1 text-xs font-semibold text-white hover:bg-[#4338CA] disabled:opacity-40 whitespace-nowrap cursor-pointer"
                                >
                                  <Download className="h-3.5 w-3.5" />
                                  <span>
                                    批量导出选中 ({selectedShotIndices.length || cameraAngles.length} 镜)
                                  </span>
                                </button>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Visual gradient fade overlay on the right side of the .mt-5.overflow-x-auto container */}
                    <div
                      aria-hidden="true"
                      className="pointer-events-none sticky right-0 top-0 bottom-0 float-right -ml-8 w-8 h-full bg-gradient-to-l from-white/90 via-white/40 to-transparent"
                    />
                  </div>

                  {/* Outer right-edge gradient fade overlay + subtle scroll indicator */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-y-0 right-0 w-10 rounded-r-xl bg-gradient-to-l from-white/90 via-white/40 to-transparent"
                  />
                </div>
              ) : scriptViewMode === 'pro9' ? (
                /* 9-Column Corporate / Commercial Shooting Script Table */
                <div className="mt-5 overflow-hidden rounded-xl border border-[#9BB2D6] bg-white">
                  <div className="bg-[#2B548E] py-3 px-6 text-center text-lg font-bold tracking-widest text-white">
                    {projectTitle || '公司宣传片拍摄脚本'}
                  </div>

                  <div className="border-b border-[#9BB2D6] bg-[#F8FAFC] px-5 py-3 text-xs text-[#1E3A68] space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold shrink-0">宣传片主题：</span>
                      <input
                        type="text"
                        value={productName}
                        onChange={(e) => setProductName(e.target.value)}
                        className="flex-1 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-[#2B548E] focus:outline-none py-0.5 text-xs text-[#1E3A68]"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold shrink-0">脚本说明：</span>
                      <input
                        type="text"
                        value={sellingPoints}
                        onChange={(e) => setSellingPoints(e.target.value)}
                        className="flex-1 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-[#2B548E] focus:outline-none py-0.5 text-xs text-[#1E3A68]"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto scroll-smooth">
                    <table className="min-w-[1050px] w-full border-collapse text-xs text-[#1E3A68]">
                      <thead>
                        <tr className="bg-[#DCE6F4] font-bold text-[#1E3A68]">
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-14 text-center">镜号</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-24 text-center">类别</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-64 text-center">场景／画面内容</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-20 text-center">景别</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-52 text-center">字幕</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-52 text-center">旁白解说</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-36 text-center">音乐／音效</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-16 text-center">时长</th>
                          <th className="border border-[#9BB2D6] py-2.5 px-3 w-28 text-center">备注</th>
                        </tr>
                      </thead>
                      <tbody>
                        {cameraAngles.length === 0 ? (
                          <tr className="py-4 even:bg-slate-50">
                            <td colSpan={9} className="border border-[#9BB2D6] py-12 px-6 text-center bg-slate-50/50">
                              <div className="mx-auto flex max-w-md flex-col items-center justify-center space-y-2.5">
                                <p className="text-sm font-bold text-[#1E3A68]">
                                  当前拍摄脚本暂无镜头行
                                </p>
                                <p className="text-xs text-slate-500">
                                  点击下方按钮添加您的第一个拍摄镜头，或使用 AI 自动生成完整分镜表。
                                </p>
                                <div className="flex items-center justify-center gap-2 pt-1">
                                  <button
                                    type="button"
                                    onClick={() => handleInsertShotAfter(-1)}
                                    className="rounded-lg bg-[#2B548E] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#1E3A68] cursor-pointer"
                                  >
                                    + 添加第一个镜头
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleAIGenerateScript()}
                                    className="rounded-lg border border-[#9BB2D6] bg-white px-3.5 py-1.5 text-xs font-semibold text-[#1E3A68] hover:bg-slate-50 cursor-pointer"
                                  >
                                    AI 一键生成脚本
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          cameraAngles.map((angle, idx) => (
                            <tr
                              key={idx}
                              draggable
                              onDragStart={(e) => {
                                setDraggedShotIdx(idx);
                                e.dataTransfer.effectAllowed = 'move';
                                e.dataTransfer.setData('text/plain', String(idx));
                              }}
                              onDragOver={(e) => {
                                e.preventDefault();
                                setDragOverShotIdx(idx);
                              }}
                              onDrop={(e) => {
                                e.preventDefault();
                                const fromIdx =
                                  draggedShotIdx !== null
                                    ? draggedShotIdx
                                    : Number(e.dataTransfer.getData('text/plain'));
                                if (!Number.isNaN(fromIdx)) {
                                  handleReorderShots(fromIdx, idx);
                                }
                                setDraggedShotIdx(null);
                                setDragOverShotIdx(null);
                              }}
                              onDragEnd={() => {
                                setDraggedShotIdx(null);
                                setDragOverShotIdx(null);
                              }}
                              className={`py-4 even:bg-slate-50 hover:bg-[#F2F6FC] transition-colors ${
                                dragOverShotIdx === idx && draggedShotIdx !== idx
                                  ? 'bg-indigo-50 ring-2 ring-inset ring-indigo-500'
                                  : ''
                              }`}
                            >
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center font-semibold cursor-grab active:cursor-grabbing">
                                <div className="flex items-center justify-center gap-1">
                                  <GripVertical className="h-3.5 w-3.5 text-slate-400" />
                                  <span>{idx + 1}</span>
                                </div>
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center">
                                <input
                                  type="text"
                                  value={angle.replace(/^0?\d+\s*/, '')}
                                  onChange={(e) => {
                                    const next = [...cameraAngles];
                                    next[idx] = `0${idx + 1} ${e.target.value}`;
                                    setCameraAngles(next);
                                  }}
                                  className="w-full text-center bg-transparent focus:outline-none"
                                />
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-3">
                                <textarea
                                  rows={2}
                                  value={visualCues[idx] || ''}
                                  onChange={(e) => {
                                    const next = [...visualCues];
                                    next[idx] = e.target.value;
                                    setVisualCues(next);
                                  }}
                                  className="w-full resize-y bg-transparent leading-relaxed focus:outline-none"
                                />
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center">
                                <select
                                  value={shotMovements[idx] || '特写推镜'}
                                  onChange={(e) => {
                                    const next = [...shotMovements];
                                    next[idx] = e.target.value;
                                    setShotMovements(next);
                                  }}
                                  className="bg-transparent text-center focus:outline-none"
                                >
                                  <option value="特写推镜">特写推镜</option>
                                  <option value="产品近景">产品近景</option>
                                  <option value="前后对比">前后对比</option>
                                  <option value="固定促单">固定促单</option>
                                  <option value="远景航拍">远景航拍</option>
                                </select>
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-3">
                                <textarea
                                  rows={2}
                                  value={sceneLines[idx] || ''}
                                  onChange={(e) => {
                                    const next = [...sceneLines];
                                    next[idx] = e.target.value;
                                    setSceneLines(next);
                                  }}
                                  className="w-full resize-y bg-transparent leading-relaxed focus:outline-none"
                                />
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-3">
                                {sceneLines[idx] || '-'}
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center">
                                {idx === 0 ? '时空穿梭音效' : bgmStyle}
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center font-mono">
                                {shotDurations[idx] ?? 4}s
                              </td>
                              <td className="border border-[#9BB2D6] py-3.5 px-2 text-center">
                                <button
                                  type="button"
                                  onClick={() => setIsMixPlayerOpen(true)}
                                  className="text-indigo-600 hover:underline cursor-pointer"
                                >
                                  预览
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="mt-5 space-y-3 rounded-xl border border-slate-200 bg-slate-50/70 p-5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-600">
                      纯享提词器 / 文本视图
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const fullText = cameraAngles
                          .map(
                            (angle, i) =>
                              `【${angle}】\n画面：${visualCues[i]}\n口播：${sceneLines[i]}`
                          )
                          .join('\n\n');
                        navigator.clipboard.writeText(fullText);
                        showNotice('success', '全篇脚本已复制到剪贴板！');
                      }}
                      className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      <span>一键复制全文</span>
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {cameraAngles.map((angle, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl border border-slate-200/80 bg-white p-4"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-600">{angle}</span>
                          <span className="font-mono text-xs text-slate-400">
                            {shotDurations[idx] || 4.0}s
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-slate-500">
                          画面描述：{visualCues[idx]}
                        </p>
                        <p className="mt-1.5 text-sm font-semibold text-slate-900">
                          台词口播：“{sceneLines[idx]}”
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>
          </main>
        )}

        {/* VIEW 4: 全链路爆款视频/图文拆解与同款裂变引擎 (全宽自适应) */}
        {activeNav === 'dissect' && (
          <main className="w-full flex-1 p-4 sm:p-6 lg:p-8">
            <ViralDissectionWorkspace
              skills={DISSECT_SKILL_PACKAGES}
              selectedSkillIds={selectedSkillIds}
              onToggleSkillId={(id) => {
                setSelectedSkillIds((prev) =>
                  prev.includes(id)
                    ? prev.length > 1
                      ? prev.filter((item) => item !== id)
                      : prev
                    : [...prev, id]
                );
              }}
              samples={QUICK_DISSECT_SAMPLES}
              dissectTitle={dissectTitle}
              setDissectTitle={setDissectTitle}
              dissectCategory={dissectCategory}
              setDissectCategory={setDissectCategory}
              dissectContent={dissectContent}
              setDissectContent={setDissectContent}
              isDissecting={isDissecting}
              onRunDissection={() => handleRunDissection()}
              dissectResult={dissectResult}
              storeMemoryEnabled={storeMemoryEnabled}
              activeStore={activeStoreProfile}
              productName={productName}
              setProductName={setProductName}
              sellingPoints={sellingPoints}
              setSellingPoints={setSellingPoints}
              isGeneratingScript={isGeneratingScript}
              onSaveDissectionToCloud={handleSaveDissectionToCloud}
              onEncapsulateAsTemplate={handleEncapsulateAsTemplate}
              onApplyDissectedStructureToEditor={() => {
                setProjectTitle(`${productName.slice(0, 14) || '爆款复刻'} · 同款脚本`);
                setPacingTip(`套用爆款拆解公式：${dissectResult.extractedFormula}`);
                setCameraAngles([...dissectResult.cameraAngles]);
                setVisualCues([...dissectResult.visualCues]);
                setSceneLines([...dissectResult.sceneLines]);
                setActiveNav('editor');
                showNotice('success', '已将拉片还原的分镜结构载入分镜精修台！');
              }}
              onGenerateNewScriptFromDissection={() => {
                setActiveNav('editor');
                handleAIGenerateScript(
                  dissectResult.hookAnalysis,
                  dissectResult.extractedFormula,
                  productName,
                  sellingPoints,
                  targetAudience,
                  dissectCategory
                );
              }}
              onNotice={showNotice}
            />
          </main>
        )}

        {/* VIEW 5: 我的云端成片作品 (全宽自适应) */}
        {activeNav === 'my_projects' && (
          <main className="w-full flex-1 space-y-6 p-4 sm:p-6 lg:p-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900">我的成片作品库</h2>
                <p className="mt-0.5 text-xs text-slate-500">
                  支持直接从作品列表生成客户临时审阅链接、一键同步到抖音/小红书/视频号，或导出视频、AI分镜长图与排词文本。
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setCurrentProjectId(null);
                  setActiveNav('editor');
                }}
                className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                <span>新建爆款成片</span>
              </button>
            </div>

            {!user && !domesticUser ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
                <p className="text-sm font-bold text-slate-900">
                  请先使用手机号或邮箱登录以管理您的作品
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  支持大陆手机号验证码或邮箱一键登录，自动同步您的分镜工程与混剪模板。
                </p>
                <button
                  type="button"
                  onClick={() => setIsDomesticLoginOpen(true)}
                  className="mt-4 flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <Phone className="h-4 w-4" />
                  <span>手机号 / 邮箱一键登录</span>
                </button>
              </div>
            ) : allUserProjects.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
                <p className="text-sm font-bold text-slate-900">暂无保存的成片作品</p>
                <p className="mt-1 text-xs text-slate-500">
                  您可以在「海量爆款库」点击一键做同款，或在「AI 脚本与分镜」点击保存作品。
                </p>
                <button
                  type="button"
                  onClick={() => setActiveNav('templates')}
                  className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  去海量爆款库挑一个
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
                {allUserProjects.map((proj) => (
                  <div
                    key={proj.id}
                    className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-base font-bold text-slate-900">{proj.title}</h3>
                        <button
                          type="button"
                          onClick={async () => {
                            if (proj.id.startsWith('local_')) {
                              setLocalProjects((prev) =>
                                prev.filter((item) => item.id !== proj.id)
                              );
                              showNotice('success', '已删除该作品。');
                              return;
                            }
                            try {
                              await deleteDoc(doc(db, 'projects', proj.id));
                              showNotice('success', '已删除该作品。');
                            } catch (err) {
                              handleFirestoreError(
                                err,
                                OperationType.DELETE,
                                `projects/${proj.id}`
                              );
                            }
                          }}
                          className="rounded-lg p-1 text-slate-400 hover:bg-red-50 hover:text-red-600 cursor-pointer"
                          title="删除作品"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="mt-1 flex items-center gap-2 text-xs text-slate-500">
                        <span>{proj.category}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">{proj.aspectRatio}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">
                          {proj.sceneLines.length} 个镜头
                        </span>
                      </div>

                      <p className="mt-3 text-xs font-medium text-slate-800">
                        商品：{proj.productName}
                      </p>
                      <p className="mt-1 line-clamp-2 text-xs text-slate-500">
                        首镜口播：“{proj.sceneLines[0]}”
                      </p>
                    </div>

                    <div className="mt-5 space-y-2 border-t border-slate-100 pt-3">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentProjectId(proj.id);
                            setProjectTitle(proj.title);
                            setProductName(proj.productName);
                            setSellingPoints(proj.sellingPoints);
                            setTargetAudience(proj.targetAudience);
                            setProjectCategory(proj.category);
                            setAspectRatio(proj.aspectRatio);
                            setBgmStyle(proj.bgmStyle);
                            setVoiceTone(proj.voiceTone);
                            setPacingTip(proj.pacingTip);
                            setCameraAngles([...proj.cameraAngles]);
                            setVisualCues([...proj.visualCues]);
                            setSceneLines([...proj.sceneLines]);
                            setActiveNav('editor');
                          }}
                          className="flex-1 rounded-xl border border-slate-200 bg-white py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                        >
                          编辑分镜
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setCurrentProjectId(proj.id);
                            setProjectTitle(proj.title);
                            setProductName(proj.productName);
                            setProjectCategory(proj.category);
                            setAspectRatio(proj.aspectRatio);
                            setBgmStyle(proj.bgmStyle);
                            setVoiceTone(proj.voiceTone);
                            setCameraAngles([...proj.cameraAngles]);
                            setVisualCues([...proj.visualCues]);
                            setSceneLines([...proj.sceneLines]);
                            setIsMixPlayerOpen(true);
                          }}
                          className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-indigo-600 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                        >
                          <Play className="h-3.5 w-3.5 fill-white" />
                          <span>直接混剪</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setShareModalProject(proj)}
                          className="flex flex-1 items-center justify-center gap-1 rounded-xl border border-indigo-200 bg-indigo-50/60 py-2 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 cursor-pointer"
                        >
                          <Share2 className="h-3.5 w-3.5" />
                          <span>共享链接/发平台</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setExportModalProject(proj)}
                          className="flex flex-1 items-center justify-center gap-1 rounded-xl border border-slate-200 bg-slate-50 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>全格式导出</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        )}

        {/* VIEW 6: 我的拆解记录与专属模板 */}
        {activeNav === 'my_saved' && (
          <main className="mx-auto w-full max-w-7xl flex-1 space-y-6 p-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                我的拆解报告库与专属爆款模板
              </h2>
              <p className="mt-0.5 text-xs text-slate-500">
                您在「一键拉片拆解」中提炼并保存的专属模板与拉片记录，可随时一键套用到新商品。
              </p>
            </div>

            {!user && !domesticUser ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
                <p className="text-sm font-bold text-slate-900">
                  请先使用手机号或邮箱登录以同步您的专属模板库
                </p>
                <button
                  type="button"
                  onClick={() => setIsDomesticLoginOpen(true)}
                  className="mt-4 flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  <Phone className="h-4 w-4" />
                  <span>手机号 / 邮箱一键登录</span>
                </button>
              </div>
            ) : allUserTemplates.length === 0 && cloudDissections.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
                <p className="text-sm font-bold text-slate-900">暂无自定义拆解模板</p>
                <p className="mt-1 text-xs text-slate-500">
                  前往「一键拉片拆解」拆解任意文案并点击「保存至拆解库」即可在此随时复用。
                </p>
                <button
                  type="button"
                  onClick={() => setActiveNav('dissect')}
                  className="mt-4 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                >
                  去一键拆解爆款视频
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {allUserTemplates.map((tpl) => (
                  <div
                    key={tpl.id}
                    className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-base font-bold text-slate-900">{tpl.title}</h3>
                        <button
                          type="button"
                          onClick={async () => {
                            if (tpl.id.startsWith('local_')) {
                              setLocalTemplates((prev) =>
                                prev.filter((item) => item.id !== tpl.id)
                              );
                              showNotice('success', '已移除该自定义模板。');
                              return;
                            }
                            try {
                              await deleteDoc(doc(db, 'templates', tpl.id));
                              showNotice('success', '已移除该自定义模板。');
                            } catch (err) {
                              handleFirestoreError(
                                err,
                                OperationType.DELETE,
                                `templates/${tpl.id}`
                              );
                            }
                          }}
                          className="rounded-lg p-1 text-slate-400 hover:bg-red-50 hover:text-red-600 cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="mt-2 text-xs text-slate-600">
                        前3秒钩子：{tpl.hookFormula}
                      </p>
                      <p className="mt-1 text-xs text-indigo-700 font-medium">
                        结构公式：{tpl.structureSummary}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => {
                          setCurrentProjectId(null);
                          setProjectTitle(tpl.title);
                          setProjectCategory(tpl.category);
                          setPacingTip(tpl.structureSummary);
                          setCameraAngles([...tpl.cameraAngles]);
                          setVisualCues([...tpl.visualCues]);
                          setSceneLines([...tpl.sceneLines]);
                          setActiveNav('editor');
                        }}
                        className="w-full rounded-xl bg-indigo-600 py-2 text-xs font-semibold text-white hover:bg-indigo-700 cursor-pointer"
                      >
                        一键套用此模板
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        )}

        {/* VIEW 7: 商业化会员订阅与算力充值中心 (全宽自适应) */}
        {activeNav === 'pricing' && (
          <main className="w-full flex-1 space-y-6 p-4 sm:p-6 lg:p-8">
            <section className="rounded-2xl border border-slate-200 bg-white p-6">
              <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-center">
                <div>
                  <div className="text-xs font-semibold text-indigo-600">
                    商业化 SaaS 计费与算力中心
                  </div>
                  <h2 className="mt-1 text-xl font-bold text-slate-900">
                    当前方案：{tierLabelMap[planTier]} · 剩余可用算力{' '}
                    <span className="font-mono text-indigo-600 tabular-nums">{credits}</span> 点
                  </h2>
                  <p className="mt-1 text-xs text-slate-500">
                    计费规则：AI 一键生成完整分镜脚本 10 点/次 · SkillHub 拆解爆款视频 5 点/次 · AI 单句/单镜精修 5 点/次 · 视频混剪与全格式导出 0 点免费。
                  </p>
                </div>

                <div className="flex w-full max-w-md flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={voucherCode}
                        onChange={(e) => setVoucherCode(e.target.value)}
                        placeholder="输入会员激活码/充值卡密 (如 VIP-PRO-2026)"
                        className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pr-3 pl-9 font-mono text-xs text-slate-900 focus:border-indigo-600 focus:bg-white focus:outline-none"
                      />
                      <KeyRound className="pointer-events-none absolute top-3 left-3 h-4 w-4 text-slate-400" />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRedeemVoucher()}
                      className="rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-indigo-700 whitespace-nowrap"
                    >
                      立即兑换
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span>点击体验测试卡密：</span>
                    {Object.keys(BUILTIN_VOUCHERS).map((code) => (
                      <button
                        key={code}
                        type="button"
                        onClick={() => {
                          setVoucherCode(code);
                          handleRedeemVoucher(code);
                        }}
                        className="font-mono font-semibold text-indigo-600 underline hover:text-indigo-800"
                      >
                        {code}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              <div className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6">
                <div>
                  <div className="text-xs font-semibold text-slate-500">
                    适合新手尝鲜体验
                  </div>
                  <h3 className="mt-1 text-lg font-bold text-slate-900">
                    个人免费体验版
                  </h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="font-mono text-3xl font-bold tabular-nums text-slate-900">
                      ¥0
                    </span>
                    <span className="text-xs text-slate-500">/ 永久有效</span>
                  </div>

                  <ul className="mt-6 space-y-3 text-xs text-slate-600">
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>注册赠送初始算力</span>
                      <span className="font-mono font-semibold tabular-nums text-slate-900">
                        100 点
                      </span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>抖音来客门店记忆库配置</span>
                      <span className="font-semibold text-slate-900">免费开放</span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>海量爆款模板库使用</span>
                      <span className="font-semibold text-slate-900">全部开放</span>
                    </li>
                    <li className="flex items-center justify-between pb-1">
                      <span>全格式导出（视频/长图/CSV）</span>
                      <span className="font-semibold text-slate-900">免费开放</span>
                    </li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => handleRedeemVoucher('CREDITS-200')}
                  className="mt-6 w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 text-xs font-semibold text-slate-800 hover:bg-slate-100"
                >
                  免费领取 200 点体验加油包
                </button>
              </div>

              <div className="flex flex-col justify-between rounded-2xl border-2 border-indigo-600 bg-white p-6">
                <div>
                  <div className="text-xs font-semibold text-indigo-600">
                    适合实体门店商家、带货达人与自媒体博主
                  </div>
                  <h3 className="mt-1 text-lg font-bold text-slate-900">
                    专业创作者月卡 (Pro)
                  </h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="font-mono text-3xl font-bold tabular-nums text-slate-900">
                      ¥39
                    </span>
                    <span className="text-xs text-slate-500">/ 月（立充 1,000 算力点）</span>
                  </div>

                  <ul className="mt-6 space-y-3 text-xs text-slate-600">
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>每月到账 AI 算力额度</span>
                      <span className="font-mono font-semibold tabular-nums text-indigo-600">
                        1,000 点 / 月
                      </span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>可生成爆款脚本或拉片拆解</span>
                      <span className="font-mono font-semibold tabular-nums text-slate-900">
                        100 - 200 次
                      </span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>SkillHub 拆解工作流全技能包</span>
                      <span className="font-semibold text-slate-900">优先高速通道</span>
                    </li>
                    <li className="flex items-center justify-between pb-1">
                      <span>客户临时公共审阅链接生成</span>
                      <span className="font-semibold text-slate-900">无上限</span>
                    </li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => handleRedeemVoucher('VIP-PRO-2026')}
                  className="mt-6 w-full rounded-xl bg-indigo-600 py-2.5 text-xs font-semibold text-white hover:bg-indigo-700"
                >
                  一键开通专业版 (+1,000 算力点)
                </button>
              </div>

              <div className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6">
                <div>
                  <div className="text-xs font-semibold text-amber-600">
                    适合连锁门店品牌、代运营团队与MCN机构
                  </div>
                  <h3 className="mt-1 text-lg font-bold text-slate-900">
                    企业 MCN 矩阵版
                  </h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="font-mono text-3xl font-bold tabular-nums text-slate-900">
                      ¥199
                    </span>
                    <span className="text-xs text-slate-500">/ 月（立充 10,000 算力点）</span>
                  </div>

                  <ul className="mt-6 space-y-3 text-xs text-slate-600">
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>每月到账团队算力池</span>
                      <span className="font-mono font-semibold tabular-nums text-amber-600">
                        10,000 点 / 月
                      </span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>多门店长期记忆知识库管理</span>
                      <span className="font-mono font-semibold tabular-nums text-slate-900">
                        无限门店切换
                      </span>
                    </li>
                    <li className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span>同行爆款库拆解与私有化沉淀</span>
                      <span className="font-semibold text-slate-900">支持全团队复用</span>
                    </li>
                    <li className="flex items-center justify-between pb-1">
                      <span>全格式高清成片与故事板长图导出</span>
                      <span className="font-semibold text-slate-900">尊享无限导出</span>
                    </li>
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => handleRedeemVoucher('VIP-MAX-2026')}
                  className="mt-6 w-full rounded-xl bg-slate-900 py-2.5 text-xs font-semibold text-white hover:bg-slate-800"
                >
                  一键开通企业MCN版 (+10,000 算力点)
                </button>
              </div>
            </section>

            {/* Admin Card Key Generator */}
            <section className="rounded-2xl border border-slate-200 bg-white p-6">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    站长商业化发卡工具（生成卡密发给小红书/微信付费客户）
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500">
                    您可以一键生成新的专属激活码，复制发给付款用户，用户在上方输入框粘贴即可自动充值算力与升级会员。
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const randomSuffix = Math.random()
                        .toString(36)
                        .substring(2, 8)
                        .toUpperCase();
                      const newCode = `PRO-${randomSuffix}`;
                      setGeneratedCustomCodes((prev) => [
                        { code: newCode, tier: 'pro', credits: 1000 },
                        ...prev,
                      ]);
                      showNotice('success', `已生成专业版月卡激活码：${newCode}`);
                    }}
                    className="rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    + 生成 ¥39 专业版卡密
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const randomSuffix = Math.random()
                        .toString(36)
                        .substring(2, 8)
                        .toUpperCase();
                      const newCode = `MCN-${randomSuffix}`;
                      setGeneratedCustomCodes((prev) => [
                        { code: newCode, tier: 'enterprise', credits: 10000 },
                        ...prev,
                      ]);
                      showNotice('success', `已生成企业MCN版激活码：${newCode}`);
                    }}
                    className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    + 生成 ¥199 企业版卡密
                  </button>
                </div>
              </div>

              {generatedCustomCodes.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
                  {generatedCustomCodes.map((item) => (
                    <div
                      key={item.code}
                      className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs"
                    >
                      <span className="font-mono font-bold text-slate-900">{item.code}</span>
                      <span className="text-slate-400">·</span>
                      <span className="font-mono text-slate-600 tabular-nums">
                        +{item.credits}点
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(item.code);
                          setVoucherCode(item.code);
                          showNotice('success', `已复制并填入卡密 ${item.code}`);
                        }}
                        className="font-semibold text-indigo-600 hover:underline"
                      >
                        复制并使用
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </main>
        )}
      </div>

      {/* Modal 1: Real-Time Video Mix-Cut Synthesizer & Exporter */}
      <VideoMixPlayerModal
        isOpen={isMixPlayerOpen}
        onClose={() => setIsMixPlayerOpen(false)}
        title={projectTitle}
        productName={productName}
        category={projectCategory}
        aspectRatio={aspectRatio}
        bgmStyle={bgmStyle}
        voiceTone={voiceTone}
        cameraAngles={cameraAngles}
        visualCues={visualCues}
        sceneLines={sceneLines}
      />

      {/* Modal 2: Temporary Public Share Link & Multi-Platform 1-Click Jump */}
      {shareModalProject && (
        <ShareAndPlatformModal
          isOpen={true}
          onClose={() => setShareModalProject(null)}
          project={shareModalProject}
          onCreateCloudShareLink={(hours) =>
            handleCreateTemporaryShareLink(shareModalProject, hours)
          }
        />
      )}

      {/* Modal 3: Multi-Asset Export Modal */}
      {exportModalProject && (
        <MultiAssetExportModal
          isOpen={true}
          onClose={() => setExportModalProject(null)}
          project={exportModalProject}
          onOpenVideoExporter={() => {
            setProjectTitle(exportModalProject.title);
            setProductName(exportModalProject.productName);
            setProjectCategory(exportModalProject.category);
            setAspectRatio(exportModalProject.aspectRatio);
            setBgmStyle(exportModalProject.bgmStyle);
            setVoiceTone(exportModalProject.voiceTone);
            setCameraAngles([...exportModalProject.cameraAngles]);
            setVisualCues([...exportModalProject.visualCues]);
            setSceneLines([...exportModalProject.sceneLines]);
            setIsMixPlayerOpen(true);
          }}
        />
      )}

      {/* Modal 4: Domestic Phone / Email Login Modal */}
      <DomesticLoginModal
        isOpen={isDomesticLoginOpen}
        onClose={() => setIsDomesticLoginOpen(false)}
        onSuccess={(session) => {
          setDomesticUser(session);
          showNotice(
            'success',
            `欢迎回来，${session.displayName}！已为您激活国内极速工作台通行证。`
          );
        }}
      />

      {/* Modal 5: AI Model Gateway & Custom Endpoint Modal */}
      <AIModelGatewayModal
        isOpen={isGatewayModalOpen}
        onClose={() => setIsGatewayModalOpen(false)}
        config={gatewayConfig}
        onSave={(next) => {
          setGatewayConfig(next);
          showNotice('success', `已切换 AI 能力网关至：${next.providerName} (${next.modelName})`);
        }}
      />

      {/* Modal 6: Kuaizi × Huotu × Youmi Viral Template Replication & Slot Studio */}
      <ViralTemplateStudioModal
        template={studioModalTemplate}
        onClose={() => setStudioModalTemplate(null)}
        storeMemoryEnabled={storeMemoryEnabled}
        activeStore={activeStoreProfile}
        isGenerating={isGeneratingScript}
        onApplySlotsToEditor={(payload) => {
          setCurrentProjectId(null);
          setProjectTitle(payload.title);
          setProductName(payload.productName);
          setSellingPoints(payload.sellingPoints);
          setTargetAudience(payload.audience);
          setProjectCategory(payload.category);
          setBgmStyle(payload.bgmStyle);
          setPacingTip(payload.pacingTip);
          setCameraAngles([...payload.cameraAngles]);
          setVisualCues([...payload.visualCues]);
          setSceneLines([...payload.sceneLines]);
          setShotDurations(payload.cameraAngles.map(() => 4.0));
          setActiveNav('editor');
          if (payload.openMixImmediately) {
            setIsMixPlayerOpen(true);
          } else {
            showNotice('success', `已套用模板并载入「${payload.title}」分镜精修台！`);
          }
        }}
        onAIFissionGenerate={async (payload) => {
          setProductName(payload.productName);
          setSellingPoints(payload.sellingPoints);
          setTargetAudience(payload.audience);
          setProjectCategory(payload.category);
          setActiveNav('editor');
          await handleAIGenerateScript(
            payload.templateHook,
            payload.templateStructure,
            payload.productName,
            payload.sellingPoints,
            payload.audience,
            payload.category
          );
        }}
        onJumpToDissect={(tpl) => handleDissectFromTemplate(tpl)}
        onJumpToGraphicSuite={() => setActiveNav('graphic_suite')}
        onNotice={showNotice}
      />

      {/* Modal 7: Kuaizi 16-Capability Quick Tool Modal (Daily Insight, Multi-Lang TTS, Digital Human, Ad ROI, etc.) */}
      <KuaiziQuickToolModal
        toolId={kuaiziToolModalId}
        onClose={() => setKuaiziToolModalId(null)}
        productName={productName}
        sellingPoints={sellingPoints}
        sceneLines={sceneLines}
        activeStore={activeStoreProfile}
        onApplyTextToScript={(newLines, newTitle) => {
          setSceneLines(newLines);
          if (newTitle) setProjectTitle(newTitle);
          setActiveNav('editor');
          showNotice('success', '已将该洞察钩子填入当前脚本首镜！');
        }}
        onOpenMixPlayer={() => {
          setActiveNav('editor');
          setIsMixPlayerOpen(true);
        }}
      />

      {/* Right-Side Collapsible RAG Knowledge Base AI Copilot Sidebar */}
      <RagCopilotSidebar
        isOpen={isRagCopilotOpen}
        onClose={() => setIsRagCopilotOpen(false)}
        storeMemoryEnabled={storeMemoryEnabled}
        activeStore={activeStoreProfile}
        productName={productName}
        sellingPoints={sellingPoints}
        cameraAngles={cameraAngles}
        visualCues={visualCues}
        sceneLines={sceneLines}
        onApplyHookToFirstShot={(newHookLine) => {
          const next = [...sceneLines];
          if (next.length > 0) next[0] = newHookLine;
          else next.push(newHookLine);
          setSceneLines(next);
          setActiveNav('editor');
          showNotice('success', 'RAG 智库助手已为您更新第 1 镜黄金前3秒台词！');
        }}
        onApplyFullScriptFromRag={(payload) => {
          setProjectTitle(payload.title);
          setCameraAngles([...payload.cameraAngles]);
          setVisualCues([...payload.visualCues]);
          setSceneLines([...payload.sceneLines]);
          setShotDurations(payload.cameraAngles.map(() => 4.0));
          setActiveNav('editor');
          showNotice('success', `已载入 RAG 智库为您定制的「${payload.title}」4镜脚本！`);
        }}
        onOpenStoreConfig={() => {
          setIsRagCopilotOpen(false);
          setMerchantSubTab('stores');
          setActiveNav('store_kb');
        }}
      />

      {/* Modal 8: Dedicated Product Manual & System Architecture Documentation Modal */}
      <SystemManualModal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
      />

      {/* Modal 9: Personal Custom AI Agent & Deep RAG Knowledge Base Studio */}
      <PersonalAgentRagStudioModal
        isOpen={isPersonalAgentModalOpen}
        onClose={() => setIsPersonalAgentModalOpen(false)}
        activeProfile={activeStoreProfile}
        onSaveAgentAndProfile={(newAgent, newProfile) => {
          setLocalStores((prev) => [newProfile, ...prev.filter((s) => s.id !== newProfile.id)]);
          setActiveStoreId(newProfile.id);
          setStoreNameInput(newProfile.storeName);
          setStoreIndustryInput(newProfile.industry);
          setStoreProductsInput(newProfile.signatureProducts);
          setStorePersonaInput(newProfile.storePersona);
          setStoreAudienceInput(newProfile.targetAudience);
          setStoreAnchorsInput(newProfile.memoryAnchors);
          setStoreMemoryEnabled(true);
          recordHistoryEntry(
            'action',
            `已装载专属智能体「${newAgent.name}」与深度RAG知识库`,
            'AI 智能体与 RAG 建立',
            'workbench'
          );
          showNotice(
            'success',
            `已成功装载专属智能体「${newAgent.name}」！RAG 召回深度 98.4%，已注入全局长期记忆。`
          );
        }}
        onShowNotice={showNotice}
      />
    </div>
  );
}
