import {createRoot} from 'react-dom/client';
import React, { Suspense } from 'react';
import Studio from './studio/Studio';
import './index.css';

const LegacyApp = React.lazy(() => import('./App.tsx'));
createRoot(document.getElementById('root')!).render(new URLSearchParams(location.search).has('legacy') ? <><div style={{ position: 'sticky', top: 0, zIndex: 999, padding: '12px 24px', background: '#172337', color: '#c8ddf9', fontSize: 13 }}>旧版原型与历史工具：部分模块尚未迁移，展示数据不代表真实执行结果。<a href="/" style={{ marginLeft: 18, color: '#b9d9ff' }}>进入新版创作工作台 →</a></div><Suspense fallback={<p>正在载入原版工具…</p>}><LegacyApp /></Suspense></> : <Studio />);
