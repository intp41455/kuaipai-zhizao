import { auth, db } from '../firebase';
import { collection, doc, getDoc, getDocs, query, where, setDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getBlob } from 'firebase/storage';
import type { Assistant, FilmProject, Asset } from './types';

const mediaStorage = getStorage(auth.app);

export async function studioFetch(url: string, options: RequestInit = {}) {
  const token = await auth.currentUser?.getIdToken();
  if (!token) throw new Error('请先登录后使用此功能。');
  const response = await fetch(url, { ...options, headers: { ...(options.body instanceof File || options.body instanceof Blob ? {} : { 'Content-Type': 'application/json' }), ...options.headers, Authorization: `Bearer ${token}` } });
  if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.error || `请求失败（${response.status}）`); }
  return response;
}
export async function saveCloudProject(project: FilmProject, files: Map<string, File>, onProgress?: (name: string, percent: number) => void) {
  const user = auth.currentUser;
  if (!user) throw new Error('请登录后保存到云端。');
  const id = project.id || crypto.randomUUID();
  const assets = [];
  const storagePaths: Record<string, string> = {};
  for (const asset of project.assets) {
    let storagePath = asset.storagePath;
    if (!storagePath?.startsWith(`users/${user.uid}/assets/`)) {
      const file = files.get(asset.id);
      if (!file) throw new Error(`缺少原始素材“${asset.name}”，请先替换或重新关联。`);
      storagePath = `users/${user.uid}/assets/${asset.id}`;
      const task = uploadBytesResumable(ref(mediaStorage, storagePath), file, { contentType: file.type || (asset.kind === 'video' ? 'video/mp4' : 'image/jpeg') });
      await new Promise<void>((resolve, reject) => task.on('state_changed', snapshot => onProgress?.(asset.name, Math.round(snapshot.bytesTransferred / snapshot.totalBytes * 100)), reject, resolve));
    }
    storagePaths[asset.id] = storagePath;
    assets.push({ id: asset.id, name: asset.name, kind: asset.kind, storagePath, ...(Number.isFinite(asset.duration) ? { duration: asset.duration } : {}) });
  }
  await setDoc(doc(db, 'studio_projects', id), { ownerId: user.uid, title: project.title, style: project.style, aspect: project.aspect, description: project.description, scenes: project.scenes, assets, updatedAt: serverTimestamp() });
  return { id, storagePaths };
}
export async function restoreCloudAsset(asset: Asset) {
  if (!asset.storagePath) return null;
  const user = auth.currentUser;
  if (!user || !asset.storagePath.startsWith(`users/${user.uid}/assets/`)) throw new Error('无权读取此素材。');
  const blob = await getBlob(ref(mediaStorage, asset.storagePath));
  const file = new File([blob], asset.name, { type: blob.type || (asset.kind === 'video' ? 'video/mp4' : 'image/jpeg') });
  return { file, asset: { ...asset, url: URL.createObjectURL(file) } };
}
export async function listCloudProjects() {
  const user = auth.currentUser;
  if (!user) throw new Error('请先登录。');
  const result = await getDocs(query(collection(db, 'studio_projects'), where('ownerId', '==', user.uid)));
  return result.docs.map(d => ({ ...d.data(), id: d.id } as FilmProject));
}
export async function deleteCloudProject(id: string) { await deleteDoc(doc(db, 'studio_projects', id)); }
export async function saveAssistant(assistant: Assistant) {
  if (!auth.currentUser) throw new Error('请登录后保存助手。');
  if (assistant.knowledge.reduce((sum, item) => sum + item.text.length, 0) > 200000) throw new Error('当前知识资料合计超过20万字，请精简或拆分。');
  await setDoc(doc(db, 'studio_assistants', auth.currentUser.uid), { ...assistant, ownerId: auth.currentUser.uid, updatedAt: serverTimestamp() });
}
export async function loadAssistant() {
  if (!auth.currentUser) return null;
  const result = await getDoc(doc(db, 'studio_assistants', auth.currentUser.uid));
  return result.exists() ? result.data() as Assistant : null;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('kuaipai-studio-v1', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('drafts');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
export async function saveDeviceDraft(key: string, value: unknown) {
  const database = await openDB();
  await new Promise<void>((resolve, reject) => { const tx = database.transaction('drafts', 'readwrite'); tx.objectStore('drafts').put(value, key); tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); });
  database.close();
}
export async function loadDeviceDraft(key: string) {
  const database = await openDB();
  try { return await new Promise<any>((resolve, reject) => { const request = database.transaction('drafts').objectStore('drafts').get(key); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); }
  finally { database.close(); }
}
