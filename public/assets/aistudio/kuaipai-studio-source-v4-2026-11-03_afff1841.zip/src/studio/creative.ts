import type { Scene } from './types';

export const creativeDirections = [
  { id: 'detail', name: '细节故事', instruction: '从素材中一个具体细节切入，按环境、动作、细节组织故事，使用自然口语，不虚构探店经历。' },
  { id: 'practical', name: '实用清单', instruction: '以用户能获得的实用信息开场，组织成值得收藏的简短清单，价格、地址和营业时间只能引用已提供事实。' },
  { id: 'discovery', name: '发现看点', instruction: '先提出一个与可见素材相关的问题，再用镜头给出答案，突出值得观看的真实看点，不使用虚假震惊或夸大功效。' },
] as const;

export interface CreativePlan { title: string; scenes: Scene[] }
export async function submitCreativeBatch(
  plan: (direction: typeof creativeDirections[number], index: number) => Promise<CreativePlan>,
  submit: (plan: CreativePlan, index: number) => Promise<void>,
) {
  const signatures = new Set<string>();
  let submitted = 0;
  try {
    for (let index = 0; index < creativeDirections.length; index++) {
      const result = await plan(creativeDirections[index], index);
      const signature = result.scenes.map(scene => scene.text.trim()).join('\n');
      if (!signature || signatures.has(signature)) throw new Error('模型返回了空白或重复文案，请调整创作说明后重试。');
      signatures.add(signature);
      await submit(result, index); submitted++;
    }
  } catch (error) { throw new Error(`已提交 ${submitted} / 3 个创意版本。${(error as Error).message}`); }
  return submitted;
}
