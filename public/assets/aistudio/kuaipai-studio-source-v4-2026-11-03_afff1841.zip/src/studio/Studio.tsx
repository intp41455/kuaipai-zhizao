import React, { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ArrowLeft, ArrowRight, AudioLines, Bot, Check, ChevronDown, Clapperboard, Download, Film, ImagePlus, Layers, LoaderCircle, LogOut, Mic, MoreHorizontal, Play, Plus, Save, Search, Settings2, Sparkles, Trash2, Upload, UserRound, X } from 'lucide-react';
import { onAuthStateChanged, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendEmailVerification, signOut, type User } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import type { Asset, Scene, Assistant, FilmProject } from './types';
import { submitCreativeBatch, type CreativePlan } from './creative';
import { studioFetch, saveCloudProject, listCloudProjects, deleteCloudProject, saveAssistant, loadAssistant, saveDeviceDraft, loadDeviceDraft, restoreCloudAsset } from './storage';
import './studio.css';

const styles = [{ id: 'food', title: '烟火探店', detail: '鲜明食欲 · 快节奏', color: '#f3b975' }, { id: 'film', title: '城市纪事', detail: '电影色调 · 慢叙事', color: '#a7a1e6' }, { id: 'clean', title: '私藏清单', detail: '清爽信息 · 易收藏', color: '#7fc9d1' }];
const initialAssistant: Assistant = { name: '我的内容搭档', instruction: '真诚、自然，有具体细节，不夸大，不编造价格和店铺信息。', knowledge: [] };
type Job = { id: string; title?: string; status: string; progress: number; error?: string; downloadable: boolean };
function download(blob: Blob, name: string) { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000); }
async function thumbnail(file: File, url: string): Promise<{ thumbnail: string; duration?: number }> {
  const canvas = document.createElement('canvas'); canvas.width = 384; canvas.height = 384;
  const ctx = canvas.getContext('2d')!;
  if (file.type.startsWith('image/')) {
    const img = new Image(); img.src = url; await img.decode();
    const s = Math.max(384 / img.width, 384 / img.height); ctx.drawImage(img, (384 - img.width * s) / 2, (384 - img.height * s) / 2, img.width * s, img.height * s);
    return { thumbnail: canvas.toDataURL('image/jpeg', 0.65) };
  }
  const video = document.createElement('video'); video.muted = true; video.preload = 'auto'; video.src = url;
  await new Promise<void>((resolve, reject) => { video.onloadeddata = () => resolve(); video.onerror = () => reject(new Error('视频无法读取，请使用MP4/H.264或常见格式。')); });
  const duration = video.duration;
  ctx.drawImage(video, 0, 0, 384, 384); const result = { thumbnail: canvas.toDataURL('image/jpeg', 0.65), duration };
  video.removeAttribute('src'); video.load(); return result;
}

export default function Studio() {
  const [page, setPage] = useState<'create' | 'projects' | 'assistant'>(new URLSearchParams(location.search).get('workspace') === 'assistant' ? 'assistant' : 'create');
  const [mode, setMode] = useState<'video' | 'note'>('video');
  const [user, setUser] = useState<User | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(''); const [notice, setNotice] = useState('');
  const [assets, setAssets] = useState<Asset[]>([]); const files = useRef(new Map<string, File>());
  const [scenes, setScenes] = useState<Scene[]>([]); const [active, setActive] = useState(0);
  const [title, setTitle] = useState(''); const [subject, setSubject] = useState(''); const [description, setDescription] = useState('');
  const [style, setStyle] = useState('food'); const [aspect, setAspect] = useState<'9:16' | '16:9'>('9:16');
  const [voice, setVoice] = useState('Kore'); const [narration, setNarration] = useState(false); const [bgm, setBgm] = useState<File | null>(null);
  const [assistant, setAssistant] = useState<Assistant>(initialAssistant); const [question, setQuestion] = useState(''); const [answer, setAnswer] = useState('');
  const [sources, setSources] = useState<{ name: string; chunk: number; text: string }[]>([]);
  const [projects, setProjects] = useState<FilmProject[]>([]); const [projectId, setProjectId] = useState<string>(); const [jobs, setJobs] = useState<Job[]>([]);
  const [capabilities, setCapabilities] = useState<{ renderer: boolean; speech: boolean } | null>(null);
  const [draftReady, setDraftReady] = useState(false); const [playing, setPlaying] = useState(false);
  const [filmPreview, setFilmPreview] = useState<{ url: string; title: string }>(); const resultDialog = useRef<HTMLDialogElement>(null);
  const [sampleAudio, setSampleAudio] = useState<string>(); const input = useRef<HTMLInputElement>(null);
  const relinkInput = useRef<HTMLInputElement>(null); const relinkId = useRef<string>('');
  const speechRef = useRef<HTMLAudioElement>(null); const previewVideo = useRef<HTMLVideoElement>(null);
  const previewAsset = assets.find(a => a.id === scenes[active]?.assetId);
  const latest = useRef({ assets, scenes, title, style, aspect, description, subject, projectId }); latest.current = { assets, scenes, title, style, aspect, description, subject, projectId };
  const ownerRef = useRef<string | null>(null);

  useEffect(() => onAuthStateChanged(auth, async current => {
    setUser(current); setFilmPreview(undefined); setCapabilities(null); setJobs([]); setProjects([]); setAssistant(initialAssistant);
    const previousOwner = ownerRef.current;
    const carriedDraft = current && previousOwner === 'guest' && latest.current.assets.length ? { ...latest.current, projectId: undefined, assets: latest.current.assets.map(a => ({ ...a, file: files.current.get(a.id) })) } : null;
    const key = current?.uid || 'guest'; ownerRef.current = key; setDraftReady(false);
    try {
      const draft = carriedDraft || await loadDeviceDraft(key);
      if (ownerRef.current !== key) return;
      files.current.clear();
      if (draft) {
        const restored = (draft.assets || []).map((a: Asset & { file?: File }) => { const { file, ...asset } = a; if (file) files.current.set(a.id, file); return { ...asset, url: file ? URL.createObjectURL(file) : '' }; });
        setAssets(restored); setScenes(draft.scenes || []); setTitle(draft.title || ''); setStyle(draft.style || 'food'); setAspect(draft.aspect || '9:16'); setDescription(draft.description || ''); setSubject(draft.subject || ''); setProjectId(draft.projectId); setActive(0);
      } else { setAssets([]); setScenes([]); setTitle(''); setDescription(''); setSubject(''); setProjectId(undefined); }
      setDraftReady(true);
      if (current) {
        studioFetch('/api/studio/status').then(r => r.json()).then(setCapabilities).catch(e => setNotice(e.message));
        loadAssistant().then(a => { if (a && ownerRef.current === key) setAssistant(a); }).catch(e => setNotice(`助手云端读取失败：${e.message}`));
      }
    } catch { setDraftReady(true); setNotice('浏览器未允许本机草稿存储，请及时保存云端工程。'); }
  }), []);
  useEffect(() => {
    if (!draftReady) return;
    const key = user?.uid || 'guest';
    const timer = setTimeout(() => saveDeviceDraft(key, { ...latest.current, assets: latest.current.assets.map(a => ({ ...a, url: '', file: files.current.get(a.id) })) }).catch(() => setNotice('本机存储空间不足，请下载或保存工程。')), 700);
    return () => clearTimeout(timer);
  }, [assets, scenes, title, style, aspect, description, subject, projectId, draftReady, user]);
  useEffect(() => { if (!notice) return; const t = setTimeout(() => setNotice(''), 9000); return () => clearTimeout(t); }, [notice]);
  useEffect(() => {
    if (!user) return;
    let stopped = false;
    const poll = () => studioFetch('/api/studio/jobs').then(r => r.json()).then(data => { if (!stopped) setJobs(data); }).catch(() => {});
    poll(); const t = setInterval(poll, 2500); return () => { stopped = true; clearInterval(t); };
  }, [user]);
  useEffect(() => {
    if (!playing || !scenes.length) return;
    const t = setTimeout(() => { if (active < scenes.length - 1) setActive(a => a + 1); else { setPlaying(false); setActive(0); } }, scenes[active].duration * 1000);
    return () => clearTimeout(t);
  }, [playing, active, scenes]);
  useEffect(() => {
    const video = previewVideo.current;
    if (video && previewAsset?.kind === 'video') { video.currentTime = scenes[active]?.start || 0; if (playing) video.play().catch(() => {}); else video.pause(); }
  }, [active, playing, previewAsset?.id]);
  useEffect(() => () => { if (sampleAudio) URL.revokeObjectURL(sampleAudio); }, [sampleAudio]);

  useEffect(() => { if (!filmPreview) return; resultDialog.current?.showModal(); return () => URL.revokeObjectURL(filmPreview.url); }, [filmPreview]);

  async function task(name: string, fn: () => Promise<void>) { setBusy(name); try { await fn(); } catch (e) { setNotice((e as Error).message); } finally { setBusy(''); } }
  function needUser() { if (user) return true; setAuthOpen(true); setNotice('登录后即可使用 AI、云端保存和视频合成。'); return false; }
  async function importFiles(selected: FileList | File[]) {
    await task('正在读取素材', async () => {
      const incoming: Asset[] = [];
      for (const file of Array.from(selected).slice(0, Math.max(0, 24 - assets.length))) {
        if (!/^(image|video)\//.test(file.type)) continue;
        if (file.size > 25 * 1024 * 1024) throw new Error(`${file.name} 超过25MB，请先压缩。`);
        const url = URL.createObjectURL(file); const id = crypto.randomUUID();
        try { const info = await thumbnail(file, url); incoming.push({ id, name: file.name, kind: file.type.startsWith('image') ? 'image' : 'video', url, ...info }); files.current.set(id, file); }
        catch (e) { URL.revokeObjectURL(url); throw e; }
      }
      if (!incoming.length) throw new Error('请选择常见图片或视频，最多24个素材。');
      setAssets(a => [...a, ...incoming]); setScenes(s => [...s, ...incoming.map(a => ({ assetId: a.id, text: '', duration: Math.min(a.duration || 4, 5), start: 0 }))]); setNotice(`已导入 ${incoming.length} 个素材，点击镜头即可编辑。`);
    });
  }
  async function replaceMedia(file: File) { await task('替换素材', async () => { if (file.size > 25 * 1024 * 1024 || !/^(image|video)\//.test(file.type)) throw new Error('请选择25MB内的图片或视频。'); const id = relinkId.current; const url = URL.createObjectURL(file); const info = await thumbnail(file, url); files.current.set(id, file); setAssets(items => items.map(a => a.id === id ? { id, name: file.name, kind: file.type.startsWith('image/') ? 'image' : 'video', url, ...info } : a)); }); }
  function changeScene(index: number, patch: Partial<Scene>) { setScenes(s => s.map((scene, i) => i === index ? { ...scene, ...patch } : scene)); }
  async function generate() {
    if (!needUser()) return;
    await task('AI 正在看素材、写脚本', async () => {
      const result = await (await studioFetch('/api/ai/studio-plan', { method: 'POST', body: JSON.stringify({ subject, style, assistant, assets }) })).json();
      setTitle(result.title); setDescription(result.description); setScenes(result.scenes); setSources(result.sources); setActive(0); setPlaying(false); setNotice('脚本已生成。请核对店名、价格和地址，再导出成片。');
    });
  }
  async function save() {
    if (!needUser()) return;
    await task('正在保存工程', async () => { const saved = await saveCloudProject({ id: projectId, title: title || '未命名作品', style, aspect, scenes, assets, description }, files.current, (name, percent) => setBusy(`正在上传素材 ${percent}% · ${name}`)); setProjectId(saved.id); setAssets(current => current.map(asset => ({ ...asset, storagePath: saved.storagePaths[asset.id] }))); setNotice('工程和原始素材已保存到云端，可在其他设备登录继续编辑。'); });
  }
  async function uploadAsset(file: File) {
    return (await studioFetch('/api/studio/assets', { method: 'POST', headers: { 'Content-Type': file.type, 'X-File-Name': encodeURIComponent(file.name) }, body: file })).json();
  }
  async function exportFilm(count = 1) {
    if (!needUser()) return;
    if (!scenes.length) return setNotice('请先添加素材。');
    await task('正在提交成片任务', async () => {
      const ids = new Map<string, string>();
      const neededAssets = count > 1 ? assets : assets.filter(a => scenes.some(s => s.assetId === a.id));
      for (const asset of neededAssets) {
        if (ids.has(asset.id)) continue;
        const file = files.current.get(asset.id);
        if (!file) throw new Error('此工程缺少本机原始素材，请重新上传并关联镜头。');
        const uploaded = await uploadAsset(file); ids.set(asset.id, uploaded.id);
      }
      const music = bgm ? await uploadAsset(bgm) : null;
      const submit = async (plan: CreativePlan) => {
        await studioFetch('/api/studio/render', { method: 'POST', body: JSON.stringify({ title: plan.title, style, aspect, narration, voice, bgmId: music?.id, scenes: plan.scenes.map(s => ({ ...s, assetId: ids.get(s.assetId) })) }) });
      };
      if (count === 1) await submit({ title, scenes });
      else await submitCreativeBatch(async (direction, index) => {
        setBusy(`AI 正在策划 ${index + 1} / 3 · ${direction.name}`);
        return (await (await studioFetch('/api/ai/studio-plan', { method: 'POST', body: JSON.stringify({ subject, style, assistant, assets, creativeDirection: direction.id }) })).json()) as CreativePlan;
      }, submit);
      setNotice(`${count} 个真实渲染任务已排队，完成后可在右侧下载。`);
      setJobs(await (await studioFetch('/api/studio/jobs')).json());
    });
  }
  async function exportNote(index: number) {
    await task('正在生成图文图片', async () => {
      const asset = assets.find(a => a.id === scenes[index]?.assetId);
      if (!asset?.url) throw new Error('请重新上传原始素材。');
      const canvas = document.createElement('canvas'); canvas.width = 1080; canvas.height = 1440; const ctx = canvas.getContext('2d')!;
      const image = new Image(); image.src = asset.kind === 'image' ? asset.url : asset.thumbnail || asset.url; await image.decode();
      const scale = Math.max(1080 / image.width, 1440 / image.height); ctx.drawImage(image, (1080 - image.width * scale) / 2, (1440 - image.height * scale) / 2, image.width * scale, image.height * scale);
      const gradient = ctx.createLinearGradient(0, 720, 0, 1440); gradient.addColorStop(0, 'transparent'); gradient.addColorStop(1, '#081222ee'); ctx.fillStyle = gradient; ctx.fillRect(0, 720, 1080, 720);
      ctx.fillStyle = '#fff'; ctx.font = '600 56px "Microsoft YaHei", sans-serif';
      (scenes[index].text || title || '记录此刻').match(/.{1,15}/gu)?.slice(0, 5).forEach((line, i) => ctx.fillText(line, 76, 1100 + i * 74));
      ctx.font = '28px sans-serif'; ctx.fillText(`${index + 1} / ${scenes.length}`, 78, 1360);
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('图片导出失败')), 'image/png'));
      download(blob, `${title || '图文'}-${index + 1}.png`);
    });
  }
  async function login(action: 'google' | 'login' | 'register') {
    await task('正在登录', async () => {
      if (action === 'google') await signInWithPopup(auth, googleProvider);
      else if (action === 'login') await signInWithEmailAndPassword(auth, email, password);
      else { const result = await createUserWithEmailAndPassword(auth, email, password); await sendEmailVerification(result.user); setNotice('账户已创建，验证邮件已发送。默认权限为内容创作者。'); }
      setPassword(''); setAuthOpen(false);
    });
  }
  function moveScene(index: number, delta: number) {
    const target = index + delta; if (target < 0 || target >= scenes.length) return;
    setScenes(s => { const result = [...s]; [result[index], result[target]] = [result[target], result[index]]; return result; }); setActive(target);
  }
  const current = scenes[active];
  return <div className="kp-studio">
    <aside className="kp-nav">
      <a className="kp-brand" href="/" aria-label="快拍智造首页"><span className="kp-logo"><Clapperboard size={22} /></span><span>快拍智造<small>让好素材，成为好内容</small></span></a>
      <div className="kp-nav-group"><span className="kp-nav-caption">工作空间</span>
        <button className={page === 'create' ? 'selected' : ''} onClick={() => setPage('create')}><Sparkles size={18} />创作工作台</button>
        <button className={page === 'projects' ? 'selected' : ''} onClick={() => { setPage('projects'); if (needUser()) task('读取作品', async () => setProjects(await listCloudProjects())); }}><Layers size={18} />我的作品</button>
        <button className={page === 'assistant' ? 'selected' : ''} onClick={() => setPage('assistant')}><Bot size={18} />专属 AI 助手</button>
      </div>
      <div className="kp-nav-bottom"><p>每一段随拍<br />都有值得被看见的故事。</p><a href="?legacy=1" target="_blank" rel="noreferrer">原版工具与历史工程 <ArrowUpRight size={14} /></a><button onClick={() => user ? task('退出登录', () => signOut(auth)) : setAuthOpen(true)}><UserRound size={18} /><span>{user?.displayName || user?.email?.split('@')[0] || '登录你的工作空间'}<small>{user ? '内容创作者 · 个人空间' : '登录后解锁云端 AI 创作'}</small></span>{user && <LogOut size={14} />}</button></div>
    </aside>
    <main className="kp-main"><input ref={relinkInput} type="file" accept="image/*,video/*" hidden onChange={e => { const file = e.target.files?.[0]; if (file) replaceMedia(file); e.target.value = ''; }} />
      <header className="kp-topbar"><div><span className="kp-live-dot" /> {page === 'create' ? '创作工作台' : page === 'projects' ? '我的作品' : '专属 AI 助手'}</div><span className="kp-top-meta">随拍素材 · 自然表达 · 真实成片</span></header>
      {page === 'create' && <>
        <section className="kp-heading"><div><p className="kp-eyebrow">从生活里，找到你的下一条好内容</p><h1>灵感到成片，<span>简单一点。</span></h1><p>放入照片和视频，剩下的交给你与 AI 一起完成。</p></div><button className="kp-secondary" onClick={() => { setAssets([]); setScenes([]); setProjectId(undefined); setTitle(''); setDescription(''); setSubject(''); setActive(0); files.current.clear(); }}><Plus size={16} />新建创作</button></section>
        <div className="kp-workspace"><section className="kp-editor">
          <div className="kp-modebar"><div className="kp-tabs"><button className={mode === 'video' ? 'active' : ''} onClick={() => setMode('video')}><Film size={16} />短视频</button><button className={mode === 'note' ? 'active' : ''} onClick={() => setMode('note')}><ImagePlus size={16} />图文笔记</button></div><span>{assets.length}/24 个素材</span></div>
          <div className={'kp-upload ' + (assets.length ? 'compact' : '')} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); if (!busy) importFiles(e.dataTransfer.files); }}>
            <input ref={input} type="file" multiple accept="image/*,video/*" hidden onChange={e => { if (e.target.files) importFiles(e.target.files); e.target.value = ''; }} />
            <button onClick={() => input.current?.click()} disabled={!!busy || assets.length >= 24}><span className="kp-upload-icon"><Upload size={24} /></span><strong>{assets.length ? '继续添加素材' : '把你的随拍，放进来'}</strong><span>拖入照片或视频，或点击选择</span><small>支持 JPG、PNG、WebP、MP4、MOV · 单个 25MB 内</small></button>
          </div>
          {assets.length > 0 && <div className="kp-asset-strip">{assets.map(asset => <button key={asset.id} onClick={() => { setActive(scenes.findIndex(s => s.assetId === asset.id)); setPlaying(false); }} title={asset.name}>{asset.thumbnail && <img src={asset.thumbnail} alt={asset.name} />}<span>{asset.kind === 'video' ? '视频' : '照片'}</span></button>)}</div>}
          <div className="kp-brief"><label htmlFor="subject">这次，想让大家看见什么？</label><textarea id="subject" value={subject} onChange={e => setSubject(e.target.value)} placeholder="比如：分享西安一家巷子里的面馆，想突出手工现做和烟火气。店名、价格等事实请在这里写清楚。" maxLength={1200} /></div>
          <div className="kp-style-row">{styles.map(s => <button key={s.id} className={style === s.id ? 'active' : ''} onClick={() => setStyle(s.id)}><span className="kp-style-swatch" style={{ background: s.color }} /><span><strong>{s.title}</strong><small>{s.detail}</small></span>{style === s.id && <Check size={15} />}</button>)}</div>
          <button className="kp-generate" disabled={!!busy || !assets.length} onClick={generate}>{busy.includes('AI') ? <LoaderCircle className="kp-spin" size={18} /> : <Sparkles size={18} />}用 AI 编排这组素材<span>识别画面 · 写文案 · 排镜头</span></button>
          {scenes.length > 0 && <section className="kp-timeline"><div className="kp-section-title"><h2>把故事，调整成你的样子</h2><span>约 {(scenes.reduce((sum, s) => sum + s.duration, 0) - (style === 'film' ? Math.max(0, scenes.length - 1) * 0.3 : 0)).toFixed(1)} 秒 · {scenes.length} 镜头</span></div><input className="kp-title-input" aria-label="作品标题" value={title} onChange={e => setTitle(e.target.value)} placeholder="给这条作品一个标题" maxLength={120} />
            <div className="kp-scenes">{scenes.map((scene, index) => { const asset = assets.find(a => a.id === scene.assetId); return <div key={`${scene.assetId}-${index}`} className={'kp-scene ' + (active === index ? 'active' : '')} onClick={() => { setActive(index); setPlaying(false); }}><div className="kp-scene-image">{asset?.thumbnail ? <img src={asset.thumbnail} alt={`镜头${index + 1}`} /> : <Film size={20} />}<span>{String(index + 1).padStart(2, '0')}</span></div><div className="kp-scene-body"><textarea aria-label={`镜头${index + 1}文案`} value={scene.text} onChange={e => changeScene(index, { text: e.target.value })} placeholder="写下这一镜的字幕和口播" maxLength={180} /><div className="kp-scene-controls"><label>时长 <input aria-label={`镜头${index + 1}时长`} type="number" min="2" max="15" step="0.5" value={scene.duration} onChange={e => changeScene(index, { duration: Math.max(2, Math.min(15, Number(e.target.value) || 4)) })} /> 秒</label>{asset?.kind === 'video' && <label>起点 <input aria-label={`镜头${index + 1}起点`} type="number" min="0" max={asset.duration || 3600} value={scene.start} onChange={e => changeScene(index, { start: Math.max(0, Number(e.target.value)) })} /> 秒</label>}<div className="kp-scene-actions"><button aria-label={`替换镜头${index + 1}素材`} onClick={e => { e.stopPropagation(); relinkId.current = scene.assetId; relinkInput.current?.click(); }}>替换</button><button aria-label={`镜头${index + 1}前移`} disabled={index === 0} onClick={e => { e.stopPropagation(); moveScene(index, -1); }}><ArrowLeft size={14} /></button><button aria-label={`镜头${index + 1}后移`} disabled={index === scenes.length - 1} onClick={e => { e.stopPropagation(); moveScene(index, 1); }}><ArrowRight size={14} /></button><button aria-label={`删除镜头${index + 1}`} onClick={e => { e.stopPropagation(); setScenes(s => s.filter((_, i) => i !== index)); setActive(0); }}><Trash2 size={14} /></button></div></div></div></div>; })}</div>
            {mode === 'note' && <label className="kp-note-label">笔记正文<textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="补充你的真实体验、店铺信息与推荐理由。" maxLength={8000} /><button className="kp-secondary" onClick={() => { download(new Blob([title + '\n\n' + description], { type: 'text/plain;charset=utf-8' }), '图文文案.txt'); }}>下载文案</button></label>}
          </section>}
          <details className="kp-advanced"><summary><Settings2 size={16} />声音与画面设置<ChevronDown size={16} /></summary><div className="kp-settings-grid"><label>画幅<select value={aspect} onChange={e => setAspect(e.target.value as '9:16' | '16:9')}><option value="9:16">9:16 竖屏 · 1080P</option><option value="16:9">16:9 横屏 · 1080P</option></select></label><label>配音声音<select value={voice} onChange={e => setVoice(e.target.value)}><option value="Kore">自然女声 · Kore</option><option value="Puck">轻快中性 · Puck</option><option value="Charon">沉稳男声 · Charon</option><option value="Aoede">柔和女声 · Aoede</option></select></label><label className="kp-check"><input type="checkbox" checked={narration} onChange={e => setNarration(e.target.checked)} />生成真实 AI 配音并混入成片</label><button className="kp-secondary" disabled={!!busy || !current?.text} onClick={() => { if (!needUser()) return; task('生成配音试听', async () => { const response = await studioFetch('/api/studio/speech', { method: 'POST', body: JSON.stringify({ text: current.text, voice }) }); setSampleAudio(URL.createObjectURL(await response.blob())); }); }}><Mic size={15} />试听当前镜头</button><label className="kp-music">背景音乐（请使用有授权的音频）<input type="file" accept="audio/*" onChange={e => setBgm(e.target.files?.[0] || null)} />{bgm?.name}</label>{sampleAudio && <audio ref={speechRef} src={sampleAudio} controls autoPlay />}</div><p>AI 配音需部署端配置有效密钥。实拍原声默认静音；成片使用生成配音和你选择的背景音乐。</p></details>
          <div className="kp-bottom-actions"><button className="kp-secondary" onClick={save} disabled={!!busy || !scenes.length}><Save size={16} />保存云端工程</button><span>素材与编辑自动暂存本机</span><button className="kp-link-button" onClick={() => { if (!needUser()) return; exportFilm(3); }} disabled={!!busy || !assets.length}>AI 生成 3 个创意版本 <Layers size={14} /></button></div>
        </section>
        <aside className="kp-preview-panel"><div className="kp-section-title"><h2>作品预览</h2><span>{mode === 'video' ? '画面与字幕' : '图文封面'}</span></div><div className={'kp-phone ' + (aspect === '16:9' ? 'landscape' : '')}>
          {previewAsset?.url ? <>{previewAsset.kind === 'video' ? <video ref={previewVideo} src={previewAsset.url} muted playsInline loop /> : <img key={previewAsset.id} src={previewAsset.url} alt="当前镜头预览" className={playing ? 'kp-photo-motion' : ''} />}<div className="kp-phone-shade" /><div className="kp-phone-caption">{current?.text || '你的故事，从这里开始'}</div><span className="kp-preview-label">{styles.find(s => s.id === style)?.title}</span></> : <div className="kp-phone-empty"><span className="kp-orbit"><Clapperboard size={30} /></span><strong>好内容，从一段随拍开始</strong><p>上传后，在这里看见你的作品</p></div>}
        </div><div className="kp-playback"><button aria-label={playing ? '暂停预览' : '播放预览'} disabled={!scenes.length} onClick={() => setPlaying(p => !p)}>{playing ? 'Ⅱ' : <Play size={16} />}</button><span>{scenes.length ? `${active + 1} / ${scenes.length}` : '0 / 0'}</span><div className="kp-mini-track"><i style={{ width: `${scenes.length ? ((active + 1) / scenes.length) * 100 : 0}%` }} /></div></div>
          <button className="kp-export" onClick={() => mode === 'video' ? exportFilm() : exportNote(active)} disabled={!!busy || !scenes.length}><Download size={17} />{mode === 'video' ? '生成并导出 MP4' : '导出当前图文图片'}</button><p className="kp-export-caption">{mode === 'video' ? '1080P · H.264 · 字幕与音轨一起导出' : '1080 × 1440 · PNG · 可逐张下载'}</p>
          {capabilities && !capabilities.renderer && <p className="kp-warning">部署端尚未安装 FFmpeg，暂时无法合成视频。请使用随包 Dockerfile。</p>}
          {jobs.length > 0 && <div className="kp-jobs"><h3>成片任务</h3>{jobs.slice().reverse().map(job => <div key={job.id}><div><span>{({ queued: '等待合成', running: '正在合成', completed: '成片已就绪', failed: '合成失败', cancelled: '已取消' } as Record<string, string>)[job.status]}</span><span>{job.progress}%</span></div><small>{job.title}</small><progress max="100" value={job.progress} />{job.error && <p>{job.error}</p>}{job.downloadable && <button onClick={() => task('正在加载真实成片', async () => { const response = await studioFetch(`/api/studio/jobs/${job.id}/download`); setFilmPreview({ url: URL.createObjectURL(await response.blob()), title: job.title || title || '快拍智造' }); })}><Play size={14} />预览成片</button>}{job.downloadable && <button onClick={() => task('正在下载', async () => { const r = await studioFetch(`/api/studio/jobs/${job.id}/download`); download(await r.blob(), `${job.title || title || '快拍智造'}-${job.id.slice(0, 4)}.mp4`); })}><Download size={14} />下载 MP4</button>}{['queued', 'running'].includes(job.status) && <button onClick={() => task('取消任务', async () => { await studioFetch(`/api/studio/jobs/${job.id}/cancel`, { method: 'POST' }); })}>取消</button>}</div>)}</div>}
          <details className="kp-help"><summary>让普通素材更好看</summary><p>同一场景尽量包含环境、人物动作和细节。每段拍摄保持3秒以上。价格、地址和推荐理由写得越具体，内容越贴近你。</p></details>
        </aside></div>
      </>}
      {page === 'projects' && <section className="kp-page"><h1>把创作，慢慢积累。</h1><p>云端保存工程与原始素材，换设备也能继续创作。</p><div className="kp-project-grid">{projects.map(project => <article key={project.id}><Film size={26} /><h2>{project.title}</h2><p>{project.scenes.length} 镜头 · {project.aspect}</p><button onClick={() => { task('正在打开云端工程与素材', async () => { const owner = auth.currentUser?.uid; const local = new Map(assets.map(a => [a.id, a])); const restored: Asset[] = []; for (const asset of project.assets) { const cached = local.get(asset.id); if (cached?.url) { restored.push(cached); continue; } const media = await restoreCloudAsset(asset); if (media) { files.current.set(asset.id, media.file); const info = await thumbnail(media.file, media.asset.url); restored.push({ ...media.asset, ...info }); } else restored.push({ ...asset, url: '' }); } if (auth.currentUser?.uid !== owner) return; setProjectId(project.id); setTitle(project.title); setScenes(project.scenes); setStyle(project.style); setAspect(project.aspect); setDescription(project.description); setAssets(restored); setActive(0); setPage('create'); if (restored.some(a => !a.url)) setNotice('旧工程未上传原始素材，请点镜头上的替换重新关联并保存。'); }); }}>继续编辑 <ArrowRight size={15} /></button><button onClick={() => { if (window.confirm(`删除工程“${project.title}”？此操作不删除原始素材。`)) task('删除工程', async () => { await deleteCloudProject(project.id!); setProjects(p => p.filter(i => i.id !== project.id)); }); }} aria-label={`删除工程${project.title}`}><Trash2 size={15} /></button></article>)}</div>{!projects.length && <div className="kp-empty"><Layers size={32} /><h2>你的下一条作品，从这里开始</h2><button className="kp-export" onClick={() => setPage('create')}>开始创作</button></div>}</section>}
      {page === 'assistant' && <section className="kp-page kp-assistant"><p className="kp-eyebrow">懂你的品牌，也懂你的表达</p><h1>建立你的内容搭档。</h1><p>写下表达偏好，再放入店铺、产品或品牌资料。无需搭建工作流。</p><label>助手名称<input value={assistant.name} onChange={e => setAssistant(a => ({ ...a, name: e.target.value }))} maxLength={80} /></label><label>你希望它怎样创作？<textarea value={assistant.instruction} onChange={e => setAssistant(a => ({ ...a, instruction: e.target.value }))} maxLength={3000} /></label><div className="kp-section-title"><h2>知识资料</h2><label className="kp-secondary kp-file-button"><Plus size={15} />添加 TXT / MD<input type="file" accept=".txt,.md,text/plain,text/markdown" multiple hidden onChange={e => { const selected = Array.from(e.target.files || []); task('读取知识资料', async () => { const docs = await Promise.all(selected.slice(0, 30 - assistant.knowledge.length).map(async file => { if (file.size > 150000) throw new Error('单份知识资料请控制在150KB内。'); return { id: crypto.randomUUID(), name: file.name, text: (await file.text()).slice(0, 50000) }; })); setAssistant(a => ({ ...a, knowledge: [...a.knowledge, ...docs] })); }); e.target.value = ''; }} /></label></div>{assistant.knowledge.map(item => <div className="kp-knowledge" key={item.id}><span>{item.name}<small>{item.text.length} 字</small></span><button aria-label={`移除${item.name}`} onClick={() => setAssistant(a => ({ ...a, knowledge: a.knowledge.filter(k => k.id !== item.id) }))}><X size={16} /></button></div>)}<details className="kp-paste"><summary>直接粘贴资料</summary><textarea placeholder="店名、营业时间、地址、产品信息……" onBlur={e => { const text = e.target.value.trim(); if (text) { setAssistant(a => ({ ...a, knowledge: [...a.knowledge, { id: crypto.randomUUID(), name: '手动补充资料', text: text.slice(0, 50000) }].slice(0, 30) })); e.target.value = ''; } }} /></details><button className="kp-export" disabled={!!busy} onClick={() => { if (needUser()) task('保存助手', async () => { await saveAssistant(assistant); try { const indexed = await (await studioFetch('/api/ai/knowledge-index', { method: 'POST', body: JSON.stringify({ knowledge: assistant.knowledge }) })).json(); setNotice(`助手已保存，${indexed.indexedSources} 份资料、${indexed.indexedChunks} 个片段已建立语义索引。`); } catch (error) { setNotice(`资料已保存到云端，但语义索引尚未完成：${(error as Error).message}`); } }); }}><Save size={16} />保存助手与知识库</button><div className="kp-rag-test"><h2>问一句，看看它是否真的理解</h2><div><input value={question} onChange={e => setQuestion(e.target.value)} placeholder="比如：店里有什么招牌菜？" /><button disabled={!!busy || !question.trim()} onClick={() => { if (needUser()) task('检索知识并回答', async () => { const r = await (await studioFetch('/api/ai/knowledge-answer', { method: 'POST', body: JSON.stringify({ question, knowledge: assistant.knowledge }) })).json(); setAnswer(r.answer); setSources(r.sources); }); }}><Search size={18} /></button></div>{answer && <p className="kp-answer">{answer}</p>}{sources.map((source, i) => <details key={i}><summary>{source.name} · 片段 {source.chunk}</summary><p>{source.text}</p></details>)}<small>结合语义向量与关键词检索，并显示来源。首次保存资料时自动建立索引；未命中时明确说明。</small></div></section>}
    </main>
    {busy && <div className="kp-busy" role="status"><LoaderCircle size={16} className="kp-spin" />{busy}</div>}
    {notice && <div className="kp-notice" role="alert">{notice}<button onClick={() => setNotice('')} aria-label="关闭提示"><X size={16} /></button></div>}
    {filmPreview && <dialog ref={resultDialog} className="kp-film-dialog" onClose={() => setFilmPreview(undefined)} aria-label="真实成片预览"><header><h2>{filmPreview.title}</h2><button onClick={() => resultDialog.current?.close()} aria-label="关闭成片预览"><X size={20} /></button></header><video src={filmPreview.url} controls autoPlay playsInline /><footer><span>这是合成后的实际文件，包含已生成的声音与字幕。</span><a href={filmPreview.url} download={`${filmPreview.title}.mp4`}><Download size={16} />下载 MP4</a></footer></dialog>}
    {authOpen && <div className="kp-modal-backdrop"><section className="kp-auth" role="dialog" aria-modal="true" aria-label="登录工作空间"><button className="kp-modal-close" onClick={() => setAuthOpen(false)} aria-label="关闭登录"><X size={20} /></button><span className="kp-logo"><Clapperboard size={25} /></span><h2>欢迎来到你的创作空间</h2><p>真实登录，独立作品，专属 AI 助手。</p><button className="kp-export" disabled={!!busy} onClick={() => login('google')}>使用 Google 账户继续</button><div className="kp-divider">或使用邮箱</div><label>邮箱<input type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label><label>密码<input type="password" autoComplete="current-password" value={password} minLength={8} onChange={e => setPassword(e.target.value)} /></label><div className="kp-auth-actions"><button className="kp-secondary" disabled={!!busy || !email || password.length < 8} onClick={() => login('register')}>注册账户</button><button className="kp-export" disabled={!!busy || !email || !password} onClick={() => login('login')}>登录</button></div><small>新用户默认为内容创作者，不能修改套餐、算力或其他用户数据。</small></section></div>}
  </div>;
}
