export interface Asset { id: string; name: string; kind: 'image' | 'video' | 'audio'; url: string; duration?: number; thumbnail?: string; storagePath?: string }
export interface Scene { assetId: string; text: string; duration: number; start: number }
export interface Knowledge { id: string; name: string; text: string }
export interface Assistant { name: string; instruction: string; knowledge: Knowledge[] }
export interface FilmProject { id?: string; title: string; style: string; aspect: '9:16' | '16:9'; scenes: Scene[]; assets: Asset[]; description: string; updatedAt?: unknown }
